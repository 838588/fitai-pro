import { useState } from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Activity } from 'lucide-react';

const muscleGroups = [
  { name: 'Chest', color: '#ef4444', exercises: ['Bench Press', 'Push-ups', 'Dips'] },
  { name: 'Back', color: '#3b82f6', exercises: ['Pull-ups', 'Rows', 'Deadlifts'] },
  { name: 'Shoulders', color: '#f59e0b', exercises: ['Shoulder Press', 'Lateral Raises'] },
  { name: 'Biceps', color: '#10b981', exercises: ['Curls', 'Chin-ups'] },
  { name: 'Triceps', color: '#8b5cf6', exercises: ['Dips', 'Extensions', 'Close Grip Press'] },
  { name: 'Abs', color: '#ec4899', exercises: ['Crunches', 'Planks', 'Leg Raises'] },
  { name: 'Quads', color: '#06b6d4', exercises: ['Squats', 'Lunges', 'Leg Press'] },
  { name: 'Hamstrings', color: '#f97316', exercises: ['Deadlifts', 'Leg Curls'] },
  { name: 'Glutes', color: '#a855f7', exercises: ['Squats', 'Hip Thrusts', 'Lunges'] },
  { name: 'Calves', color: '#14b8a6', exercises: ['Calf Raises', 'Jump Rope'] },
];

export function MuscleMap() {
  const [selectedMuscle, setSelectedMuscle] = useState<string | null>(null);
  const [hoveredMuscle, setHoveredMuscle] = useState<string | null>(null);

  const muscle = muscleGroups.find(m => m.name === (selectedMuscle || hoveredMuscle));

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-white mb-2 flex items-center gap-2">
          <Activity className="w-6 h-6 text-purple-400" />
          3D Muscle Map
        </h2>
        <p className="text-white/60">Visualize which muscles you're working</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Body Visualization */}
        <Card className="p-8 bg-white/5 border-white/10">
          <h3 className="text-white mb-6 text-center">Front View</h3>
          
          {/* Simplified body diagram using SVG */}
          <div className="relative mx-auto" style={{ maxWidth: '300px' }}>
            <svg viewBox="0 0 200 400" className="w-full">
              {/* Head */}
              <circle cx="100" cy="30" r="20" fill="#ffffff20" stroke="#ffffff40" strokeWidth="2" />
              
              {/* Torso */}
              <rect x="70" y="55" width="60" height="80" rx="10" fill="#ffffff20" stroke="#ffffff40" strokeWidth="2" />
              
              {/* Chest */}
              <ellipse
                cx="100" cy="75" rx="25" ry="20"
                fill={hoveredMuscle === 'Chest' || selectedMuscle === 'Chest' ? '#ef4444' : '#ffffff10'}
                stroke={hoveredMuscle === 'Chest' || selectedMuscle === 'Chest' ? '#ef4444' : '#ffffff30'}
                strokeWidth="2"
                className="cursor-pointer transition-all"
                onMouseEnter={() => setHoveredMuscle('Chest')}
                onMouseLeave={() => setHoveredMuscle(null)}
                onClick={() => setSelectedMuscle(selectedMuscle === 'Chest' ? null : 'Chest')}
              />
              
              {/* Abs */}
              <rect
                x="85" y="95" width="30" height="35" rx="5"
                fill={hoveredMuscle === 'Abs' || selectedMuscle === 'Abs' ? '#ec4899' : '#ffffff10'}
                stroke={hoveredMuscle === 'Abs' || selectedMuscle === 'Abs' ? '#ec4899' : '#ffffff30'}
                strokeWidth="2"
                className="cursor-pointer transition-all"
                onMouseEnter={() => setHoveredMuscle('Abs')}
                onMouseLeave={() => setHoveredMuscle(null)}
                onClick={() => setSelectedMuscle(selectedMuscle === 'Abs' ? null : 'Abs')}
              />
              
              {/* Shoulders */}
              <circle
                cx="60" cy="65" r="12"
                fill={hoveredMuscle === 'Shoulders' || selectedMuscle === 'Shoulders' ? '#f59e0b' : '#ffffff10'}
                stroke={hoveredMuscle === 'Shoulders' || selectedMuscle === 'Shoulders' ? '#f59e0b' : '#ffffff30'}
                strokeWidth="2"
                className="cursor-pointer transition-all"
                onMouseEnter={() => setHoveredMuscle('Shoulders')}
                onMouseLeave={() => setHoveredMuscle(null)}
                onClick={() => setSelectedMuscle(selectedMuscle === 'Shoulders' ? null : 'Shoulders')}
              />
              <circle
                cx="140" cy="65" r="12"
                fill={hoveredMuscle === 'Shoulders' || selectedMuscle === 'Shoulders' ? '#f59e0b' : '#ffffff10'}
                stroke={hoveredMuscle === 'Shoulders' || selectedMuscle === 'Shoulders' ? '#f59e0b' : '#ffffff30'}
                strokeWidth="2"
                className="cursor-pointer transition-all"
                onMouseEnter={() => setHoveredMuscle('Shoulders')}
                onMouseLeave={() => setHoveredMuscle(null)}
                onClick={() => setSelectedMuscle(selectedMuscle === 'Shoulders' ? null : 'Shoulders')}
              />
              
              {/* Arms - Biceps */}
              <rect
                x="40" y="75" width="15" height="40" rx="7"
                fill={hoveredMuscle === 'Biceps' || selectedMuscle === 'Biceps' ? '#10b981' : '#ffffff10'}
                stroke={hoveredMuscle === 'Biceps' || selectedMuscle === 'Biceps' ? '#10b981' : '#ffffff30'}
                strokeWidth="2"
                className="cursor-pointer transition-all"
                onMouseEnter={() => setHoveredMuscle('Biceps')}
                onMouseLeave={() => setHoveredMuscle(null)}
                onClick={() => setSelectedMuscle(selectedMuscle === 'Biceps' ? null : 'Biceps')}
              />
              <rect
                x="145" y="75" width="15" height="40" rx="7"
                fill={hoveredMuscle === 'Biceps' || selectedMuscle === 'Biceps' ? '#10b981' : '#ffffff10'}
                stroke={hoveredMuscle === 'Biceps' || selectedMuscle === 'Biceps' ? '#10b981' : '#ffffff30'}
                strokeWidth="2"
                className="cursor-pointer transition-all"
                onMouseEnter={() => setHoveredMuscle('Biceps')}
                onMouseLeave={() => setHoveredMuscle(null)}
                onClick={() => setSelectedMuscle(selectedMuscle === 'Biceps' ? null : 'Biceps')}
              />
              
              {/* Legs - Quads */}
              <rect
                x="75" y="140" width="20" height="70" rx="10"
                fill={hoveredMuscle === 'Quads' || selectedMuscle === 'Quads' ? '#06b6d4' : '#ffffff10'}
                stroke={hoveredMuscle === 'Quads' || selectedMuscle === 'Quads' ? '#06b6d4' : '#ffffff30'}
                strokeWidth="2"
                className="cursor-pointer transition-all"
                onMouseEnter={() => setHoveredMuscle('Quads')}
                onMouseLeave={() => setHoveredMuscle(null)}
                onClick={() => setSelectedMuscle(selectedMuscle === 'Quads' ? null : 'Quads')}
              />
              <rect
                x="105" y="140" width="20" height="70" rx="10"
                fill={hoveredMuscle === 'Quads' || selectedMuscle === 'Quads' ? '#06b6d4' : '#ffffff10'}
                stroke={hoveredMuscle === 'Quads' || selectedMuscle === 'Quads' ? '#06b6d4' : '#ffffff30'}
                strokeWidth="2"
                className="cursor-pointer transition-all"
                onMouseEnter={() => setHoveredMuscle('Quads')}
                onMouseLeave={() => setHoveredMuscle(null)}
                onClick={() => setSelectedMuscle(selectedMuscle === 'Quads' ? null : 'Quads')}
              />
              
              {/* Calves */}
              <ellipse
                cx="85" cy="230" rx="8" ry="20"
                fill={hoveredMuscle === 'Calves' || selectedMuscle === 'Calves' ? '#14b8a6' : '#ffffff10'}
                stroke={hoveredMuscle === 'Calves' || selectedMuscle === 'Calves' ? '#14b8a6' : '#ffffff30'}
                strokeWidth="2"
                className="cursor-pointer transition-all"
                onMouseEnter={() => setHoveredMuscle('Calves')}
                onMouseLeave={() => setHoveredMuscle(null)}
                onClick={() => setSelectedMuscle(selectedMuscle === 'Calves' ? null : 'Calves')}
              />
              <ellipse
                cx="115" cy="230" rx="8" ry="20"
                fill={hoveredMuscle === 'Calves' || selectedMuscle === 'Calves' ? '#14b8a6' : '#ffffff10'}
                stroke={hoveredMuscle === 'Calves' || selectedMuscle === 'Calves' ? '#14b8a6' : '#ffffff30'}
                strokeWidth="2"
                className="cursor-pointer transition-all"
                onMouseEnter={() => setHoveredMuscle('Calves')}
                onMouseLeave={() => setHoveredMuscle(null)}
                onClick={() => setSelectedMuscle(selectedMuscle === 'Calves' ? null : 'Calves')}
              />
            </svg>
          </div>

          <p className="text-white/60 text-sm text-center mt-4">
            Click or hover over muscle groups
          </p>
        </Card>

        {/* Muscle Information */}
        <div className="space-y-4">
          {muscle ? (
            <Card className="p-6 bg-white/5 border-white/10">
              <div className="flex items-center gap-3 mb-4">
                <div
                  className="w-8 h-8 rounded-full"
                  style={{ backgroundColor: muscle.color }}
                />
                <h3 className="text-white">{muscle.name}</h3>
              </div>

              <div className="space-y-3">
                <div>
                  <p className="text-white/60 text-sm mb-2">Best Exercises:</p>
                  <div className="flex flex-wrap gap-2">
                    {muscle.exercises.map(ex => (
                      <Badge key={ex} className="bg-purple-500/20 text-purple-300 border-purple-500/30">
                        {ex}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </Card>
          ) : (
            <Card className="p-12 bg-white/5 border-white/10 text-center">
              <Activity className="w-12 h-12 text-white/40 mx-auto mb-4" />
              <p className="text-white/60">Select a muscle group to see details</p>
            </Card>
          )}

          {/* Muscle Groups Legend */}
          <Card className="p-6 bg-white/5 border-white/10">
            <h3 className="text-white mb-4">Muscle Groups</h3>
            <div className="space-y-2">
              {muscleGroups.map(group => (
                <button
                  key={group.name}
                  onClick={() => setSelectedMuscle(selectedMuscle === group.name ? null : group.name)}
                  onMouseEnter={() => setHoveredMuscle(group.name)}
                  onMouseLeave={() => setHoveredMuscle(null)}
                  className={`w-full flex items-center gap-3 p-3 rounded-lg transition-all ${
                    selectedMuscle === group.name || hoveredMuscle === group.name
                      ? 'bg-white/20'
                      : 'bg-white/5 hover:bg-white/10'
                  }`}
                >
                  <div
                    className="w-4 h-4 rounded-full"
                    style={{ backgroundColor: group.color }}
                  />
                  <span className="text-white">{group.name}</span>
                  <span className="ml-auto text-white/60 text-sm">
                    {group.exercises.length} exercises
                  </span>
                </button>
              ))}
            </div>
          </Card>
        </div>
      </div>

      {/* Workout Focus Guide */}
      <Card className="p-6 bg-gradient-to-r from-purple-500/10 to-pink-500/10 border-purple-500/30">
        <h3 className="text-white mb-3">💡 Weekly Training Guide</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-white/80 text-sm">
          <div>
            <p className="mb-2">• <strong>Push Day:</strong> Chest, Shoulders, Triceps</p>
            <p className="mb-2">• <strong>Pull Day:</strong> Back, Biceps</p>
            <p>• <strong>Leg Day:</strong> Quads, Hamstrings, Glutes, Calves</p>
          </div>
          <div>
            <p className="mb-2">• Train each muscle group 1-2 times per week</p>
            <p className="mb-2">• Allow 48 hours recovery between sessions</p>
            <p>• Don't neglect smaller muscle groups</p>
          </div>
        </div>
      </Card>
    </div>
  );
}
