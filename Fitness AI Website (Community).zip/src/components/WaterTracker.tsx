import { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Droplet, Plus, Minus, Target } from 'lucide-react';
import { projectId } from '../utils/supabase/info';
import { toast } from 'sonner@2.0.3';

interface WaterEntry {
  date: string;
  amount: number; // in ml
}

interface WaterTrackerProps {
  accessToken: string;
}

const GLASS_SIZES = [
  { label: 'Small Glass', ml: 200 },
  { label: 'Medium Glass', ml: 250 },
  { label: 'Large Glass', ml: 350 },
  { label: 'Water Bottle', ml: 500 },
  { label: 'Large Bottle', ml: 1000 },
];

const DAILY_GOAL = 2500; // ml (about 8-10 glasses)

export function WaterTracker({ accessToken }: WaterTrackerProps) {
  const [entries, setEntries] = useState<WaterEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const today = new Date().toISOString().split('T')[0];

  useEffect(() => {
    loadEntries();
  }, []);

  const loadEntries = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-eb0ee345/water-tracker`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${accessToken}`
          }
        }
      );

      const data = await response.json();
      if (response.ok && data.entries) {
        setEntries(data.entries);
      }
    } catch (err) {
      console.error('Error loading water entries:', err);
    } finally {
      setLoading(false);
    }
  };

  const addWater = async (ml: number) => {
    const existingEntry = entries.find(e => e.date === today);
    let updatedEntries: WaterEntry[];

    if (existingEntry) {
      updatedEntries = entries.map(e =>
        e.date === today ? { ...e, amount: e.amount + ml } : e
      );
    } else {
      updatedEntries = [...entries, { date: today, amount: ml }];
    }

    await saveEntries(updatedEntries);
  };

  const removeWater = async (ml: number) => {
    const existingEntry = entries.find(e => e.date === today);
    if (!existingEntry) return;

    const updatedEntries = entries.map(e =>
      e.date === today ? { ...e, amount: Math.max(0, e.amount - ml) } : e
    );

    await saveEntries(updatedEntries);
  };

  const saveEntries = async (updatedEntries: WaterEntry[]) => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-eb0ee345/water-tracker`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`
          },
          body: JSON.stringify({ entries: updatedEntries })
        }
      );

      if (response.ok) {
        setEntries(updatedEntries);
        const todayAmount = updatedEntries.find(e => e.date === today)?.amount || 0;
        if (todayAmount >= DAILY_GOAL) {
          toast.success('🎉 Daily water goal achieved!');
        }
      }
    } catch (err) {
      console.error('Error saving water entries:', err);
      toast.error('Failed to update water intake');
    }
  };

  const getTodayAmount = () => {
    return entries.find(e => e.date === today)?.amount || 0;
  };

  const getWeeklyAverage = () => {
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    
    const weekEntries = entries.filter(e => new Date(e.date) >= weekAgo);
    if (weekEntries.length === 0) return 0;
    
    const total = weekEntries.reduce((sum, e) => sum + e.amount, 0);
    return Math.round(total / 7);
  };

  const todayAmount = getTodayAmount();
  const percentage = Math.min((todayAmount / DAILY_GOAL) * 100, 100);
  const glassesEquivalent = Math.round(todayAmount / 250);

  if (loading) {
    return (
      <Card className="p-6 bg-white/5 border-white/10">
        <p className="text-white/60 text-center">Loading water tracker...</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-white mb-2 flex items-center gap-2">
            <Droplet className="w-6 h-6 text-blue-400" />
            Water Tracker
          </h2>
          <p className="text-white/60">Stay hydrated throughout the day</p>
        </div>
      </div>

      {/* Today's Progress */}
      <Card className="p-6 bg-gradient-to-br from-blue-500/20 to-cyan-500/20 border-blue-500/30">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Droplet className="w-8 h-8 text-blue-400" />
            <div>
              <p className="text-white/80 text-sm">Today's Intake</p>
              <p className="text-white text-3xl">{todayAmount} ml</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-white/80 text-sm">Goal</p>
            <p className="text-white text-xl">{DAILY_GOAL} ml</p>
          </div>
        </div>

        <Progress value={percentage} className="h-4 mb-2" />
        
        <div className="flex items-center justify-between text-sm">
          <span className="text-white/80">
            {glassesEquivalent} glasses (~250ml each)
          </span>
          <span className="text-white/80">
            {Math.round(percentage)}%
          </span>
        </div>

        {percentage >= 100 && (
          <div className="mt-4 p-3 bg-green-500/20 border border-green-500/30 rounded-lg text-center">
            <p className="text-green-300">🎉 Goal achieved! Keep it up!</p>
          </div>
        )}
      </Card>

      {/* Quick Add Buttons */}
      <Card className="p-6 bg-white/5 border-white/10">
        <h3 className="text-white mb-4 flex items-center gap-2">
          <Plus className="w-5 h-5" />
          Quick Add
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {GLASS_SIZES.map(size => (
            <Button
              key={size.label}
              onClick={() => addWater(size.ml)}
              className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 flex flex-col gap-1 h-auto py-4"
            >
              <Droplet className="w-5 h-5" />
              <span className="text-sm">{size.label}</span>
              <span className="text-xs opacity-80">{size.ml}ml</span>
            </Button>
          ))}
        </div>

        {todayAmount > 0 && (
          <div className="mt-4 pt-4 border-t border-white/10">
            <Button
              onClick={() => removeWater(250)}
              className="w-full bg-red-500/20 hover:bg-red-500/30 text-red-300"
            >
              <Minus className="w-4 h-4 mr-2" />
              Remove 250ml
            </Button>
          </div>
        )}
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-6 bg-white/5 border-white/10">
          <div className="flex items-center gap-3 mb-2">
            <Target className="w-5 h-5 text-purple-400" />
            <span className="text-white/60">Remaining</span>
          </div>
          <p className="text-white text-2xl">
            {Math.max(0, DAILY_GOAL - todayAmount)} ml
          </p>
        </Card>

        <Card className="p-6 bg-white/5 border-white/10">
          <div className="flex items-center gap-3 mb-2">
            <Droplet className="w-5 h-5 text-blue-400" />
            <span className="text-white/60">Weekly Average</span>
          </div>
          <p className="text-white text-2xl">{getWeeklyAverage()} ml</p>
        </Card>

        <Card className="p-6 bg-white/5 border-white/10">
          <div className="flex items-center gap-3 mb-2">
            <div className="text-xl">🏆</div>
            <span className="text-white/60">Streak</span>
          </div>
          <p className="text-white text-2xl">
            {entries.filter(e => e.amount >= DAILY_GOAL).length} days
          </p>
        </Card>
      </div>

      {/* Hydration Tips */}
      <Card className="p-6 bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border-blue-500/30">
        <h3 className="text-white mb-3">💧 Hydration Tips</h3>
        <ul className="space-y-2 text-white/80 text-sm">
          <li>• Drink water first thing in the morning</li>
          <li>• Keep a water bottle nearby during workouts</li>
          <li>• Drink before you feel thirsty</li>
          <li>• Increase intake during hot weather or intense exercise</li>
          <li>• Set hourly reminders to drink water</li>
        </ul>
      </Card>
    </div>
  );
}
