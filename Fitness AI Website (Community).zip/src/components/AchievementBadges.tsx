import { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Trophy, Award, Target, Flame, Star, Medal, Crown, Zap } from 'lucide-react';
import { projectId } from '../utils/supabase/info';

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: string;
  unlocked: boolean;
  unlockedDate?: string;
  progress?: number;
  target?: number;
}

interface AchievementBadgesProps {
  accessToken: string;
}

const availableAchievements: Omit<Achievement, 'unlocked' | 'unlockedDate' | 'progress'>[] = [
  {
    id: 'first-workout',
    title: 'First Steps',
    description: 'Complete your first workout',
    icon: '🎯',
    category: 'Beginner',
    target: 1,
  },
  {
    id: 'week-streak',
    title: 'Week Warrior',
    description: 'Complete 7 consecutive days of workouts',
    icon: '🔥',
    category: 'Consistency',
    target: 7,
  },
  {
    id: 'month-streak',
    title: 'Monthly Master',
    description: 'Workout for 30 consecutive days',
    icon: '👑',
    category: 'Consistency',
    target: 30,
  },
  {
    id: 'ten-workouts',
    title: 'Getting Strong',
    description: 'Complete 10 total workouts',
    icon: '💪',
    category: 'Progress',
    target: 10,
  },
  {
    id: 'fifty-workouts',
    title: 'Dedicated Athlete',
    description: 'Complete 50 total workouts',
    icon: '⭐',
    category: 'Progress',
    target: 50,
  },
  {
    id: 'hundred-workouts',
    title: 'Century Club',
    description: 'Complete 100 total workouts',
    icon: '🏆',
    category: 'Progress',
    target: 100,
  },
  {
    id: 'early-bird',
    title: 'Early Bird',
    description: 'Complete 5 workouts before 7 AM',
    icon: '🌅',
    category: 'Special',
    target: 5,
  },
  {
    id: 'night-owl',
    title: 'Night Owl',
    description: 'Complete 5 workouts after 8 PM',
    icon: '🌙',
    category: 'Special',
    target: 5,
  },
  {
    id: 'pr-setter',
    title: 'Record Breaker',
    description: 'Set 5 personal records',
    icon: '🚀',
    category: 'Strength',
    target: 5,
  },
  {
    id: 'hydration-hero',
    title: 'Hydration Hero',
    description: 'Meet water goal for 7 consecutive days',
    icon: '💧',
    category: 'Wellness',
    target: 7,
  },
  {
    id: 'meal-tracker',
    title: 'Nutrition Ninja',
    description: 'Log meals for 14 consecutive days',
    icon: '🍎',
    category: 'Nutrition',
    target: 14,
  },
  {
    id: 'sleep-master',
    title: 'Sleep Master',
    description: 'Get 8+ hours of sleep for 7 days',
    icon: '😴',
    category: 'Recovery',
    target: 7,
  },
  {
    id: 'full-body',
    title: 'Full Body Focus',
    description: 'Complete 10 full body workouts',
    icon: '🎪',
    category: 'Variety',
    target: 10,
  },
  {
    id: 'cardio-king',
    title: 'Cardio King',
    description: 'Complete 20 cardio sessions',
    icon: '🏃',
    category: 'Cardio',
    target: 20,
  },
  {
    id: 'strength-beast',
    title: 'Strength Beast',
    description: 'Lift 10,000 kg total volume',
    icon: '🦍',
    category: 'Strength',
    target: 10000,
  },
  {
    id: 'perfect-week',
    title: 'Perfect Week',
    description: 'Hit all targets for 7 days (workout, water, sleep, nutrition)',
    icon: '✨',
    category: 'Excellence',
    target: 7,
  },
];

export function AchievementBadges({ accessToken }: AchievementBadgesProps) {
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('All');

  useEffect(() => {
    loadAchievements();
  }, []);

  const loadAchievements = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-eb0ee345/achievements`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${accessToken}`
          }
        }
      );

      const data = await response.json();
      if (response.ok && data.achievements) {
        setAchievements(data.achievements);
      } else {
        // Initialize with all achievements locked
        const initialAchievements = availableAchievements.map(a => ({
          ...a,
          unlocked: false,
          progress: 0,
        }));
        setAchievements(initialAchievements);
      }
    } catch (err) {
      console.error('Error loading achievements:', err);
      const initialAchievements = availableAchievements.map(a => ({
        ...a,
        unlocked: false,
        progress: 0,
      }));
      setAchievements(initialAchievements);
    } finally {
      setLoading(false);
    }
  };

  const categories = ['All', 'Beginner', 'Consistency', 'Progress', 'Strength', 'Nutrition', 'Wellness', 'Recovery', 'Special', 'Excellence', 'Variety', 'Cardio'];

  const filteredAchievements = selectedCategory === 'All'
    ? achievements
    : achievements.filter(a => a.category === selectedCategory);

  const unlockedCount = achievements.filter(a => a.unlocked).length;
  const totalCount = achievements.length;
  const completionPercentage = Math.round((unlockedCount / totalCount) * 100);

  if (loading) {
    return (
      <Card className="p-6 bg-white/5 border-white/10">
        <p className="text-white/60 text-center">Loading achievements...</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-white mb-2 flex items-center gap-2">
            <Trophy className="w-6 h-6 text-yellow-400" />
            Achievement Badges
          </h2>
          <p className="text-white/60">Unlock badges as you progress</p>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-6 bg-gradient-to-br from-yellow-500/20 to-orange-500/20 border-yellow-500/30">
          <div className="flex items-center gap-3 mb-2">
            <Trophy className="w-6 h-6 text-yellow-400" />
            <span className="text-white/80">Total Unlocked</span>
          </div>
          <p className="text-white text-3xl">{unlockedCount} / {totalCount}</p>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-purple-500/20 to-pink-500/20 border-purple-500/30">
          <div className="flex items-center gap-3 mb-2">
            <Star className="w-6 h-6 text-purple-400" />
            <span className="text-white/80">Completion</span>
          </div>
          <p className="text-white text-3xl">{completionPercentage}%</p>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-blue-500/20 to-cyan-500/20 border-blue-500/30">
          <div className="flex items-center gap-3 mb-2">
            <Zap className="w-6 h-6 text-blue-400" />
            <span className="text-white/80">In Progress</span>
          </div>
          <p className="text-white text-3xl">
            {achievements.filter(a => !a.unlocked && (a.progress || 0) > 0).length}
          </p>
        </Card>
      </div>

      {/* Category Filter */}
      <Card className="p-4 bg-white/5 border-white/10">
        <div className="flex flex-wrap gap-2">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 rounded-lg text-sm transition-all ${
                selectedCategory === cat
                  ? 'bg-purple-500 text-white'
                  : 'bg-white/10 text-white/60 hover:bg-white/20'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </Card>

      {/* Achievements Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredAchievements.map(achievement => (
          <Card
            key={achievement.id}
            className={`p-6 transition-all ${
              achievement.unlocked
                ? 'bg-gradient-to-br from-yellow-500/20 to-orange-500/20 border-yellow-500/30'
                : 'bg-white/5 border-white/10 opacity-60'
            }`}
          >
            <div className="flex items-start gap-4">
              <div className={`text-4xl ${achievement.unlocked ? 'grayscale-0' : 'grayscale opacity-40'}`}>
                {achievement.icon}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="text-white">{achievement.title}</h3>
                  {achievement.unlocked && (
                    <Medal className="w-4 h-4 text-yellow-400" />
                  )}
                </div>
                <p className="text-white/60 text-sm mb-2">{achievement.description}</p>
                <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30 text-xs">
                  {achievement.category}
                </Badge>

                {!achievement.unlocked && achievement.target && (
                  <div className="mt-3">
                    <div className="flex items-center justify-between text-xs text-white/60 mb-1">
                      <span>Progress</span>
                      <span>{achievement.progress || 0} / {achievement.target}</span>
                    </div>
                    <div className="w-full bg-white/10 rounded-full h-2">
                      <div
                        className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full transition-all"
                        style={{
                          width: `${Math.min(((achievement.progress || 0) / achievement.target) * 100, 100)}%`
                        }}
                      />
                    </div>
                  </div>
                )}

                {achievement.unlocked && achievement.unlockedDate && (
                  <p className="text-white/40 text-xs mt-2">
                    Unlocked {new Date(achievement.unlockedDate).toLocaleDateString()}
                  </p>
                )}
              </div>
            </div>
          </Card>
        ))}
      </div>

      {filteredAchievements.length === 0 && (
        <Card className="p-12 bg-white/5 border-white/10 text-center">
          <Award className="w-12 h-12 text-white/40 mx-auto mb-4" />
          <p className="text-white/60">No achievements in this category</p>
        </Card>
      )}

      {/* Recent Unlocks */}
      {unlockedCount > 0 && selectedCategory === 'All' && (
        <Card className="p-6 bg-white/5 border-white/10">
          <h3 className="text-white mb-4 flex items-center gap-2">
            <Flame className="w-5 h-5 text-orange-400" />
            Recent Unlocks
          </h3>
          <div className="space-y-3">
            {achievements
              .filter(a => a.unlocked)
              .sort((a, b) => new Date(b.unlockedDate!).getTime() - new Date(a.unlockedDate!).getTime())
              .slice(0, 5)
              .map(achievement => (
                <div
                  key={achievement.id}
                  className="flex items-center gap-3 p-3 bg-white/5 rounded-lg"
                >
                  <div className="text-2xl">{achievement.icon}</div>
                  <div className="flex-1">
                    <p className="text-white">{achievement.title}</p>
                    <p className="text-white/60 text-sm">
                      {new Date(achievement.unlockedDate!).toLocaleDateString()}
                    </p>
                  </div>
                  <Medal className="w-5 h-5 text-yellow-400" />
                </div>
              ))}
          </div>
        </Card>
      )}
    </div>
  );
}
