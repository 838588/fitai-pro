import { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Trophy, Plus, TrendingUp, Calendar, Trash2, Award } from 'lucide-react';
import { projectId } from '../utils/supabase/info';
import { toast } from 'sonner@2.0.3';

interface PersonalRecord {
  id: string;
  exercise: string;
  category: string;
  weight: number;
  reps: number;
  date: string;
  notes?: string;
}

interface PersonalRecordsProps {
  accessToken: string;
}

const exerciseCategories = {
  'Chest': ['Bench Press', 'Incline Press', 'Dumbbell Press', 'Push-ups'],
  'Back': ['Deadlift', 'Pull-ups', 'Barbell Row', 'Lat Pulldown'],
  'Legs': ['Squat', 'Leg Press', 'Romanian Deadlift', 'Lunges'],
  'Shoulders': ['Overhead Press', 'Lateral Raise', 'Front Raise'],
  'Arms': ['Barbell Curl', 'Tricep Dips', 'Hammer Curl', 'Skull Crushers'],
  'Core': ['Plank (time)', 'Hanging Leg Raise', 'Ab Wheel'],
};

export function PersonalRecords({ accessToken }: PersonalRecordsProps) {
  const [records, setRecords] = useState<PersonalRecord[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const [formData, setFormData] = useState({
    exercise: '',
    customExercise: '',
    category: 'Chest',
    weight: '',
    reps: '',
    date: new Date().toISOString().split('T')[0],
    notes: '',
  });

  useEffect(() => {
    loadRecords();
  }, []);

  const loadRecords = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-eb0ee345/personal-records`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${accessToken}`
          }
        }
      );

      const data = await response.json();
      if (response.ok && data.records) {
        setRecords(data.records);
      }
    } catch (err) {
      console.error('Error loading records:', err);
    } finally {
      setLoading(false);
    }
  };

  const saveRecord = async () => {
    const exerciseName = formData.exercise === 'custom' ? formData.customExercise : formData.exercise;
    
    if (!exerciseName || !formData.weight || !formData.reps) {
      toast.error('Please fill in all required fields');
      return;
    }

    const newRecord: PersonalRecord = {
      id: Date.now().toString(),
      exercise: exerciseName,
      category: formData.category,
      weight: parseFloat(formData.weight),
      reps: parseInt(formData.reps),
      date: formData.date,
      notes: formData.notes,
    };

    try {
      const updatedRecords = [...records, newRecord];

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-eb0ee345/personal-records`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`
          },
          body: JSON.stringify({ records: updatedRecords })
        }
      );

      if (response.ok) {
        setRecords(updatedRecords);
        setShowForm(false);
        setFormData({
          exercise: '',
          customExercise: '',
          category: 'Chest',
          weight: '',
          reps: '',
          date: new Date().toISOString().split('T')[0],
          notes: '',
        });
        toast.success('🏆 New PR logged!');
      }
    } catch (err) {
      console.error('Error saving record:', err);
      toast.error('Failed to save record');
    }
  };

  const deleteRecord = async (id: string) => {
    const updatedRecords = records.filter(r => r.id !== id);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-eb0ee345/personal-records`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`
          },
          body: JSON.stringify({ records: updatedRecords })
        }
      );

      if (response.ok) {
        setRecords(updatedRecords);
        toast.success('Record deleted');
      }
    } catch (err) {
      console.error('Error deleting record:', err);
      toast.error('Failed to delete record');
    }
  };

  const calculate1RM = (weight: number, reps: number) => {
    // Epley Formula
    return reps === 1 ? weight : Math.round(weight * (1 + reps / 30));
  };

  const getTopRecords = () => {
    const topRecords: { [key: string]: PersonalRecord } = {};
    
    records.forEach(record => {
      const rm = calculate1RM(record.weight, record.reps);
      if (!topRecords[record.exercise] || calculate1RM(topRecords[record.exercise].weight, topRecords[record.exercise].reps) < rm) {
        topRecords[record.exercise] = record;
      }
    });

    return Object.values(topRecords);
  };

  const filteredRecords = selectedCategory === 'All' 
    ? getTopRecords()
    : getTopRecords().filter(r => r.category === selectedCategory);

  if (loading) {
    return (
      <Card className="p-6 bg-white/5 border-white/10">
        <p className="text-white/60 text-center">Loading personal records...</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-white mb-2 flex items-center gap-2">
            <Trophy className="w-6 h-6 text-yellow-400" />
            Personal Records
          </h2>
          <p className="text-white/60">Track your best lifts and achievements</p>
        </div>
        <Button
          onClick={() => setShowForm(!showForm)}
          className="bg-gradient-to-r from-yellow-500 to-orange-500"
        >
          <Plus className="w-4 h-4 mr-2" />
          Log PR
        </Button>
      </div>

      {/* Stats Overview */}
      {records.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="p-6 bg-white/5 border-white/10">
            <div className="flex items-center gap-3 mb-2">
              <Award className="w-5 h-5 text-yellow-400" />
              <span className="text-white/60">Total PRs</span>
            </div>
            <p className="text-white text-2xl">{getTopRecords().length}</p>
          </Card>

          <Card className="p-6 bg-white/5 border-white/10">
            <div className="flex items-center gap-3 mb-2">
              <TrendingUp className="w-5 h-5 text-green-400" />
              <span className="text-white/60">This Month</span>
            </div>
            <p className="text-white text-2xl">
              {records.filter(r => {
                const recordDate = new Date(r.date);
                const now = new Date();
                return recordDate.getMonth() === now.getMonth() && recordDate.getFullYear() === now.getFullYear();
              }).length}
            </p>
          </Card>

          <Card className="p-6 bg-white/5 border-white/10">
            <div className="flex items-center gap-3 mb-2">
              <Calendar className="w-5 h-5 text-blue-400" />
              <span className="text-white/60">Latest PR</span>
            </div>
            <p className="text-white">
              {records.length > 0 
                ? new Date(records[records.length - 1].date).toLocaleDateString()
                : 'N/A'
              }
            </p>
          </Card>
        </div>
      )}

      {/* Add Record Form */}
      {showForm && (
        <Card className="p-6 bg-white/5 border-white/10">
          <h3 className="text-white mb-4">Log New Personal Record</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="text-white/80">Category *</Label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value, exercise: '' })}
                className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
              >
                {Object.keys(exerciseCategories).map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            <div>
              <Label className="text-white/80">Exercise *</Label>
              <select
                value={formData.exercise}
                onChange={(e) => setFormData({ ...formData, exercise: e.target.value })}
                className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
              >
                <option value="">Select exercise</option>
                {exerciseCategories[formData.category as keyof typeof exerciseCategories].map(ex => (
                  <option key={ex} value={ex}>{ex}</option>
                ))}
                <option value="custom">Custom Exercise...</option>
              </select>
            </div>

            {formData.exercise === 'custom' && (
              <div className="md:col-span-2">
                <Label className="text-white/80">Custom Exercise Name *</Label>
                <Input
                  value={formData.customExercise}
                  onChange={(e) => setFormData({ ...formData, customExercise: e.target.value })}
                  className="bg-white/10 border-white/20 text-white"
                  placeholder="Enter exercise name"
                />
              </div>
            )}

            <div>
              <Label className="text-white/80">Weight (kg) *</Label>
              <Input
                type="number"
                step="0.5"
                value={formData.weight}
                onChange={(e) => setFormData({ ...formData, weight: e.target.value })}
                className="bg-white/10 border-white/20 text-white"
                placeholder="100"
              />
            </div>

            <div>
              <Label className="text-white/80">Reps *</Label>
              <Input
                type="number"
                value={formData.reps}
                onChange={(e) => setFormData({ ...formData, reps: e.target.value })}
                className="bg-white/10 border-white/20 text-white"
                placeholder="5"
              />
            </div>

            <div>
              <Label className="text-white/80">Date *</Label>
              <Input
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="bg-white/10 border-white/20 text-white"
              />
            </div>

            <div>
              <Label className="text-white/80">Notes</Label>
              <Input
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="bg-white/10 border-white/20 text-white"
                placeholder="Optional notes"
              />
            </div>

            {formData.weight && formData.reps && (
              <div className="md:col-span-2">
                <div className="p-4 bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border border-yellow-500/30 rounded-lg">
                  <p className="text-white/80 text-sm mb-1">Estimated 1RM</p>
                  <p className="text-white text-2xl">
                    {calculate1RM(parseFloat(formData.weight), parseInt(formData.reps))} kg
                  </p>
                </div>
              </div>
            )}
          </div>

          <div className="flex gap-3 mt-6">
            <Button onClick={saveRecord} className="bg-gradient-to-r from-yellow-500 to-orange-500">
              Save Record
            </Button>
            <Button onClick={() => setShowForm(false)} className="bg-white/10">
              Cancel
            </Button>
          </div>
        </Card>
      )}

      {/* Category Filter */}
      {records.length > 0 && (
        <div className="flex flex-wrap gap-2">
          <Button
            onClick={() => setSelectedCategory('All')}
            className={selectedCategory === 'All' ? 'bg-purple-500' : 'bg-white/10'}
            size="sm"
          >
            All
          </Button>
          {Object.keys(exerciseCategories).map(cat => (
            <Button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={selectedCategory === cat ? 'bg-purple-500' : 'bg-white/10'}
              size="sm"
            >
              {cat}
            </Button>
          ))}
        </div>
      )}

      {/* Records List */}
      {filteredRecords.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredRecords.map((record) => (
            <Card key={record.id} className="p-6 bg-white/5 border-white/10">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <Trophy className="w-5 h-5 text-yellow-400" />
                    <h3 className="text-white">{record.exercise}</h3>
                  </div>
                  <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30">
                    {record.category}
                  </Badge>
                </div>
                <Button
                  onClick={() => deleteRecord(record.id)}
                  className="bg-red-500/20 hover:bg-red-500/30 text-red-300"
                  size="sm"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <p className="text-white/60 text-sm">Weight</p>
                  <p className="text-white text-xl">{record.weight} kg</p>
                </div>
                <div>
                  <p className="text-white/60 text-sm">Reps</p>
                  <p className="text-white text-xl">{record.reps}</p>
                </div>
              </div>

              <div className="p-3 bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border border-yellow-500/20 rounded-lg mb-3">
                <p className="text-white/60 text-sm">Estimated 1RM</p>
                <p className="text-white text-xl">{calculate1RM(record.weight, record.reps)} kg</p>
              </div>

              <div className="flex items-center justify-between text-sm">
                <span className="text-white/60">{new Date(record.date).toLocaleDateString()}</span>
                {record.notes && (
                  <span className="text-white/60 italic truncate ml-2">{record.notes}</span>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}

      {records.length === 0 && !showForm && (
        <Card className="p-12 bg-white/5 border-white/10 text-center">
          <Trophy className="w-12 h-12 text-white/40 mx-auto mb-4" />
          <p className="text-white/60 mb-4">No personal records yet</p>
          <p className="text-white/40 text-sm">Start logging your PRs to track your strength progress!</p>
        </Card>
      )}
    </div>
  );
}
