import { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ChevronLeft, ChevronRight, CheckCircle, Circle, Calendar as CalendarIcon } from 'lucide-react';
import { projectId } from '../utils/supabase/info';
import { toast } from 'sonner@2.0.3';

interface WorkoutDay {
  date: string;
  completed: boolean;
  workoutType?: string;
  exercises?: number;
  duration?: number;
}

interface WorkoutCalendarProps {
  accessToken: string;
}

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

export function WorkoutCalendar({ accessToken }: WorkoutCalendarProps) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [workoutDays, setWorkoutDays] = useState<WorkoutDay[]>([]);
  const [selectedDay, setSelectedDay] = useState<WorkoutDay | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadWorkoutDays();
  }, []);

  const loadWorkoutDays = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-eb0ee345/workout-calendar`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${accessToken}`
          }
        }
      );

      const data = await response.json();
      if (response.ok && data.workoutDays) {
        setWorkoutDays(data.workoutDays);
      }
    } catch (err) {
      console.error('Error loading workout calendar:', err);
    } finally {
      setLoading(false);
    }
  };

  const toggleWorkoutDay = async (date: string) => {
    const existingDay = workoutDays.find(d => d.date === date);
    let updatedDays: WorkoutDay[];

    if (existingDay) {
      updatedDays = workoutDays.map(d => 
        d.date === date ? { ...d, completed: !d.completed } : d
      );
    } else {
      updatedDays = [...workoutDays, {
        date,
        completed: true,
        workoutType: 'Workout',
        exercises: 0,
        duration: 0
      }];
    }

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-eb0ee345/workout-calendar`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`
          },
          body: JSON.stringify({ workoutDays: updatedDays })
        }
      );

      if (response.ok) {
        setWorkoutDays(updatedDays);
        const day = updatedDays.find(d => d.date === date);
        if (day?.completed) {
          toast.success('Workout completed! 🎉');
        }
      }
    } catch (err) {
      console.error('Error updating workout day:', err);
      toast.error('Failed to update workout');
    }
  };

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days: (Date | null)[] = [];
    
    // Add empty slots for days before month starts
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }
    
    // Add days of the month
    for (let i = 1; i <= daysInMonth; i++) {
      days.push(new Date(year, month, i));
    }

    return days;
  };

  const getWorkoutForDate = (date: Date | null): WorkoutDay | undefined => {
    if (!date) return undefined;
    const dateStr = date.toISOString().split('T')[0];
    return workoutDays.find(d => d.date === dateStr);
  };

  const previousMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1));
  };

  const getMonthStats = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    
    const monthWorkouts = workoutDays.filter(d => {
      const workoutDate = new Date(d.date);
      return workoutDate.getFullYear() === year && 
             workoutDate.getMonth() === month &&
             d.completed;
    });

    return {
      completed: monthWorkouts.length,
      currentStreak: calculateStreak(),
      totalExercises: monthWorkouts.reduce((sum, d) => sum + (d.exercises || 0), 0)
    };
  };

  const calculateStreak = () => {
    const sortedDays = workoutDays
      .filter(d => d.completed)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    let streak = 0;
    let currentDate = new Date();
    currentDate.setHours(0, 0, 0, 0);

    for (const day of sortedDays) {
      const dayDate = new Date(day.date);
      dayDate.setHours(0, 0, 0, 0);
      
      const diffDays = Math.floor((currentDate.getTime() - dayDate.getTime()) / (1000 * 60 * 60 * 24));
      
      if (diffDays === streak) {
        streak++;
      } else if (diffDays > streak) {
        break;
      }
    }

    return streak;
  };

  const days = getDaysInMonth(currentDate);
  const stats = getMonthStats();

  if (loading) {
    return (
      <Card className="p-6 bg-white/5 border-white/10">
        <p className="text-white/60 text-center">Loading calendar...</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-white mb-2 flex items-center gap-2">
            <CalendarIcon className="w-6 h-6 text-purple-400" />
            Workout Calendar
          </h2>
          <p className="text-white/60">Track your workout consistency</p>
        </div>
      </div>

      {/* Monthly Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-6 bg-white/5 border-white/10">
          <div className="flex items-center gap-3 mb-2">
            <CheckCircle className="w-5 h-5 text-green-400" />
            <span className="text-white/60">This Month</span>
          </div>
          <p className="text-white text-2xl">{stats.completed} workouts</p>
        </Card>

        <Card className="p-6 bg-white/5 border-white/10">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-5 h-5 text-orange-400">🔥</div>
            <span className="text-white/60">Current Streak</span>
          </div>
          <p className="text-white text-2xl">{stats.currentStreak} days</p>
        </Card>

        <Card className="p-6 bg-white/5 border-white/10">
          <div className="flex items-center gap-3 mb-2">
            <CalendarIcon className="w-5 h-5 text-blue-400" />
            <span className="text-white/60">Total Exercises</span>
          </div>
          <p className="text-white text-2xl">{stats.totalExercises}</p>
        </Card>
      </div>

      {/* Calendar */}
      <Card className="p-6 bg-white/5 border-white/10">
        {/* Month Navigation */}
        <div className="flex items-center justify-between mb-6">
          <Button onClick={previousMonth} className="bg-white/10 hover:bg-white/20" size="sm">
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <h3 className="text-white">
            {MONTHS[currentDate.getMonth()]} {currentDate.getFullYear()}
          </h3>
          <Button onClick={nextMonth} className="bg-white/10 hover:bg-white/20" size="sm">
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>

        {/* Day Headers */}
        <div className="grid grid-cols-7 gap-2 mb-2">
          {DAYS.map(day => (
            <div key={day} className="text-center text-white/60 text-sm py-2">
              {day}
            </div>
          ))}
        </div>

        {/* Calendar Grid */}
        <div className="grid grid-cols-7 gap-2">
          {days.map((day, index) => {
            const workout = getWorkoutForDate(day);
            const isToday = day && 
              day.toDateString() === new Date().toDateString();
            const isPast = day && day < new Date(new Date().setHours(0, 0, 0, 0));

            return (
              <button
                key={index}
                onClick={() => {
                  if (day) {
                    const dateStr = day.toISOString().split('T')[0];
                    toggleWorkoutDay(dateStr);
                  }
                }}
                disabled={!day}
                className={`
                  aspect-square p-2 rounded-lg relative transition-all
                  ${!day ? 'invisible' : ''}
                  ${isToday ? 'ring-2 ring-purple-500' : ''}
                  ${workout?.completed 
                    ? 'bg-gradient-to-br from-green-500/30 to-emerald-500/30 border border-green-500/50' 
                    : isPast 
                      ? 'bg-white/5 border border-white/10 opacity-50'
                      : 'bg-white/5 hover:bg-white/10 border border-white/10'
                  }
                `}
              >
                {day && (
                  <>
                    <span className={`text-sm ${workout?.completed ? 'text-white' : 'text-white/60'}`}>
                      {day.getDate()}
                    </span>
                    {workout?.completed && (
                      <div className="absolute top-1 right-1">
                        <CheckCircle className="w-4 h-4 text-green-400" />
                      </div>
                    )}
                    {workout?.workoutType && (
                      <div className="absolute bottom-1 left-1/2 -translate-x-1/2">
                        <div className="w-1 h-1 bg-purple-400 rounded-full" />
                      </div>
                    )}
                  </>
                )}
              </button>
            );
          })}
        </div>

        {/* Legend */}
        <div className="flex flex-wrap gap-4 mt-6 pt-6 border-t border-white/10">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-gradient-to-br from-green-500/30 to-emerald-500/30 border border-green-500/50 rounded" />
            <span className="text-white/60 text-sm">Completed</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-white/5 border border-white/10 rounded" />
            <span className="text-white/60 text-sm">Planned</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-white/5 border border-white/10 rounded opacity-50" />
            <span className="text-white/60 text-sm">Missed</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 border-2 border-purple-500 rounded" />
            <span className="text-white/60 text-sm">Today</span>
          </div>
        </div>
      </Card>

      {/* Consistency Tips */}
      <Card className="p-6 bg-gradient-to-r from-purple-500/10 to-pink-500/10 border-purple-500/30">
        <h3 className="text-white mb-3">💡 Consistency Tips</h3>
        <ul className="space-y-2 text-white/80 text-sm">
          <li>• Aim for at least 3-4 workouts per week</li>
          <li>• Schedule your workouts at the same time each day</li>
          <li>• Click on any day to mark it as completed</li>
          <li>• Build a streak to stay motivated!</li>
        </ul>
      </Card>
    </div>
  );
}
