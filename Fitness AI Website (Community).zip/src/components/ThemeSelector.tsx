import { Palette, Check } from 'lucide-react';
import { useState } from 'react';
import { themes } from '../utils/themes';
import { useTheme } from '../contexts/ThemeContext';

export function ThemeSelector() {
  const { theme, setTheme } = useTheme();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`flex items-center gap-2 px-4 py-2 bg-${theme.cardBg} hover:bg-white/20 text-${theme.textPrimary} rounded-lg transition-colors border border-${theme.cardBorder}`}
        style={{
          backgroundColor: 'rgba(255, 255, 255, 0.1)',
          borderColor: 'rgba(255, 255, 255, 0.2)',
        }}
      >
        <Palette className="w-4 h-4" />
        <span className="hidden sm:inline">Theme</span>
      </button>

      {isOpen && (
        <>
          {/* Backdrop */}
          <div
            className="fixed inset-0 z-[9998]"
            onClick={() => setIsOpen(false)}
          />
          
          {/* Dropdown */}
          <div
            className="absolute right-0 mt-2 w-64 rounded-xl shadow-xl z-[9999] overflow-hidden"
            style={{
              backgroundColor: 'rgba(0, 0, 0, 0.9)',
              border: '1px solid rgba(255, 255, 255, 0.2)',
            }}
          >
            <div className="p-3 border-b border-white/10">
              <p className="text-white text-sm">Choose Theme</p>
            </div>
            <div className="p-2 space-y-1 max-h-96 overflow-y-auto">
              {themes.map((t) => (
                <button
                  key={t.id}
                  onClick={() => {
                    setTheme(t.id);
                    setIsOpen(false);
                  }}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all hover:bg-white/10"
                >
                  {/* Color Preview */}
                  <div
                    className={`w-8 h-8 rounded-md bg-gradient-to-r ${t.buttonGradient} flex-shrink-0`}
                  />
                  
                  {/* Theme Name */}
                  <span className="text-white text-sm flex-1 text-left">
                    {t.name}
                  </span>
                  
                  {/* Check Mark */}
                  {theme.id === t.id && (
                    <Check className="w-4 h-4 text-green-400" />
                  )}
                </button>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
