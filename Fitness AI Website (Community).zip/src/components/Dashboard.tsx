import { UserData } from '../App';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { WorkoutPlanDraggable } from './WorkoutPlanDraggable';
import { MealPlan } from './MealPlan';
import { WorkoutTimer } from './WorkoutTimer';
import { ProgressTracker } from './ProgressTracker';
import { FeaturesHub } from './FeaturesHub';
import { User, Activity, Apple, Timer, Heart, Info } from 'lucide-react';

interface DashboardProps {
  userData: UserData;
  accessToken: string;
}

export function Dashboard({ userData, accessToken }: DashboardProps) {
  const bmi = (userData.weight / Math.pow(userData.height / 100, 2)).toFixed(1);
  
  const activityMultipliers: { [key: string]: number } = {
    'sedentary': 1.2,
    'light': 1.375,
    'moderate': 1.55,
    'active': 1.725,
    'very-active': 1.9,
  };

  const bmr = userData.gender === 'male'
    ? 88.362 + (13.397 * userData.weight) + (4.799 * userData.height) - (5.677 * userData.age)
    : 447.593 + (9.247 * userData.weight) + (3.098 * userData.height) - (4.330 * userData.age);

  const tdee = Math.round(bmr * activityMultipliers[userData.activityLevel]);

  // Generate workout plan data
  const generateWorkoutPlan = () => {
    const { goal, experience } = userData;

    // Base template - simplified for demonstration
    const beginnerWeightLoss = [
      {
        day: 'Monday',
        focus: 'Full Body',
        exercises: [
          { name: 'Bodyweight Squats', sets: 3, reps: '12-15', rest: 60, notes: 'Focus on form' },
          { name: 'Push-ups (modified if needed)', sets: 3, reps: '8-12', rest: 60 },
          { name: 'Dumbbell Rows', sets: 3, reps: '10-12', rest: 60 },
          { name: 'Plank', sets: 3, reps: '30-45 sec', rest: 60 },
          { name: 'Walking Lunges', sets: 3, reps: '10 each leg', rest: 60 },
        ],
      },
      {
        day: 'Wednesday',
        focus: 'Cardio & Core',
        exercises: [
          { name: 'Jump Rope', sets: 3, reps: '2 min', rest: 60 },
          { name: 'Mountain Climbers', sets: 3, reps: '20', rest: 45 },
          { name: 'Bicycle Crunches', sets: 3, reps: '15 each side', rest: 45 },
          { name: 'Burpees', sets: 3, reps: '10', rest: 60 },
          { name: 'Russian Twists', sets: 3, reps: '20', rest: 45 },
        ],
      },
      {
        day: 'Friday',
        focus: 'Full Body',
        exercises: [
          { name: 'Goblet Squats', sets: 3, reps: '12-15', rest: 60 },
          { name: 'Dumbbell Chest Press', sets: 3, reps: '10-12', rest: 60 },
          { name: 'Lat Pulldowns', sets: 3, reps: '10-12', rest: 60 },
          { name: 'Shoulder Press', sets: 3, reps: '10-12', rest: 60 },
          { name: 'Leg Raises', sets: 3, reps: '12-15', rest: 60 },
        ],
      },
    ];

    const intermediateMuscleBuild = [
      {
        day: 'Monday',
        focus: 'Chest & Triceps',
        exercises: [
          { name: 'Barbell Bench Press', sets: 4, reps: '8-10', rest: 90, notes: 'Progressive overload' },
          { name: 'Incline Dumbbell Press', sets: 4, reps: '10-12', rest: 75 },
          { name: 'Cable Flyes', sets: 3, reps: '12-15', rest: 60 },
          { name: 'Tricep Dips', sets: 3, reps: '10-12', rest: 60 },
          { name: 'Overhead Tricep Extension', sets: 3, reps: '12-15', rest: 60 },
        ],
      },
      {
        day: 'Tuesday',
        focus: 'Back & Biceps',
        exercises: [
          { name: 'Deadlifts', sets: 4, reps: '6-8', rest: 120, notes: 'Maintain proper form' },
          { name: 'Pull-ups', sets: 4, reps: '8-10', rest: 90 },
          { name: 'Barbell Rows', sets: 4, reps: '10-12', rest: 75 },
          { name: 'Barbell Curls', sets: 3, reps: '10-12', rest: 60 },
          { name: 'Hammer Curls', sets: 3, reps: '12-15', rest: 60 },
        ],
      },
      {
        day: 'Thursday',
        focus: 'Legs',
        exercises: [
          { name: 'Barbell Squats', sets: 4, reps: '8-10', rest: 120, notes: 'Go deep' },
          { name: 'Romanian Deadlifts', sets: 4, reps: '10-12', rest: 90 },
          { name: 'Leg Press', sets: 4, reps: '12-15', rest: 75 },
          { name: 'Leg Curls', sets: 3, reps: '12-15', rest: 60 },
          { name: 'Calf Raises', sets: 4, reps: '15-20', rest: 60 },
        ],
      },
      {
        day: 'Friday',
        focus: 'Shoulders & Core',
        exercises: [
          { name: 'Military Press', sets: 4, reps: '8-10', rest: 90 },
          { name: 'Lateral Raises', sets: 4, reps: '12-15', rest: 60 },
          { name: 'Front Raises', sets: 3, reps: '12-15', rest: 60 },
          { name: 'Face Pulls', sets: 3, reps: '15-20', rest: 60 },
          { name: 'Hanging Leg Raises', sets: 3, reps: '12-15', rest: 60 },
        ],
      },
    ];

    const advancedEndurance = [
      {
        day: 'Monday',
        focus: 'Upper Body Strength',
        exercises: [
          { name: 'Bench Press', sets: 5, reps: '5', rest: 180, notes: 'Heavy weight' },
          { name: 'Weighted Pull-ups', sets: 4, reps: '6-8', rest: 120 },
          { name: 'Overhead Press', sets: 4, reps: '6-8', rest: 120 },
          { name: 'Dips', sets: 3, reps: 'To failure', rest: 90 },
          { name: 'Face Pulls', sets: 3, reps: '15-20', rest: 60 },
        ],
      },
      {
        day: 'Tuesday',
        focus: 'HIIT Cardio',
        exercises: [
          { name: 'Sprint Intervals', sets: 8, reps: '30 sec sprint', rest: 90 },
          { name: 'Box Jumps', sets: 4, reps: '12', rest: 60 },
          { name: 'Battle Ropes', sets: 4, reps: '45 sec', rest: 60 },
          { name: 'Rowing Machine', sets: 4, reps: '500m', rest: 90 },
        ],
      },
      {
        day: 'Wednesday',
        focus: 'Lower Body Strength',
        exercises: [
          { name: 'Back Squats', sets: 5, reps: '5', rest: 180, notes: 'Heavy weight' },
          { name: 'Front Squats', sets: 4, reps: '6-8', rest: 120 },
          { name: 'Bulgarian Split Squats', sets: 4, reps: '8-10 each', rest: 90 },
          { name: 'Nordic Curls', sets: 3, reps: '6-8', rest: 120 },
          { name: 'Weighted Planks', sets: 3, reps: '60 sec', rest: 60 },
        ],
      },
      {
        day: 'Friday',
        focus: 'Full Body Circuit',
        exercises: [
          { name: 'Clean and Press', sets: 4, reps: '8', rest: 90 },
          { name: 'Thrusters', sets: 4, reps: '12', rest: 75 },
          { name: 'Kettlebell Swings', sets: 4, reps: '20', rest: 60 },
          { name: 'Pull-ups', sets: 4, reps: '10-12', rest: 75 },
          { name: 'Burpees', sets: 4, reps: '15', rest: 60 },
        ],
      },
      {
        day: 'Saturday',
        focus: 'Active Recovery',
        exercises: [
          { name: 'Light Jog', sets: 1, reps: '30 min', rest: 0 },
          { name: 'Yoga Flow', sets: 1, reps: '20 min', rest: 0 },
          { name: 'Stretching', sets: 1, reps: '15 min', rest: 0 },
        ],
      },
    ];

    // Simple logic to determine workout plan
    if (experience === 'beginner') {
      return beginnerWeightLoss;
    } else if (experience === 'intermediate') {
      return intermediateMuscleBuild;
    } else {
      return advancedEndurance;
    }
  };

  const workoutPlan = generateWorkoutPlan();

  return (
    <div className="space-y-6">
      {/* Welcome Message */}
      <Card className="p-6 bg-gradient-to-r from-purple-500/10 to-pink-500/10 border-purple-500/30 backdrop-blur-sm">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-white mb-2">Welcome back, {userData.name}! 👋</h2>
            <p className="text-purple-200">
              Your personalized fitness and nutrition plan is ready
            </p>
          </div>
          {(userData.medicalConditions.length > 0 || userData.dietaryRestrictions.length > 0) && (
            <div className="flex items-center gap-2 px-3 py-1 bg-blue-500/20 rounded-full">
              <Info className="w-4 h-4 text-blue-300" />
              <span className="text-blue-200 text-sm">Custom adjustments applied</span>
            </div>
          )}
        </div>
        
        {(userData.medicalConditions.length > 0 || userData.dietaryRestrictions.length > 0) && (
          <div className="mt-4 flex flex-wrap gap-2">
            {userData.medicalConditions.length > 0 && (
              <div className="flex items-center gap-2">
                <Heart className="w-4 h-4 text-amber-400" />
                <div className="flex flex-wrap gap-2">
                  {userData.medicalConditions.map((condition) => (
                    <Badge key={condition} className="bg-amber-500/20 text-amber-200 border-amber-500/30">
                      {condition}
                    </Badge>
                  ))}
                  {userData.otherMedicalConditions && (
                    <Badge className="bg-amber-500/20 text-amber-200 border-amber-500/30">
                      {userData.otherMedicalConditions}
                    </Badge>
                  )}
                </div>
              </div>
            )}
            {userData.dietaryRestrictions.length > 0 && (
              <div className="flex items-center gap-2">
                <Apple className="w-4 h-4 text-green-400" />
                <div className="flex flex-wrap gap-2">
                  {userData.dietaryRestrictions.map((restriction) => (
                    <Badge key={restriction} className="bg-green-500/20 text-green-200 border-green-500/30">
                      {restriction}
                    </Badge>
                  ))}
                  {userData.otherDietaryRestrictions && (
                    <Badge className="bg-green-500/20 text-green-200 border-green-500/30">
                      {userData.otherDietaryRestrictions}
                    </Badge>
                  )}
                </div>
              </div>
            )}
          </div>
        )}
      </Card>

      {/* User Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="p-6 bg-white/5 border-white/10 backdrop-blur-sm">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-purple-500/20 rounded-lg">
              <User className="w-5 h-5 text-purple-400" />
            </div>
            <span className="text-purple-200 text-sm">BMI</span>
          </div>
          <p className="text-white text-2xl">{bmi}</p>
        </Card>

        <Card className="p-6 bg-white/5 border-white/10 backdrop-blur-sm">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-pink-500/20 rounded-lg">
              <Activity className="w-5 h-5 text-pink-400" />
            </div>
            <span className="text-purple-200 text-sm">Daily Calories</span>
          </div>
          <p className="text-white text-2xl">{tdee}</p>
        </Card>

        <Card className="p-6 bg-white/5 border-white/10 backdrop-blur-sm">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-blue-500/20 rounded-lg">
              <Apple className="w-5 h-5 text-blue-400" />
            </div>
            <span className="text-purple-200 text-sm">Goal</span>
          </div>
          <p className="text-white capitalize">{userData.goal.replace('-', ' ')}</p>
        </Card>

        <Card className="p-6 bg-white/5 border-white/10 backdrop-blur-sm">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-green-500/20 rounded-lg">
              <Timer className="w-5 h-5 text-green-400" />
            </div>
            <span className="text-purple-200 text-sm">Experience</span>
          </div>
          <p className="text-white capitalize">{userData.experience}</p>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="workout" className="w-full">
        <TabsList className="grid w-full grid-cols-5 bg-white/5 border border-white/10">
          <TabsTrigger value="workout" className="data-[state=active]:bg-purple-500">
            Workout Plan
          </TabsTrigger>
          <TabsTrigger value="nutrition" className="data-[state=active]:bg-purple-500">
            Meal Plan
          </TabsTrigger>
          <TabsTrigger value="timer" className="data-[state=active]:bg-purple-500">
            Workout Timer
          </TabsTrigger>
          <TabsTrigger value="progress" className="data-[state=active]:bg-purple-500">
            Progress
          </TabsTrigger>
          <TabsTrigger value="features" className="data-[state=active]:bg-purple-500">
            All Features
          </TabsTrigger>
        </TabsList>

        <TabsContent value="workout" className="mt-6">
          <WorkoutPlanDraggable userData={userData} />
        </TabsContent>

        <TabsContent value="nutrition" className="mt-6">
          <MealPlan userData={userData} tdee={tdee} />
        </TabsContent>

        <TabsContent value="timer" className="mt-6">
          <WorkoutTimer workoutPlan={workoutPlan} />
        </TabsContent>

        <TabsContent value="progress" className="mt-6">
          <ProgressTracker accessToken={accessToken} />
        </TabsContent>

        <TabsContent value="features" className="mt-6">
          <FeaturesHub userData={userData} accessToken={accessToken} dailyCalories={tdee} />
        </TabsContent>
      </Tabs>
    </div>
  );
}