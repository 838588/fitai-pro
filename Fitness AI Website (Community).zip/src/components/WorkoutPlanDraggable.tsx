import { useState, useEffect } from 'react';
import { UserData } from '../App';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Checkbox } from './ui/checkbox';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from './ui/accordion';
import { Dumbbell, Clock, Repeat, Heart, GripVertical } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors, DragEndEvent } from '@dnd-kit/core';
import { arrayMove, SortableContext, sortableKeyboardCoordinates, verticalListSortingStrategy, useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

interface WorkoutPlanProps {
  userData: UserData;
  onExerciseComplete?: (dayIndex: number, exerciseIndex: number, isCompleted: boolean) => void;
}

export interface Exercise {
  id: string;
  name: string;
  sets: number;
  reps: string;
  rest: number;
  notes?: string;
  completed?: boolean;
}

export interface WorkoutDay {
  day: string;
  focus: string;
  exercises: Exercise[];
}

interface SortableExerciseProps {
  exercise: Exercise;
  exerciseIndex: number;
  dayIndex: number;
  theme: any;
  onToggleComplete: (completed: boolean) => void;
}

function SortableExercise({ exercise, theme, onToggleComplete }: SortableExerciseProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: exercise.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="p-4 bg-white/5 rounded-lg border border-white/10 flex items-start gap-3"
    >
      {/* Drag Handle */}
      <div
        {...listeners}
        {...attributes}
        className="cursor-grab active:cursor-grabbing mt-1 text-gray-400 hover:text-white transition-colors"
      >
        <GripVertical className="w-5 h-5" />
      </div>

      {/* Checkbox */}
      <div className="mt-1">
        <Checkbox
          checked={exercise.completed || false}
          onCheckedChange={(checked) => onToggleComplete(checked as boolean)}
          className="border-white/30 data-[state=checked]:bg-green-500 data-[state=checked]:border-green-500"
        />
      </div>

      {/* Exercise Info */}
      <div className="flex-1">
        <div className="flex items-start justify-between mb-2">
          <div className="flex items-center gap-3">
            <Dumbbell className={`w-5 h-5 text-${theme.accent}`} />
            <span className={`text-white ${exercise.completed ? 'line-through opacity-60' : ''}`}>
              {exercise.name}
            </span>
          </div>
        </div>
        <div className={`flex items-center gap-6 text-sm text-${theme.textSecondary} ml-8`}>
          <div className="flex items-center gap-2">
            <Repeat className="w-4 h-4" />
            <span>{exercise.sets} sets × {exercise.reps} reps</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4" />
            <span>{exercise.rest}s rest</span>
          </div>
        </div>
        {exercise.notes && (
          <p className={`text-sm text-${theme.textSecondary} ml-8 mt-2 italic`}>
            Note: {exercise.notes}
          </p>
        )}
      </div>
    </div>
  );
}

export function WorkoutPlanDraggable({ userData, onExerciseComplete }: WorkoutPlanProps) {
  const { theme } = useTheme();
  const [workoutPlan, setWorkoutPlan] = useState<(WorkoutDay | null)[]>([]);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  useEffect(() => {
    const plan = generateWorkoutPlan();
    const completeWeek = createCompleteWeek(plan);
    setWorkoutPlan(completeWeek);
  }, [userData]);

  const generateWorkoutPlan = (): WorkoutDay[] => {
    const { goal, experience } = userData;

    // Helper to add unique IDs to exercises
    const addIds = (exercises: Omit<Exercise, 'id'>[]): Exercise[] => {
      return exercises.map((ex, idx) => ({
        ...ex,
        id: `${ex.name}-${idx}-${Math.random()}`,
        completed: false
      }));
    };

    const beginnerWeightLoss: WorkoutDay[] = [
      {
        day: 'Monday',
        focus: 'Full Body',
        exercises: addIds([
          { name: 'Bodyweight Squats', sets: 3, reps: '12-15', rest: 60, notes: 'Focus on form' },
          { name: 'Push-ups (modified if needed)', sets: 3, reps: '8-12', rest: 60 },
          { name: 'Dumbbell Rows', sets: 3, reps: '10-12', rest: 60 },
          { name: 'Plank', sets: 3, reps: '30-45 sec', rest: 60 },
          { name: 'Walking Lunges', sets: 3, reps: '10 each leg', rest: 60 },
        ]),
      },
      {
        day: 'Wednesday',
        focus: 'Cardio & Core',
        exercises: addIds([
          { name: 'Jump Rope', sets: 3, reps: '2 min', rest: 60 },
          { name: 'Mountain Climbers', sets: 3, reps: '20', rest: 45 },
          { name: 'Bicycle Crunches', sets: 3, reps: '15 each side', rest: 45 },
          { name: 'Burpees', sets: 3, reps: '10', rest: 60 },
          { name: 'Russian Twists', sets: 3, reps: '20', rest: 45 },
        ]),
      },
      {
        day: 'Friday',
        focus: 'Full Body',
        exercises: addIds([
          { name: 'Goblet Squats', sets: 3, reps: '12-15', rest: 60 },
          { name: 'Dumbbell Chest Press', sets: 3, reps: '10-12', rest: 60 },
          { name: 'Lat Pulldowns', sets: 3, reps: '10-12', rest: 60 },
          { name: 'Shoulder Press', sets: 3, reps: '10-12', rest: 60 },
          { name: 'Leg Raises', sets: 3, reps: '12-15', rest: 60 },
        ]),
      },
    ];

    const intermediateMuscleBuild: WorkoutDay[] = [
      {
        day: 'Monday',
        focus: 'Chest & Triceps',
        exercises: addIds([
          { name: 'Barbell Bench Press', sets: 4, reps: '8-10', rest: 90, notes: 'Progressive overload' },
          { name: 'Incline Dumbbell Press', sets: 4, reps: '10-12', rest: 75 },
          { name: 'Cable Flyes', sets: 3, reps: '12-15', rest: 60 },
          { name: 'Tricep Dips', sets: 3, reps: '10-12', rest: 60 },
          { name: 'Overhead Tricep Extension', sets: 3, reps: '12-15', rest: 60 },
        ]),
      },
      {
        day: 'Tuesday',
        focus: 'Back & Biceps',
        exercises: addIds([
          { name: 'Deadlifts', sets: 4, reps: '6-8', rest: 120, notes: 'Maintain proper form' },
          { name: 'Pull-ups', sets: 4, reps: '8-10', rest: 90 },
          { name: 'Barbell Rows', sets: 4, reps: '10-12', rest: 75 },
          { name: 'Barbell Curls', sets: 3, reps: '10-12', rest: 60 },
          { name: 'Hammer Curls', sets: 3, reps: '12-15', rest: 60 },
        ]),
      },
      {
        day: 'Thursday',
        focus: 'Legs',
        exercises: addIds([
          { name: 'Barbell Squats', sets: 4, reps: '8-10', rest: 120, notes: 'Go deep' },
          { name: 'Romanian Deadlifts', sets: 4, reps: '10-12', rest: 90 },
          { name: 'Leg Press', sets: 4, reps: '12-15', rest: 75 },
          { name: 'Leg Curls', sets: 3, reps: '12-15', rest: 60 },
          { name: 'Calf Raises', sets: 4, reps: '15-20', rest: 60 },
        ]),
      },
      {
        day: 'Friday',
        focus: 'Shoulders & Core',
        exercises: addIds([
          { name: 'Military Press', sets: 4, reps: '8-10', rest: 90 },
          { name: 'Lateral Raises', sets: 4, reps: '12-15', rest: 60 },
          { name: 'Front Raises', sets: 3, reps: '12-15', rest: 60 },
          { name: 'Face Pulls', sets: 3, reps: '15-20', rest: 60 },
          { name: 'Hanging Leg Raises', sets: 3, reps: '12-15', rest: 60 },
        ]),
      },
    ];

    const advancedEndurance: WorkoutDay[] = [
      {
        day: 'Monday',
        focus: 'Upper Body Strength',
        exercises: addIds([
          { name: 'Bench Press', sets: 5, reps: '5', rest: 180, notes: 'Heavy weight' },
          { name: 'Weighted Pull-ups', sets: 4, reps: '6-8', rest: 120 },
          { name: 'Overhead Press', sets: 4, reps: '6-8', rest: 120 },
          { name: 'Dips', sets: 3, reps: 'To failure', rest: 90 },
          { name: 'Face Pulls', sets: 3, reps: '15-20', rest: 60 },
        ]),
      },
      {
        day: 'Tuesday',
        focus: 'HIIT Cardio',
        exercises: addIds([
          { name: 'Sprint Intervals', sets: 8, reps: '30 sec sprint', rest: 90 },
          { name: 'Box Jumps', sets: 4, reps: '12', rest: 60 },
          { name: 'Battle Ropes', sets: 4, reps: '45 sec', rest: 60 },
          { name: 'Rowing Machine', sets: 4, reps: '500m', rest: 90 },
        ]),
      },
      {
        day: 'Wednesday',
        focus: 'Lower Body Strength',
        exercises: addIds([
          { name: 'Back Squats', sets: 5, reps: '5', rest: 180, notes: 'Heavy weight' },
          { name: 'Front Squats', sets: 4, reps: '6-8', rest: 120 },
          { name: 'Bulgarian Split Squats', sets: 4, reps: '8-10 each', rest: 90 },
          { name: 'Nordic Curls', sets: 3, reps: '6-8', rest: 120 },
          { name: 'Weighted Planks', sets: 3, reps: '60 sec', rest: 60 },
        ]),
      },
      {
        day: 'Friday',
        focus: 'Full Body Circuit',
        exercises: addIds([
          { name: 'Clean and Press', sets: 4, reps: '8', rest: 90 },
          { name: 'Thrusters', sets: 4, reps: '12', rest: 75 },
          { name: 'Kettlebell Swings', sets: 4, reps: '20', rest: 60 },
          { name: 'Pull-ups', sets: 4, reps: '10-12', rest: 75 },
          { name: 'Burpees', sets: 4, reps: '15', rest: 60 },
        ]),
      },
      {
        day: 'Saturday',
        focus: 'Active Recovery',
        exercises: addIds([
          { name: 'Light Jog', sets: 1, reps: '30 min', rest: 0 },
          { name: 'Yoga Flow', sets: 1, reps: '20 min', rest: 0 },
          { name: 'Stretching', sets: 1, reps: '15 min', rest: 0 },
        ]),
      },
    ];

    if (experience === 'beginner') {
      return beginnerWeightLoss;
    } else if (experience === 'intermediate') {
      return intermediateMuscleBuild;
    } else {
      return advancedEndurance;
    }
  };

  const createCompleteWeek = (plan: WorkoutDay[]): (WorkoutDay | null)[] => {
    const allDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const completeWeek: (WorkoutDay | null)[] = [];
    
    allDays.forEach(day => {
      const workoutDay = plan.find(p => p.day === day);
      if (workoutDay) {
        completeWeek.push(workoutDay);
      } else {
        completeWeek.push(null);
      }
    });
    
    return completeWeek;
  };

  const handleDragEnd = (event: DragEndEvent, dayIndex: number) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      setWorkoutPlan((prevPlan) => {
        const newPlan = [...prevPlan];
        const day = newPlan[dayIndex];
        
        if (day && day.exercises) {
          const oldIndex = day.exercises.findIndex((ex) => ex.id === active.id);
          const newIndex = day.exercises.findIndex((ex) => ex.id === over.id);
          
          day.exercises = arrayMove(day.exercises, oldIndex, newIndex);
        }
        
        return newPlan;
      });
    }
  };

  const handleToggleComplete = (dayIndex: number, exerciseIndex: number, completed: boolean) => {
    setWorkoutPlan((prevPlan) => {
      const newPlan = [...prevPlan];
      const day = newPlan[dayIndex];
      
      if (day && day.exercises) {
        day.exercises[exerciseIndex].completed = completed;
      }
      
      return newPlan;
    });

    if (onExerciseComplete) {
      onExerciseComplete(dayIndex, exerciseIndex, completed);
    }
  };

  const getHealthModifications = () => {
    const modifications: string[] = [];
    
    const allConditions = [...userData.medicalConditions];
    if (userData.otherMedicalConditions) {
      allConditions.push(userData.otherMedicalConditions);
    }
    
    if (allConditions.some(c => c.toLowerCase().includes('knee') || c.toLowerCase().includes('arthritis'))) {
      modifications.push('Avoid high-impact exercises like jumping. Focus on low-impact alternatives.');
    }
    if (allConditions.some(c => c.toLowerCase().includes('back'))) {
      modifications.push('Prioritize core strengthening. Avoid heavy deadlifts and exercises that strain the lower back.');
    }
    if (allConditions.some(c => c.toLowerCase().includes('heart') || c.toLowerCase().includes('hypertension') || c.toLowerCase().includes('blood pressure'))) {
      modifications.push('Monitor heart rate during workouts. Take longer rest periods and avoid excessive strain.');
    }
    if (allConditions.some(c => c.toLowerCase().includes('asthma'))) {
      modifications.push('Have your inhaler nearby. Warm up gradually and avoid extremely intense cardio.');
    }
    if (allConditions.some(c => c.toLowerCase().includes('diabetes'))) {
      modifications.push('Monitor blood sugar before and after workouts. Keep a snack handy in case of low blood sugar.');
    }
    
    if (userData.otherMedicalConditions) {
      modifications.push(`Custom condition noted: ${userData.otherMedicalConditions}. Please consult with your healthcare provider for specific exercise modifications.`);
    }
    
    return modifications;
  };

  const healthModifications = getHealthModifications();

  return (
    <div className="space-y-4">
      {userData.medicalConditions.length > 0 && (
        <Card className="p-6 bg-amber-500/10 border-amber-500/30 backdrop-blur-sm">
          <h4 className="text-amber-300 mb-3 flex items-center gap-2">
            <Heart className="w-5 h-5" />
            Important Health Considerations
          </h4>
          <div className="space-y-2">
            <p className="text-amber-200 text-sm mb-2">
              Based on your medical conditions: {userData.medicalConditions.join(', ')}
            </p>
            {healthModifications.length > 0 && (
              <ul className="space-y-1 text-amber-100 text-sm">
                {healthModifications.map((mod, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <span className="text-amber-400">•</span>
                    <span>{mod}</span>
                  </li>
                ))}
              </ul>
            )}
            <p className="text-amber-300 text-sm mt-3 italic">
              Always consult with your healthcare provider before starting any new exercise program.
            </p>
          </div>
        </Card>
      )}

      <Card className="p-6 bg-white/5 border-white/10 backdrop-blur-sm">
        <div className="mb-6">
          <h3 className="text-white mb-2">Your Personalized 7-Day Workout Plan</h3>
          <p className={`text-${theme.textSecondary}`}>
            Based on your {userData.experience} experience level and {userData.goal.replace('-', ' ')} goal
          </p>
          <p className={`text-${theme.textSecondary} text-sm mt-2`}>
            💡 Tip: Drag exercises to reorder them, and check them off as you complete them!
          </p>
        </div>

        <Accordion type="single" collapsible className="space-y-4">
          {workoutPlan.map((day, dayIndex) => {
            const dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
            const dayName = dayNames[dayIndex];
            
            if (!day) {
              return (
                <AccordionItem
                  key={dayIndex}
                  value={`day-${dayIndex}`}
                  className="border border-white/10 rounded-lg bg-white/5 px-4"
                >
                  <AccordionTrigger className={`text-white hover:text-${theme.accent}`}>
                    <div className="flex items-center gap-4">
                      <Badge className="bg-green-500">{dayName}</Badge>
                      <span className="text-green-300">Rest Day 💤</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="pt-4 p-4 bg-green-500/10 rounded-lg border border-green-500/20">
                      <p className="text-green-200">
                        Take this day to recover and let your muscles rebuild. Stay active with light stretching, walking, or yoga if you feel up to it!
                      </p>
                      <div className="mt-4 space-y-2 text-sm text-green-300">
                        <p>✓ Focus on hydration and nutrition</p>
                        <p>✓ Get quality sleep (7-9 hours)</p>
                        <p>✓ Light mobility work or foam rolling</p>
                        <p>✓ Reflect on this week's progress</p>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              );
            }
            
            return (
              <AccordionItem
                key={dayIndex}
                value={`day-${dayIndex}`}
                className="border border-white/10 rounded-lg bg-white/5 px-4"
              >
                <AccordionTrigger className={`text-white hover:text-${theme.accent}`}>
                  <div className="flex items-center gap-4">
                    <Badge className={`bg-${theme.primary}`}>{day.day}</Badge>
                    <span>{day.focus}</span>
                    <Badge className="bg-white/10 text-white text-xs ml-auto mr-4">
                      {day.exercises.filter(ex => ex.completed).length}/{day.exercises.length} ✓
                    </Badge>
                  </div>
                </AccordionTrigger>
                <AccordionContent>
                  <div className="pt-4 space-y-3">
                    <DndContext
                      sensors={sensors}
                      collisionDetection={closestCenter}
                      onDragEnd={(event) => handleDragEnd(event, dayIndex)}
                    >
                      <SortableContext
                        items={day.exercises.map(ex => ex.id)}
                        strategy={verticalListSortingStrategy}
                      >
                        {day.exercises.map((exercise, exerciseIndex) => (
                          <SortableExercise
                            key={exercise.id}
                            exercise={exercise}
                            exerciseIndex={exerciseIndex}
                            dayIndex={dayIndex}
                            theme={theme}
                            onToggleComplete={(completed) => 
                              handleToggleComplete(dayIndex, exerciseIndex, completed)
                            }
                          />
                        ))}
                      </SortableContext>
                    </DndContext>
                  </div>
                </AccordionContent>
              </AccordionItem>
            );
          })}
        </Accordion>
      </Card>
    </div>
  );
}
