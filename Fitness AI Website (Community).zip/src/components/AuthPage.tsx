import { useState } from 'react';
import { Dumbbell, Mail, Lock, User } from 'lucide-react';
import { createClient } from '../utils/supabase/client';
import { projectId, publicAnonKey } from '../utils/supabase/info';
import { useTheme } from '../contexts/ThemeContext';
import { ThemeSelector } from './ThemeSelector';

interface AuthPageProps {
  onAuthSuccess: (accessToken: string, userName: string) => void;
}

export function AuthPage({ onAuthSuccess }: AuthPageProps) {
  const { theme } = useTheme();
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (isSignUp) {
        // Sign up
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-eb0ee345/signup`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${publicAnonKey}`
            },
            body: JSON.stringify({ email, password, name })
          }
        );

        const data = await response.json();

        if (!response.ok) {
          console.log(`Sign up error: ${data.error}`);
          setError(data.error || 'Failed to sign up');
          setLoading(false);
          return;
        }

        // After successful signup, automatically sign in
        const supabase = createClient();
        const { data: signInData, error: signInError } = await supabase.auth.signInWithPassword({
          email,
          password
        });

        if (signInError) {
          console.log(`Sign in error after sign up: ${signInError.message}`);
          setError('Account created! Please sign in.');
          setIsSignUp(false);
          setLoading(false);
          return;
        }

        if (signInData.session) {
          console.log('Sign up and sign in successful');
          onAuthSuccess(signInData.session.access_token, name || email);
        }
      } else {
        // Sign in
        const supabase = createClient();
        const { data, error: signInError } = await supabase.auth.signInWithPassword({
          email,
          password
        });

        if (signInError) {
          console.log(`Sign in error: ${signInError.message}`);
          setError(signInError.message);
          setLoading(false);
          return;
        }

        if (data.session) {
          console.log('Sign in successful');
          const userName = data.user.user_metadata?.name || email;
          onAuthSuccess(data.session.access_token, userName);
        }
      }
    } catch (err) {
      console.log(`Unexpected auth error: ${err}`);
      setError('An unexpected error occurred');
      setLoading(false);
    }
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br ${theme.gradient} flex items-center justify-center px-4`}>
      <div className="max-w-md w-full">
        {/* Theme Selector - Floating */}
        <div className="absolute top-4 right-4">
          <ThemeSelector />
        </div>

        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-3 mb-4">
            <div className={`bg-gradient-to-br ${theme.buttonGradient} p-3 rounded-xl`}>
              <Dumbbell className={`w-8 h-8 text-${theme.textPrimary}`} />
            </div>
            <div>
              <h1 className={`text-${theme.textPrimary} text-3xl`}>FitAI Pro</h1>
              <p className={`text-${theme.textSecondary} text-sm`}>AI-Powered Fitness & Nutrition</p>
            </div>
          </div>
        </div>

        {/* Auth Form */}
        <div className={`bg-${theme.cardBg} backdrop-blur-md rounded-2xl p-8 border border-${theme.cardBorder} shadow-xl`}
          style={{ backgroundColor: 'rgba(255, 255, 255, 0.1)', borderColor: 'rgba(255, 255, 255, 0.2)' }}>
          <h2 className={`text-2xl text-${theme.textPrimary} mb-6 text-center`}>
            {isSignUp ? 'Create Account' : 'Welcome Back'}
          </h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            {isSignUp && (
              <div>
                <label className={`block text-${theme.textSecondary} text-sm mb-2`}>
                  Name
                </label>
                <div className="relative">
                  <User className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-${theme.textSecondary}`} />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className={`w-full bg-white/5 border border-white/20 rounded-lg px-10 py-3 text-${theme.textPrimary} placeholder-${theme.textSecondary}/50 focus:outline-none focus:border-${theme.accent} focus:ring-2 focus:ring-${theme.accent}/20`}
                    placeholder="Your name"
                  />
                </div>
              </div>
            )}

            <div>
              <label className={`block text-${theme.textSecondary} text-sm mb-2`}>
                Email
              </label>
              <div className="relative">
                <Mail className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-${theme.textSecondary}`} />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={`w-full bg-white/5 border border-white/20 rounded-lg px-10 py-3 text-${theme.textPrimary} placeholder-${theme.textSecondary}/50 focus:outline-none focus:border-${theme.accent} focus:ring-2 focus:ring-${theme.accent}/20`}
                  placeholder="your@email.com"
                  required
                />
              </div>
            </div>

            <div>
              <label className={`block text-${theme.textSecondary} text-sm mb-2`}>
                Password
              </label>
              <div className="relative">
                <Lock className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-${theme.textSecondary}`} />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className={`w-full bg-white/5 border border-white/20 rounded-lg px-10 py-3 text-${theme.textPrimary} placeholder-${theme.textSecondary}/50 focus:outline-none focus:border-${theme.accent} focus:ring-2 focus:ring-${theme.accent}/20`}
                  placeholder="••••••••"
                  required
                  minLength={6}
                />
              </div>
            </div>

            {error && (
              <div className="bg-red-500/20 border border-red-500/50 rounded-lg p-3 text-red-200 text-sm">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className={`w-full bg-gradient-to-r ${theme.buttonGradient} hover:${theme.buttonHover} text-${theme.textPrimary} py-3 rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed`}
            >
              {loading ? 'Please wait...' : isSignUp ? 'Sign Up' : 'Sign In'}
            </button>
          </form>

          <div className="mt-6 text-center">
            <button
              onClick={() => {
                setIsSignUp(!isSignUp);
                setError('');
              }}
              className={`text-${theme.textSecondary} hover:text-${theme.textPrimary} text-sm transition-colors`}
            >
              {isSignUp ? 'Already have an account? Sign in' : "Don't have an account? Sign up"}
            </button>
          </div>
        </div>

        <p className={`text-${theme.textSecondary}/60 text-xs text-center mt-6`}>
          Your health data is securely stored and never shared with third parties.
        </p>
      </div>
    </div>
  );
}
