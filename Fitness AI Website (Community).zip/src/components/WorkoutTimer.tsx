import { useState, useEffect, useRef } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { Checkbox } from './ui/checkbox';
import { Play, Pause, RotateCcw, Timer, CheckCircle2, Dumbbell, Clock, ChevronRight } from 'lucide-react';
import { projectId } from '../utils/supabase/info';
import { toast } from 'sonner@2.0.3';

interface Exercise {
  name: string;
  sets: number;
  reps: string;
  rest: number;
  notes?: string;
}

interface WorkoutDay {
  day: string;
  focus: string;
  exercises: Exercise[];
}

interface WorkoutTimerProps {
  workoutPlan?: WorkoutDay[];
  selectedDay?: number;
  accessToken?: string;
}

type ExercisePhase = 'idle' | 'counting' | 'resting' | 'completed';

export function WorkoutTimer({ workoutPlan, selectedDay = 0, accessToken }: WorkoutTimerProps) {
  const [workoutStarted, setWorkoutStarted] = useState(false);
  const [currentExerciseIndex, setCurrentExerciseIndex] = useState(0);
  const [currentSet, setCurrentSet] = useState(0);
  const [phase, setPhase] = useState<ExercisePhase>('idle');
  const [currentRep, setCurrentRep] = useState(0);
  const [restTimeRemaining, setRestTimeRemaining] = useState(0);
  const [sessionTime, setSessionTime] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [completedSets, setCompletedSets] = useState<{ [key: number]: number[] }>({});
  const [completedExercises, setCompletedExercises] = useState<Set<number>>(new Set());
  const [workoutLogged, setWorkoutLogged] = useState(false);

  const repIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const restIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const sessionIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const currentDay = workoutPlan?.[selectedDay];
  const currentExercise = currentDay?.exercises[currentExerciseIndex];

  // Cleanup intervals
  useEffect(() => {
    return () => {
      if (repIntervalRef.current) clearInterval(repIntervalRef.current);
      if (restIntervalRef.current) clearInterval(restIntervalRef.current);
      if (sessionIntervalRef.current) clearInterval(sessionIntervalRef.current);
    };
  }, []);

  // Session timer
  useEffect(() => {
    if (workoutStarted && !isPaused) {
      sessionIntervalRef.current = setInterval(() => {
        setSessionTime((prev) => prev + 1);
      }, 1000);
    } else {
      if (sessionIntervalRef.current) clearInterval(sessionIntervalRef.current);
    }

    return () => {
      if (sessionIntervalRef.current) clearInterval(sessionIntervalRef.current);
    };
  }, [workoutStarted, isPaused]);

  // Get exercise pacing based on type
  const getRepDuration = (exerciseName: string): number => {
    const name = exerciseName.toLowerCase();
    
    // Holds/Planks - return duration in milliseconds for each "rep" (second)
    if (name.includes('plank') || name.includes('hold')) {
      return 1000; // 1 second per count
    }
    
    // Heavy compound lifts - slower, controlled
    if (
      name.includes('squat') || 
      name.includes('deadlift') || 
      name.includes('bench press') ||
      name.includes('overhead press') ||
      name.includes('military press')
    ) {
      return 3500; // 3.5 seconds per rep
    }
    
    // Olympic lifts - explosive but controlled
    if (
      name.includes('clean') || 
      name.includes('snatch') ||
      name.includes('thruster')
    ) {
      return 3000; // 3 seconds per rep
    }
    
    // Moderate compound movements
    if (
      name.includes('row') || 
      name.includes('pull-up') ||
      name.includes('dip') ||
      name.includes('lunge') ||
      name.includes('press')
    ) {
      return 2500; // 2.5 seconds per rep
    }
    
    // Fast cardio movements
    if (
      name.includes('burpee') || 
      name.includes('jump') ||
      name.includes('mountain climber') ||
      name.includes('sprint')
    ) {
      return 2000; // 2 seconds per rep
    }
    
    // Isolation exercises - moderate pace
    if (
      name.includes('curl') || 
      name.includes('raise') ||
      name.includes('extension') ||
      name.includes('fly') ||
      name.includes('crunch')
    ) {
      return 2000; // 2 seconds per rep
    }
    
    // Default moderate pace
    return 2500;
  };

  const parseReps = (repsString: string): number => {
    // Handle ranges like "12-15" - take the max
    const rangeMatch = repsString.match(/(\d+)-(\d+)/);
    if (rangeMatch) {
      return parseInt(rangeMatch[2]);
    }
    
    // Handle time-based like "30-45 sec" or "2 min"
    const timeMatch = repsString.match(/(\d+)/);
    if (timeMatch && (repsString.includes('sec') || repsString.includes('min'))) {
      const value = parseInt(timeMatch[1]);
      return repsString.includes('min') ? value * 60 : value;
    }
    
    // Handle "To failure"
    if (repsString.toLowerCase().includes('failure')) {
      return 12; // Default for "to failure"
    }
    
    // Extract first number
    const match = repsString.match(/(\d+)/);
    return match ? parseInt(match[1]) : 12;
  };

  const isHoldExercise = (exerciseName: string): boolean => {
    const name = exerciseName.toLowerCase();
    return name.includes('plank') || name.includes('hold');
  };

  const startExercise = () => {
    if (!currentExercise) return;
    
    setPhase('counting');
    setCurrentRep(0);
    setIsPaused(false);
    
    const targetReps = parseReps(currentExercise.reps);
    const repDuration = getRepDuration(currentExercise.name);
    
    let repCount = 0;
    repIntervalRef.current = setInterval(() => {
      repCount++;
      setCurrentRep(repCount);
      
      if (repCount >= targetReps) {
        if (repIntervalRef.current) clearInterval(repIntervalRef.current);
        completeSet();
      }
    }, repDuration);
  };

  const completeSet = () => {
    // Mark set as completed
    const exerciseKey = currentExerciseIndex;
    setCompletedSets(prev => ({
      ...prev,
      [exerciseKey]: [...(prev[exerciseKey] || []), currentSet]
    }));

    // Check if all sets are done for this exercise
    if (currentSet + 1 >= currentExercise!.sets) {
      // Auto-check the completed exercise
      setCompletedExercises(prev => new Set([...prev, currentExerciseIndex]));
      
      // Move to next exercise or complete workout
      if (currentExerciseIndex + 1 >= currentDay!.exercises.length) {
        setPhase('completed');
        // Log workout to backend
        if (accessToken && !workoutLogged) {
          logWorkout();
        }
      } else {
        setPhase('idle');
        setCurrentExerciseIndex(prev => prev + 1);
        setCurrentSet(0);
      }
    } else {
      // Start rest period
      setPhase('resting');
      setRestTimeRemaining(currentExercise!.rest);
      
      restIntervalRef.current = setInterval(() => {
        setRestTimeRemaining(prev => {
          if (prev <= 1) {
            if (restIntervalRef.current) clearInterval(restIntervalRef.current);
            // Auto-advance to next set
            setCurrentSet(prevSet => prevSet + 1);
            setPhase('idle');
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
  };

  const skipRest = () => {
    if (restIntervalRef.current) clearInterval(restIntervalRef.current);
    setRestTimeRemaining(0);
    setCurrentSet(prev => prev + 1);
    setPhase('idle');
  };

  const pauseResume = () => {
    setIsPaused(!isPaused);
    if (!isPaused) {
      // Pause
      if (repIntervalRef.current) clearInterval(repIntervalRef.current);
      if (restIntervalRef.current) clearInterval(restIntervalRef.current);
    } else {
      // Resume based on current phase
      if (phase === 'counting') {
        const targetReps = parseReps(currentExercise!.reps);
        const repDuration = getRepDuration(currentExercise!.name);
        
        repIntervalRef.current = setInterval(() => {
          setCurrentRep(prev => {
            const newRep = prev + 1;
            if (newRep >= targetReps) {
              if (repIntervalRef.current) clearInterval(repIntervalRef.current);
              completeSet();
            }
            return newRep;
          });
        }, repDuration);
      } else if (phase === 'resting') {
        restIntervalRef.current = setInterval(() => {
          setRestTimeRemaining(prev => {
            if (prev <= 1) {
              if (restIntervalRef.current) clearInterval(restIntervalRef.current);
              setCurrentSet(prevSet => prevSet + 1);
              setPhase('idle');
              return 0;
            }
            return prev - 1;
          });
        }, 1000);
      }
    }
  };

  const resetWorkout = () => {
    if (repIntervalRef.current) clearInterval(repIntervalRef.current);
    if (restIntervalRef.current) clearInterval(restIntervalRef.current);
    if (sessionIntervalRef.current) clearInterval(sessionIntervalRef.current);
    
    setWorkoutStarted(false);
    setCurrentExerciseIndex(0);
    setCurrentSet(0);
    setPhase('idle');
    setCurrentRep(0);
    setRestTimeRemaining(0);
    setSessionTime(0);
    setIsPaused(false);
    setCompletedSets({});
    setCompletedExercises(new Set());
    setWorkoutLogged(false);
  };

  const logWorkout = async () => {
    if (!accessToken || !currentDay || workoutLogged) return;
    
    setWorkoutLogged(true);
    
    try {
      const workoutLog = {
        date: new Date().toISOString(),
        workoutDay: currentDay.day + ' - ' + currentDay.focus,
        exercisesCompleted: completedExercises.size,
        totalExercises: currentDay.exercises.length,
        duration: Math.floor(sessionTime / 60) // Convert to minutes
      };

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-eb0ee345/log-workout`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ workoutLog })
        }
      );

      if (response.ok) {
        toast.success('🎉 Workout logged! Great job!');
      } else {
        console.log('Failed to log workout');
      }
    } catch (err) {
      console.log(`Error logging workout: ${err}`);
    }
  };

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getWorkoutProgress = (): number => {
    if (!currentDay) return 0;
    const totalExercises = currentDay.exercises.length;
    const completedExercises = currentExerciseIndex;
    const currentExerciseProgress = currentExercise 
      ? (currentSet / currentExercise.sets)
      : 0;
    return ((completedExercises + currentExerciseProgress) / totalExercises) * 100;
  };

  // No workout plan available
  if (!workoutPlan || workoutPlan.length === 0) {
    return (
      <Card className="p-8 bg-white/5 border-white/10 backdrop-blur-sm max-w-2xl mx-auto text-center">
        <Timer className="w-16 h-16 text-purple-400 mx-auto mb-4" />
        <h3 className="text-white mb-2">No Workout Plan Available</h3>
        <p className="text-purple-200">
          Please complete your profile assessment to generate a personalized workout plan.
        </p>
      </Card>
    );
  }

  // Workout not started - Show day selection
  if (!workoutStarted) {
    return (
      <Card className="p-8 bg-white/5 border-white/10 backdrop-blur-sm max-w-3xl mx-auto">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full mb-4">
            <Timer className="w-8 h-8 text-white" />
          </div>
          <h3 className="text-white mb-2">Start Your Workout</h3>
          <p className="text-purple-200">Select a workout day to begin your guided session</p>
        </div>

        <div className="space-y-4 mb-6">
          {workoutPlan.map((day, index) => (
            <div
              key={index}
              className={`p-6 rounded-lg border cursor-pointer transition-all ${
                selectedDay === index
                  ? 'bg-purple-500/20 border-purple-500/50'
                  : 'bg-white/5 border-white/10 hover:bg-white/10'
              }`}
              onClick={() => {
                setCurrentExerciseIndex(0);
                setCurrentSet(0);
              }}
            >
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <Badge className="bg-purple-500">{day.day}</Badge>
                    <h4 className="text-white">{day.focus}</h4>
                  </div>
                  <p className="text-purple-300 text-sm">{day.exercises.length} exercises</p>
                </div>
                <ChevronRight className="w-6 h-6 text-purple-400" />
              </div>
            </div>
          ))}
        </div>

        <Button
          onClick={() => setWorkoutStarted(true)}
          className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white"
        >
          <Play className="w-5 h-5 mr-2" />
          Begin Workout Session
        </Button>
      </Card>
    );
  }

  // Workout completed
  if (phase === 'completed') {
    return (
      <Card className="p-8 bg-white/5 border-white/10 backdrop-blur-sm max-w-2xl mx-auto">
        <div className="text-center py-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-green-500 to-emerald-500 rounded-full mb-4">
            <CheckCircle2 className="w-10 h-10 text-white" />
          </div>
          <h3 className="text-white mb-2">Workout Complete!</h3>
          <p className="text-purple-200 mb-2">
            Excellent work! You completed {currentDay?.focus} - {currentDay?.exercises.length} exercises
          </p>
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 rounded-lg mb-6">
            <Clock className="w-5 h-5 text-purple-400" />
            <span className="text-white">Total Time: {formatTime(sessionTime)}</span>
          </div>
          <Button
            onClick={resetWorkout}
            className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white"
          >
            <RotateCcw className="w-5 h-5 mr-2" />
            Start New Workout
          </Button>
        </div>
      </Card>
    );
  }

  // Active workout session
  return (
    <Card className="p-8 bg-white/5 border-white/10 backdrop-blur-sm max-w-3xl mx-auto">
      {/* Header with session info */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-white">{currentDay?.focus}</h3>
          <p className="text-purple-300 text-sm">{currentDay?.day}</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 px-3 py-1 bg-white/10 rounded-lg">
            <Clock className="w-4 h-4 text-purple-400" />
            <span className="text-white text-sm">{formatTime(sessionTime)}</span>
          </div>
          <Button
            onClick={pauseResume}
            variant="outline"
            size="sm"
            className="bg-white/10 border-white/20 text-white hover:bg-white/20"
          >
            {isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
          </Button>
        </div>
      </div>

      {/* Overall progress */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-2">
          <span className="text-purple-200 text-sm">Workout Progress</span>
          <span className="text-white text-sm">
            Exercise {currentExerciseIndex + 1}/{currentDay?.exercises.length}
          </span>
        </div>
        <Progress value={getWorkoutProgress()} className="h-2" />
      </div>

      {/* Current Exercise Info */}
      <div className="mb-6 p-6 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-lg border border-purple-500/30">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3">
            <Dumbbell className="w-6 h-6 text-purple-400" />
            <div>
              <h4 className="text-white text-xl">{currentExercise?.name}</h4>
              <p className="text-purple-300 text-sm">
                {currentExercise?.sets} sets × {currentExercise?.reps} {isHoldExercise(currentExercise?.name || '') ? '' : 'reps'}
              </p>
            </div>
          </div>
          <Badge className="bg-purple-500">
            Set {currentSet + 1}/{currentExercise?.sets}
          </Badge>
        </div>
        {currentExercise?.notes && (
          <p className="text-purple-200 text-sm italic">💡 {currentExercise.notes}</p>
        )}
      </div>

      {/* Main Action Area */}
      {phase === 'idle' && (
        <div className="text-center py-12">
          <div className="mb-8">
            <div className="text-6xl mb-4">💪</div>
            <h4 className="text-white mb-2">Ready for Set {currentSet + 1}</h4>
            <p className="text-purple-200">
              {isHoldExercise(currentExercise?.name || '') 
                ? `Hold for ${currentExercise?.reps}`
                : `Target: ${currentExercise?.reps} reps`
              }
            </p>
          </div>
          <Button
            onClick={startExercise}
            disabled={isPaused}
            className="bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white px-8 py-6 text-lg"
          >
            <Play className="w-6 h-6 mr-2" />
            Start Set
          </Button>
        </div>
      )}

      {phase === 'counting' && !isPaused && (
        <div className="text-center py-12">
          <div className="mb-6">
            <div className="text-9xl text-white mb-4 animate-pulse">{currentRep}</div>
            <p className="text-purple-200 text-lg">
              {isHoldExercise(currentExercise?.name || '') ? 'seconds' : 'reps'}
            </p>
          </div>
          <Progress 
            value={(currentRep / parseReps(currentExercise?.reps || '12')) * 100} 
            className="h-3 mb-4"
          />
          <p className="text-purple-300">
            {isHoldExercise(currentExercise?.name || '') 
              ? 'Hold the position...' 
              : 'Keep your form tight...'
            }
          </p>
        </div>
      )}

      {phase === 'resting' && !isPaused && (
        <div className="text-center py-12 px-6 bg-blue-500/10 rounded-lg border border-blue-500/30">
          <Timer className="w-16 h-16 text-blue-400 mx-auto mb-4" />
          <h4 className="text-white mb-2">Rest Period</h4>
          <div className="text-7xl text-white mb-6">{formatTime(restTimeRemaining)}</div>
          <p className="text-blue-200 mb-6">Recover and prepare for your next set</p>
          <Button
            onClick={skipRest}
            variant="outline"
            className="bg-white/10 border-white/20 text-white hover:bg-white/20"
          >
            Skip Rest
          </Button>
        </div>
      )}

      {isPaused && (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">⏸️</div>
          <h4 className="text-white mb-2">Workout Paused</h4>
          <p className="text-purple-200">Press play to resume</p>
        </div>
      )}

      {/* Exercise Progress Indicator */}
      <div className="mt-8 pt-6 border-t border-white/10">
        <h5 className="text-white text-sm mb-3">Set Progress</h5>
        <div className="flex gap-2">
          {Array.from({ length: currentExercise?.sets || 0 }, (_, i) => (
            <div
              key={i}
              className={`flex-1 h-2 rounded-full ${
                completedSets[currentExerciseIndex]?.includes(i)
                  ? 'bg-green-500'
                  : i === currentSet
                  ? 'bg-purple-500 animate-pulse'
                  : 'bg-white/20'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Reset Button */}
      <Button
        onClick={resetWorkout}
        variant="outline"
        className="w-full mt-6 bg-white/5 border-white/20 text-white hover:bg-white/10"
      >
        <RotateCcw className="w-5 h-5 mr-2" />
        End Workout
      </Button>
    </Card>
  );
}