import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { 
  Scale, Trophy, Calendar, Apple, Droplet, Moon, BookOpen, Dumbbell, 
  Target, ChefHat, Utensils, Scan, MapPin, Pill, Award, Zap, 
  Quote, Download, Activity, ArrowLeft
} from 'lucide-react';
import { BodyMeasurements } from './BodyMeasurements';
import { PersonalRecords } from './PersonalRecords';
import { WorkoutCalendar } from './WorkoutCalendar';
import { NutritionLogger } from './NutritionLogger';
import { WaterTracker } from './WaterTracker';
import { SleepTracker } from './SleepTracker';
import { ExerciseLibrary } from './ExerciseLibrary';
import { CustomWorkoutBuilder } from './CustomWorkoutBuilder';
import { AchievementBadges } from './AchievementBadges';
import { MotivationalQuotes } from './MotivationalQuotes';
import { ExportData } from './ExportData';
import { MuscleMap } from './MuscleMap';
import { MealPrepPlanner } from './MealPrepPlanner';
import { RecipeDatabase } from './RecipeDatabase';
import { Challenges } from './Challenges';
import { UserData } from '../App';

interface FeaturesHubProps {
  userData: UserData;
  accessToken: string;
  dailyCalories: number;
}

type FeatureKey = 
  | 'body-measurements'
  | 'personal-records'
  | 'workout-calendar'
  | 'nutrition-logger'
  | 'water-tracker'
  | 'sleep-tracker'
  | 'exercise-library'
  | 'custom-builder'
  | 'meal-prep'
  | 'recipes'
  | 'achievements'
  | 'challenges'
  | 'quotes'
  | 'muscle-map'
  | 'export-data'
  | null;

interface Feature {
  key: FeatureKey;
  title: string;
  description: string;
  icon: any;
  color: string;
  category: string;
}

const features: Feature[] = [
  {
    key: 'body-measurements',
    title: 'Body Measurements',
    description: 'Track weight, body fat, and measurements',
    icon: Scale,
    color: 'from-blue-500 to-cyan-500',
    category: 'Tracking',
  },
  {
    key: 'personal-records',
    title: 'Personal Records',
    description: 'Log your PRs and track strength gains',
    icon: Trophy,
    color: 'from-yellow-500 to-orange-500',
    category: 'Tracking',
  },
  {
    key: 'workout-calendar',
    title: 'Workout Calendar',
    description: 'Visualize your training consistency',
    icon: Calendar,
    color: 'from-purple-500 to-pink-500',
    category: 'Tracking',
  },
  {
    key: 'nutrition-logger',
    title: 'Nutrition Logger',
    description: 'Track meals, calories, and macros',
    icon: Apple,
    color: 'from-green-500 to-emerald-500',
    category: 'Nutrition',
  },
  {
    key: 'water-tracker',
    title: 'Water Tracker',
    description: 'Monitor daily hydration',
    icon: Droplet,
    color: 'from-blue-400 to-cyan-400',
    category: 'Wellness',
  },
  {
    key: 'sleep-tracker',
    title: 'Sleep Tracker',
    description: 'Log sleep quality and duration',
    icon: Moon,
    color: 'from-indigo-500 to-purple-500',
    category: 'Wellness',
  },
  {
    key: 'exercise-library',
    title: 'Exercise Library',
    description: 'Learn proper form and technique',
    icon: BookOpen,
    color: 'from-purple-500 to-pink-500',
    category: 'Workouts',
  },
  {
    key: 'custom-builder',
    title: 'Custom Workout Builder',
    description: 'Create personalized workout plans',
    icon: Dumbbell,
    color: 'from-orange-500 to-red-500',
    category: 'Workouts',
  },
  {
    key: 'meal-prep',
    title: 'Meal Prep Planner',
    description: 'Plan weekly meals and shopping lists',
    icon: ChefHat,
    color: 'from-orange-500 to-amber-500',
    category: 'Nutrition',
  },
  {
    key: 'recipes',
    title: 'Recipe Database',
    description: 'Healthy recipes with nutrition info',
    icon: Utensils,
    color: 'from-green-500 to-teal-500',
    category: 'Nutrition',
  },
  {
    key: 'achievements',
    title: 'Achievement Badges',
    description: 'Unlock badges and track milestones',
    icon: Award,
    color: 'from-yellow-400 to-orange-400',
    category: 'Motivation',
  },
  {
    key: 'challenges',
    title: 'Fitness Challenges',
    description: 'Join 30-day challenges and compete',
    icon: Target,
    color: 'from-purple-500 to-indigo-500',
    category: 'Motivation',
  },
  {
    key: 'quotes',
    title: 'Daily Motivation',
    description: 'Get inspired with fitness quotes',
    icon: Quote,
    color: 'from-pink-500 to-rose-500',
    category: 'Motivation',
  },
  {
    key: 'muscle-map',
    title: '3D Muscle Map',
    description: 'Visualize muscles worked',
    icon: Activity,
    color: 'from-cyan-500 to-blue-500',
    category: 'Education',
  },
  {
    key: 'export-data',
    title: 'Export Data',
    description: 'Download your fitness data',
    icon: Download,
    color: 'from-gray-500 to-slate-500',
    category: 'Tools',
  },
];

export function FeaturesHub({ userData, accessToken, dailyCalories }: FeaturesHubProps) {
  const [selectedFeature, setSelectedFeature] = useState<FeatureKey>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'Tracking', 'Workouts', 'Nutrition', 'Wellness', 'Motivation', 'Education', 'Tools'];

  const filteredFeatures = selectedCategory === 'All'
    ? features
    : features.filter(f => f.category === selectedCategory);

  if (selectedFeature) {
    const feature = features.find(f => f.key === selectedFeature);
    return (
      <div className="space-y-6">
        <Button
          onClick={() => setSelectedFeature(null)}
          className="bg-white/10 hover:bg-white/20"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Features
        </Button>

        {selectedFeature === 'body-measurements' && <BodyMeasurements accessToken={accessToken} />}
        {selectedFeature === 'personal-records' && <PersonalRecords accessToken={accessToken} />}
        {selectedFeature === 'workout-calendar' && <WorkoutCalendar accessToken={accessToken} />}
        {selectedFeature === 'nutrition-logger' && <NutritionLogger accessToken={accessToken} dailyCalories={dailyCalories} />}
        {selectedFeature === 'water-tracker' && <WaterTracker accessToken={accessToken} />}
        {selectedFeature === 'sleep-tracker' && <SleepTracker accessToken={accessToken} />}
        {selectedFeature === 'exercise-library' && <ExerciseLibrary />}
        {selectedFeature === 'custom-builder' && <CustomWorkoutBuilder />}
        {selectedFeature === 'meal-prep' && <MealPrepPlanner />}
        {selectedFeature === 'recipes' && <RecipeDatabase />}
        {selectedFeature === 'achievements' && <AchievementBadges accessToken={accessToken} />}
        {selectedFeature === 'challenges' && <Challenges />}
        {selectedFeature === 'quotes' && <MotivationalQuotes />}
        {selectedFeature === 'muscle-map' && <MuscleMap />}
        {selectedFeature === 'export-data' && <ExportData userData={userData} accessToken={accessToken} />}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-white mb-2">Features & Tools</h2>
        <p className="text-white/60">Explore all available fitness tracking and planning tools</p>
      </div>

      {/* Category Filter */}
      <Card className="p-4 bg-white/5 border-white/10">
        <div className="flex flex-wrap gap-2">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-lg text-sm transition-all ${
                selectedCategory === cat
                  ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white'
                  : 'bg-white/10 text-white/60 hover:bg-white/20'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </Card>

      {/* Features Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredFeatures.map((feature) => {
          const Icon = feature.icon;
          return (
            <Card
              key={feature.key}
              onClick={() => setSelectedFeature(feature.key)}
              className="p-6 bg-white/5 border-white/10 hover:bg-white/10 cursor-pointer transition-all group"
            >
              <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${feature.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                <Icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-white mb-2">{feature.title}</h3>
              <p className="text-white/60 text-sm mb-3">{feature.description}</p>
              <div className="flex items-center justify-between">
                <span className="text-xs text-white/40">{feature.category}</span>
                <span className="text-purple-400 text-sm group-hover:translate-x-1 transition-transform">→</span>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Quick Stats */}
      <Card className="p-6 bg-gradient-to-r from-purple-500/10 to-pink-500/10 border-purple-500/30">
        <h3 className="text-white mb-4">✨ Feature Highlights</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="flex items-center gap-3">
            <div className="text-2xl">📊</div>
            <div>
              <p className="text-white">15 Total Features</p>
              <p className="text-white/60 text-sm">All tools you need</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-2xl">🎯</div>
            <div>
              <p className="text-white">Track Everything</p>
              <p className="text-white/60 text-sm">Comprehensive logging</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-2xl">🚀</div>
            <div>
              <p className="text-white">Stay Motivated</p>
              <p className="text-white/60 text-sm">Badges & achievements</p>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
