import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ChefHat, ShoppingCart, Calendar, Plus, Trash2 } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface MealPrepItem {
  id: string;
  name: string;
  meal: string;
  servings: number;
  prepTime: number;
  ingredients: string[];
  instructions: string[];
}

const sampleRecipes: MealPrepItem[] = [
  {
    id: '1',
    name: 'Grilled Chicken & Rice',
    meal: 'Lunch',
    servings: 5,
    prepTime: 45,
    ingredients: ['1 kg chicken breast', '2 cups brown rice', '2 tbsp olive oil', 'Spices'],
    instructions: ['Season chicken', 'Grill for 20 minutes', 'Cook rice', 'Portion into containers'],
  },
  {
    id: '2',
    name: 'Overnight Oats',
    meal: 'Breakfast',
    servings: 5,
    prepTime: 10,
    ingredients: ['2 cups oats', '2 cups almond milk', '2 tbsp honey', 'Berries'],
    instructions: ['Mix oats and milk', 'Add honey', 'Refrigerate overnight', 'Top with berries'],
  },
];

export function MealPrepPlanner() {
  const [weekPlan, setWeekPlan] = useState<MealPrepItem[]>([]);
  const [showRecipes, setShowRecipes] = useState(true);

  const addToWeek = (recipe: MealPrepItem) => {
    setWeekPlan([...weekPlan, { ...recipe, id: Date.now().toString() }]);
    toast.success('Added to meal prep plan!');
  };

  const removeFromWeek = (id: string) => {
    setWeekPlan(weekPlan.filter(item => item.id !== id));
  };

  const generateShoppingList = () => {
    const allIngredients = weekPlan.flatMap(item => item.ingredients);
    return [...new Set(allIngredients)];
  };

  const shoppingList = generateShoppingList();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-white mb-2 flex items-center gap-2">
            <ChefHat className="w-6 h-6 text-orange-400" />
            Meal Prep Planner
          </h2>
          <p className="text-white/60">Plan your weekly meal preparation</p>
        </div>
        <Button
          onClick={() => setShowRecipes(!showRecipes)}
          className="bg-gradient-to-r from-orange-500 to-red-500"
        >
          {showRecipes ? 'Hide' : 'Show'} Recipes
        </Button>
      </div>

      {/* Recipe Library */}
      {showRecipes && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {sampleRecipes.map(recipe => (
            <Card key={recipe.id} className="p-6 bg-white/5 border-white/10">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-white mb-2">{recipe.name}</h3>
                  <div className="flex gap-2">
                    <Badge className="bg-orange-500/20 text-orange-300 border-orange-500/30">
                      {recipe.meal}
                    </Badge>
                    <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30">
                      {recipe.servings} servings
                    </Badge>
                    <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30">
                      {recipe.prepTime} min
                    </Badge>
                  </div>
                </div>
              </div>

              <div className="mb-4">
                <p className="text-white/60 text-sm mb-2">Ingredients:</p>
                <ul className="text-white/80 text-sm space-y-1">
                  {recipe.ingredients.map((ing, i) => (
                    <li key={i}>• {ing}</li>
                  ))}
                </ul>
              </div>

              <Button
                onClick={() => addToWeek(recipe)}
                className="bg-green-500 hover:bg-green-600 w-full"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add to Week Plan
              </Button>
            </Card>
          ))}
        </div>
      )}

      {/* Weekly Plan */}
      {weekPlan.length > 0 && (
        <Card className="p-6 bg-white/5 border-white/10">
          <h3 className="text-white mb-4 flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            This Week's Meal Prep ({weekPlan.length} recipes)
          </h3>
          <div className="space-y-3">
            {weekPlan.map(item => (
              <div key={item.id} className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
                <div>
                  <p className="text-white mb-1">{item.name}</p>
                  <p className="text-white/60 text-sm">{item.servings} servings • {item.prepTime} min</p>
                </div>
                <Button
                  onClick={() => removeFromWeek(item.id)}
                  className="bg-red-500/20 hover:bg-red-500/30 text-red-300"
                  size="sm"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>

          <div className="mt-4 pt-4 border-t border-white/10">
            <p className="text-white/80 mb-2">
              Total prep time: {weekPlan.reduce((sum, item) => sum + item.prepTime, 0)} minutes
            </p>
            <p className="text-white/80">
              Total servings: {weekPlan.reduce((sum, item) => sum + item.servings, 0)}
            </p>
          </div>
        </Card>
      )}

      {/* Shopping List */}
      {shoppingList.length > 0 && (
        <Card className="p-6 bg-gradient-to-br from-green-500/20 to-emerald-500/20 border-green-500/30">
          <h3 className="text-white mb-4 flex items-center gap-2">
            <ShoppingCart className="w-5 h-5" />
            Shopping List
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {shoppingList.map((item, i) => (
              <div key={i} className="flex items-center gap-2 text-white/80">
                <div className="w-2 h-2 bg-green-400 rounded-full" />
                <span>{item}</span>
              </div>
            ))}
          </div>
          <Button
            onClick={() => {
              navigator.clipboard.writeText(shoppingList.join('\n'));
              toast.success('Shopping list copied to clipboard!');
            }}
            className="mt-4 bg-green-500 hover:bg-green-600"
          >
            Copy to Clipboard
          </Button>
        </Card>
      )}

      {weekPlan.length === 0 && !showRecipes && (
        <Card className="p-12 bg-white/5 border-white/10 text-center">
          <ChefHat className="w-12 h-12 text-white/40 mx-auto mb-4" />
          <p className="text-white/60 mb-4">No meals planned yet</p>
          <p className="text-white/40 text-sm">Add recipes to start planning your week!</p>
        </Card>
      )}
    </div>
  );
}
