import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Download, FileText, Database, Calendar } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface ExportDataProps {
  userData: any;
  accessToken: string;
}

export function ExportData({ userData, accessToken }: ExportDataProps) {
  const [exporting, setExporting] = useState(false);

  const exportToPDF = async (dataType: string) => {
    setExporting(true);
    toast.success(`Preparing ${dataType} export...`);
    
    // Simulate export
    setTimeout(() => {
      toast.success(`${dataType} exported successfully!`);
      setExporting(false);
    }, 1500);
  };

  const exportToCSV = (data: any[], filename: string) => {
    if (data.length === 0) {
      toast.error('No data to export');
      return;
    }

    // Convert to CSV
    const headers = Object.keys(data[0]).join(',');
    const rows = data.map(row => Object.values(row).join(',')).join('\n');
    const csv = `${headers}\n${rows}`;

    // Download
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${filename}_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    
    toast.success('CSV exported successfully!');
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-white mb-2 flex items-center gap-2">
          <Download className="w-6 h-6 text-purple-400" />
          Export Your Data
        </h2>
        <p className="text-white/60">Download your fitness data in various formats</p>
      </div>

      {/* Export Options */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="p-6 bg-white/5 border-white/10">
          <div className="flex items-center gap-3 mb-4">
            <FileText className="w-8 h-8 text-blue-400" />
            <div>
              <h3 className="text-white">Workout History</h3>
              <p className="text-white/60 text-sm">All your completed workouts</p>
            </div>
          </div>
          <div className="flex gap-3">
            <Button
              onClick={() => exportToPDF('Workout History')}
              disabled={exporting}
              className="bg-blue-500 hover:bg-blue-600 flex-1"
            >
              <Download className="w-4 h-4 mr-2" />
              PDF
            </Button>
            <Button
              onClick={() => exportToCSV([], 'workout_history')}
              className="bg-green-500 hover:bg-green-600 flex-1"
            >
              <Download className="w-4 h-4 mr-2" />
              CSV
            </Button>
          </div>
        </Card>

        <Card className="p-6 bg-white/5 border-white/10">
          <div className="flex items-center gap-3 mb-4">
            <Database className="w-8 h-8 text-purple-400" />
            <div>
              <h3 className="text-white">Progress Data</h3>
              <p className="text-white/60 text-sm">Body measurements & PRs</p>
            </div>
          </div>
          <div className="flex gap-3">
            <Button
              onClick={() => exportToPDF('Progress Data')}
              disabled={exporting}
              className="bg-purple-500 hover:bg-purple-600 flex-1"
            >
              <Download className="w-4 h-4 mr-2" />
              PDF
            </Button>
            <Button
              onClick={() => exportToCSV([], 'progress_data')}
              className="bg-green-500 hover:bg-green-600 flex-1"
            >
              <Download className="w-4 h-4 mr-2" />
              CSV
            </Button>
          </div>
        </Card>

        <Card className="p-6 bg-white/5 border-white/10">
          <div className="flex items-center gap-3 mb-4">
            <Calendar className="w-8 h-8 text-pink-400" />
            <div>
              <h3 className="text-white">Nutrition Log</h3>
              <p className="text-white/60 text-sm">Food intake & macros</p>
            </div>
          </div>
          <div className="flex gap-3">
            <Button
              onClick={() => exportToPDF('Nutrition Log')}
              disabled={exporting}
              className="bg-pink-500 hover:bg-pink-600 flex-1"
            >
              <Download className="w-4 h-4 mr-2" />
              PDF
            </Button>
            <Button
              onClick={() => exportToCSV([], 'nutrition_log')}
              className="bg-green-500 hover:bg-green-600 flex-1"
            >
              <Download className="w-4 h-4 mr-2" />
              CSV
            </Button>
          </div>
        </Card>

        <Card className="p-6 bg-white/5 border-white/10">
          <div className="flex items-center gap-3 mb-4">
            <Download className="w-8 h-8 text-orange-400" />
            <div>
              <h3 className="text-white">Complete Profile</h3>
              <p className="text-white/60 text-sm">All your fitness data</p>
            </div>
          </div>
          <Button
            onClick={() => {
              const dataStr = JSON.stringify(userData, null, 2);
              const blob = new Blob([dataStr], { type: 'application/json' });
              const url = window.URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = `fitness_profile_${new Date().toISOString().split('T')[0]}.json`;
              a.click();
              window.URL.revokeObjectURL(url);
              toast.success('Profile exported successfully!');
            }}
            className="bg-gradient-to-r from-orange-500 to-red-500 w-full"
          >
            <Download className="w-4 h-4 mr-2" />
            Export JSON
          </Button>
        </Card>
      </div>

      {/* Info Card */}
      <Card className="p-6 bg-gradient-to-r from-blue-500/10 to-purple-500/10 border-blue-500/30">
        <h3 className="text-white mb-3">📊 About Data Export</h3>
        <ul className="space-y-2 text-white/80 text-sm">
          <li>• <strong>PDF</strong> - Formatted reports perfect for printing</li>
          <li>• <strong>CSV</strong> - Spreadsheet format for detailed analysis</li>
          <li>• <strong>JSON</strong> - Complete raw data backup</li>
          <li>• All exports include data from your entire history</li>
        </ul>
      </Card>
    </div>
  );
}
