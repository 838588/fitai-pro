import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Search, ChefHat, Clock, Flame } from 'lucide-react';

interface Recipe {
  id: string;
  name: string;
  category: string;
  prepTime: number;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  ingredients: string[];
  instructions: string[];
  tags: string[];
}

const recipes: Recipe[] = [
  {
    id: '1',
    name: 'Grilled Chicken with Quinoa',
    category: 'High Protein',
    prepTime: 30,
    calories: 450,
    protein: 45,
    carbs: 35,
    fats: 12,
    ingredients: ['200g chicken breast', '100g quinoa', '1 tbsp olive oil', 'Mixed vegetables'],
    instructions: ['Season chicken', 'Grill for 15-20 min', 'Cook quinoa', 'Steam vegetables', 'Combine and serve'],
    tags: ['Lean', 'Post-Workout', 'Gluten-Free'],
  },
  {
    id: '2',
    name: 'Protein Smoothie Bowl',
    category: 'Breakfast',
    prepTime: 10,
    calories: 350,
    protein: 30,
    carbs: 40,
    fats: 8,
    ingredients: ['1 scoop protein powder', '1 banana', '1 cup berries', '1/2 cup oats', 'Almond milk'],
    instructions: ['Blend all ingredients', 'Pour into bowl', 'Top with granola and fruit'],
    tags: ['Quick', 'Vegetarian', 'Pre-Workout'],
  },
  {
    id: '3',
    name: 'Salmon with Sweet Potato',
    category: 'Balanced',
    prepTime: 35,
    calories: 520,
    protein: 38,
    carbs: 45,
    fats: 18,
    ingredients: ['180g salmon fillet', '1 large sweet potato', '2 cups broccoli', 'Lemon', 'Herbs'],
    instructions: ['Bake salmon at 200°C for 20 min', 'Roast sweet potato', 'Steam broccoli', 'Season with lemon'],
    tags: ['Omega-3', 'Complex Carbs', 'Anti-Inflammatory'],
  },
];

export function RecipeDatabase() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);

  const categories = ['All', 'High Protein', 'Breakfast', 'Balanced', 'Vegetarian', 'Low Carb'];

  const filteredRecipes = recipes.filter(recipe => {
    const matchesSearch = recipe.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         recipe.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = selectedCategory === 'All' || recipe.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-white mb-2 flex items-center gap-2">
          <ChefHat className="w-6 h-6 text-orange-400" />
          Recipe Database
        </h2>
        <p className="text-white/60">Healthy recipes with macros</p>
      </div>

      {/* Search and Filter */}
      <Card className="p-6 bg-white/5 border-white/10">
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40" />
            <Input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-white/10 border-white/20 text-white"
              placeholder="Search recipes or tags..."
            />
          </div>

          <div className="flex flex-wrap gap-2">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1 rounded-lg text-sm transition-all ${
                  selectedCategory === cat
                    ? 'bg-orange-500 text-white'
                    : 'bg-white/10 text-white/60 hover:bg-white/20'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </Card>

      {/* Recipes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredRecipes.map(recipe => (
          <Card
            key={recipe.id}
            onClick={() => setSelectedRecipe(recipe)}
            className="p-6 bg-white/5 border-white/10 hover:bg-white/10 cursor-pointer transition-all"
          >
            <div className="flex items-start justify-between mb-3">
              <h3 className="text-white">{recipe.name}</h3>
              <ChefHat className="w-5 h-5 text-orange-400" />
            </div>

            <Badge className="bg-orange-500/20 text-orange-300 border-orange-500/30 mb-3">
              {recipe.category}
            </Badge>

            <div className="grid grid-cols-2 gap-2 mb-3 text-sm">
              <div className="flex items-center gap-2 text-white/80">
                <Clock className="w-4 h-4" />
                <span>{recipe.prepTime} min</span>
              </div>
              <div className="flex items-center gap-2 text-white/80">
                <Flame className="w-4 h-4" />
                <span>{recipe.calories} cal</span>
              </div>
            </div>

            <div className="flex gap-2 text-xs text-white/60">
              <span>P: {recipe.protein}g</span>
              <span>C: {recipe.carbs}g</span>
              <span>F: {recipe.fats}g</span>
            </div>

            <div className="flex flex-wrap gap-1 mt-3">
              {recipe.tags.map(tag => (
                <span key={tag} className="text-xs px-2 py-1 bg-purple-500/20 text-purple-300 rounded">
                  {tag}
                </span>
              ))}
            </div>
          </Card>
        ))}
      </div>

      {/* Recipe Detail Modal */}
      {selectedRecipe && (
        <div 
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedRecipe(null)}
        >
          <Card 
            className="bg-gradient-to-br from-gray-900 to-black border-white/20 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h2 className="text-white mb-2">{selectedRecipe.name}</h2>
                  <Badge className="bg-orange-500/20 text-orange-300 border-orange-500/30">
                    {selectedRecipe.category}
                  </Badge>
                </div>
                <Button onClick={() => setSelectedRecipe(null)} className="bg-white/10" size="sm">
                  ✕
                </Button>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="p-4 bg-white/5 rounded-lg">
                  <p className="text-white/60 text-sm">Prep Time</p>
                  <p className="text-white text-xl">{selectedRecipe.prepTime} min</p>
                </div>
                <div className="p-4 bg-white/5 rounded-lg">
                  <p className="text-white/60 text-sm">Calories</p>
                  <p className="text-white text-xl">{selectedRecipe.calories}</p>
                </div>
              </div>

              <div className="mb-6">
                <h3 className="text-white mb-3">Macros</h3>
                <div className="grid grid-cols-3 gap-3">
                  <div className="p-3 bg-green-500/10 border border-green-500/20 rounded-lg">
                    <p className="text-green-300 text-sm">Protein</p>
                    <p className="text-white">{selectedRecipe.protein}g</p>
                  </div>
                  <div className="p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                    <p className="text-blue-300 text-sm">Carbs</p>
                    <p className="text-white">{selectedRecipe.carbs}g</p>
                  </div>
                  <div className="p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                    <p className="text-yellow-300 text-sm">Fats</p>
                    <p className="text-white">{selectedRecipe.fats}g</p>
                  </div>
                </div>
              </div>

              <div className="mb-6">
                <h3 className="text-white mb-3">Ingredients</h3>
                <ul className="space-y-2">
                  {selectedRecipe.ingredients.map((ing, i) => (
                    <li key={i} className="flex gap-2 text-white/80">
                      <span className="text-purple-400">•</span>
                      <span>{ing}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h3 className="text-white mb-3">Instructions</h3>
                <ol className="space-y-2">
                  {selectedRecipe.instructions.map((step, i) => (
                    <li key={i} className="flex gap-3 text-white/80">
                      <span className="flex-shrink-0 w-6 h-6 rounded-full bg-purple-500/20 text-purple-300 flex items-center justify-center text-sm">
                        {i + 1}
                      </span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ol>
              </div>
            </div>
          </Card>
        </div>
      )}

      {filteredRecipes.length === 0 && (
        <Card className="p-12 bg-white/5 border-white/10 text-center">
          <ChefHat className="w-12 h-12 text-white/40 mx-auto mb-4" />
          <p className="text-white/60">No recipes found</p>
        </Card>
      )}
    </div>
  );
}
