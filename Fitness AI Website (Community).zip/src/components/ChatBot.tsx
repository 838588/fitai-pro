import { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Bot, User as UserIcon } from 'lucide-react';
import { UserData } from '../App';
import { useTheme } from '../contexts/ThemeContext';

interface ChatBotProps {
  userData: UserData;
}

interface Message {
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export function ChatBot({ userData }: ChatBotProps) {
  const { theme } = useTheme();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: `Hi ${userData.name}! 👋 I'm your AI fitness assistant. I can help you with workout tips, nutrition advice, form corrections, and answer any fitness-related questions!`,
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  const generateResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();
    
    // Personalized responses based on user data
    const { goal, experience, medicalConditions, dietaryRestrictions } = userData;
    
    // Workout-related questions
    if (lowerMessage.includes('workout') || lowerMessage.includes('exercise') || lowerMessage.includes('train')) {
      if (lowerMessage.includes('how often') || lowerMessage.includes('frequency')) {
        if (experience === 'beginner') {
          return `As a beginner aiming for ${goal.replace('-', ' ')}, I recommend working out 3-4 times per week. This gives your body enough time to recover while building consistency. Make sure to include rest days!`;
        } else if (experience === 'intermediate') {
          return `For intermediate level with your ${goal.replace('-', ' ')} goal, 4-5 workouts per week is ideal. Consider a split routine to target different muscle groups and allow proper recovery.`;
        } else {
          return `At an advanced level pursuing ${goal.replace('-', ' ')}, 5-6 workouts per week with strategic deload weeks will optimize your results. Listen to your body and prioritize recovery.`;
        }
      }
      
      if (lowerMessage.includes('rest') || lowerMessage.includes('recovery')) {
        return `Rest is crucial for muscle growth and preventing injury! Aim for 7-9 hours of sleep nightly. Active recovery like light walking or yoga on rest days can help. ${medicalConditions.length > 0 ? 'Given your health conditions, extra recovery time is even more important!' : ''}`;
      }
      
      if (lowerMessage.includes('cardio')) {
        if (goal === 'weight-loss') {
          return `For weight loss, combine 20-30 minutes of cardio 3-4x per week with your strength training. HIIT or moderate-intensity cardio works great. Don't overdo it though - you need energy for strength training!`;
        } else if (goal === 'muscle-gain') {
          return `For muscle gain, keep cardio to 2-3 sessions per week, 15-20 minutes max. Focus mainly on strength training. Light cardio helps with cardiovascular health without interfering with gains.`;
        } else {
          return `For general fitness and endurance, aim for 3-4 cardio sessions weekly. Mix up your cardio - running, cycling, swimming - to keep it interesting and work different muscle groups!`;
        }
      }
      
      return `Based on your ${experience} experience level and ${goal.replace('-', ' ')} goal, focus on progressive overload, proper form, and consistency. Your current plan is tailored to your needs!`;
    }
    
    // Nutrition questions
    if (lowerMessage.includes('diet') || lowerMessage.includes('nutrition') || lowerMessage.includes('eat') || lowerMessage.includes('food') || lowerMessage.includes('protein') || lowerMessage.includes('calorie')) {
      if (lowerMessage.includes('protein')) {
        if (goal === 'muscle-gain') {
          return `For muscle gain, aim for 1.6-2.2g of protein per kg of body weight. That's about ${Math.round(userData.weight * 1.8)}g daily for you. ${dietaryRestrictions.includes('Vegetarian') ? 'Great plant-based sources: tofu, tempeh, lentils, quinoa, and protein powder!' : 'Good sources: chicken, fish, eggs, Greek yogurt, and lean beef.'}`;
        } else if (goal === 'weight-loss') {
          return `During weight loss, protein is crucial to preserve muscle! Aim for 1.8-2.4g per kg of body weight - about ${Math.round(userData.weight * 2)}g daily. This keeps you full and maintains your metabolism. ${dietaryRestrictions.includes('Vegan') ? 'Focus on legumes, tofu, seitan, and plant-based protein powders!' : 'Prioritize lean proteins like chicken breast, fish, and egg whites.'}`;
        }
        return `A good baseline is 1.6-2.0g of protein per kg of body weight, so around ${Math.round(userData.weight * 1.8)}g for you. Spread it across your meals for better absorption!`;
      }
      
      if (lowerMessage.includes('calorie')) {
        const bmr = userData.gender === 'male'
          ? 88.362 + (13.397 * userData.weight) + (4.799 * userData.height) - (5.677 * userData.age)
          : 447.593 + (9.247 * userData.weight) + (3.098 * userData.height) - (4.330 * userData.age);
        
        const activityMultipliers: { [key: string]: number } = {
          'sedentary': 1.2,
          'light': 1.375,
          'moderate': 1.55,
          'active': 1.725,
          'very-active': 1.9,
        };
        
        const tdee = Math.round(bmr * activityMultipliers[userData.activityLevel]);
        
        if (goal === 'weight-loss') {
          return `For weight loss, aim for about ${tdee - 500} calories daily (500 cal deficit from your ${tdee} TDEE). Don't go below ${Math.round(bmr * 1.2)} calories to maintain your metabolism!`;
        } else if (goal === 'muscle-gain') {
          return `To build muscle, eat around ${tdee + 300} calories daily (300 cal surplus over your ${tdee} TDEE). This provides energy for muscle growth without excessive fat gain!`;
        }
        return `Your estimated daily calorie needs are around ${tdee} calories to maintain your current weight. Adjust based on your goals!`;
      }
      
      if (lowerMessage.includes('meal') || lowerMessage.includes('when')) {
        return `Meal timing is flexible, but here's what works well: Pre-workout (1-2hrs before): light carbs + protein. Post-workout (within 1hr): protein + carbs to refuel. Spread protein across 3-4 meals for optimal muscle protein synthesis. ${dietaryRestrictions.length > 0 ? `I see you have dietary restrictions (${dietaryRestrictions.join(', ')}), so plan meals accordingly!` : ''}`;
      }
      
      return `Nutrition is 70% of your results! Focus on whole foods, adequate protein, and staying consistent with your calorie goals. ${dietaryRestrictions.length > 0 ? `With your ${dietaryRestrictions.join(' and ')} preferences, there are plenty of delicious options available!` : ''}`;
    }
    
    // Form and technique
    if (lowerMessage.includes('form') || lowerMessage.includes('technique') || lowerMessage.includes('how to')) {
      return `Proper form is crucial for preventing injury and maximizing results! Key principles: 1) Start with lighter weights to master the movement, 2) Control the negative (lowering) phase, 3) Full range of motion when possible, 4) Keep core engaged, 5) Don't sacrifice form for heavier weight. Want specific tips for a particular exercise?`;
    }
    
    // Motivation
    if (lowerMessage.includes('motivat') || lowerMessage.includes('tired') || lowerMessage.includes('lazy') || lowerMessage.includes('skip')) {
      return `I believe in you! Remember why you started this journey. Every workout counts, even the ones where you don't feel 100%. Show up, do what you can, and you'll be proud you did. Your future self will thank you! 💪`;
    }
    
    // Progress tracking
    if (lowerMessage.includes('progress') || lowerMessage.includes('result') || lowerMessage.includes('long')) {
      return `Results take time - be patient! Beginners see noticeable changes in 4-8 weeks. Track your progress with photos, measurements, and strength gains, not just the scale. Progressive overload and consistency are key. Small improvements compound over time!`;
    }
    
    // Supplements
    if (lowerMessage.includes('supplement') || lowerMessage.includes('creatine') || lowerMessage.includes('protein powder')) {
      return `Supplements aren't magic, but some help! Protein powder is convenient for hitting protein goals. Creatine (5g daily) is well-researched for strength and muscle gain. Vitamin D, omega-3s, and a multivitamin can fill nutritional gaps. Always prioritize whole foods first! ${medicalConditions.length > 0 ? 'Consult your doctor before starting any supplements given your medical history.' : ''}`;
    }
    
    // Pain or injury
    if (lowerMessage.includes('pain') || lowerMessage.includes('hurt') || lowerMessage.includes('injury') || lowerMessage.includes('sore')) {
      if (lowerMessage.includes('sore') || lowerMessage.includes('doms')) {
        return `Muscle soreness (DOMS) is normal, especially when starting out! It usually peaks 24-48hrs after working out. Light movement, stretching, foam rolling, and proper nutrition help. Don't skip your next workout - light activity actually helps recovery!`;
      }
      return `⚠️ If you're experiencing pain (not just muscle soreness), stop that exercise immediately. Pain is your body's warning signal. Rest, ice, and consider seeing a healthcare professional if it persists. Never push through sharp or joint pain! ${medicalConditions.length > 0 ? 'This is especially important given your medical conditions.' : ''}`;
    }
    
    // Sleep
    if (lowerMessage.includes('sleep') || lowerMessage.includes('rest')) {
      return `Sleep is when your body repairs and grows muscle! Aim for 7-9 hours nightly. Tips: Keep a consistent sleep schedule, avoid screens 1hr before bed, keep room cool and dark, limit caffeine after 2pm. Quality sleep boosts recovery, performance, and fat loss!`;
    }
    
    // General fitness greetings
    if (lowerMessage.includes('hello') || lowerMessage.includes('hi ') || lowerMessage.includes('hey')) {
      return `Hey ${userData.name}! How can I help you with your fitness journey today? Ask me about workouts, nutrition, recovery, or anything fitness-related!`;
    }
    
    if (lowerMessage.includes('thank')) {
      return `You're welcome! Keep up the great work, ${userData.name}! Remember, consistency beats perfection. I'm here whenever you need guidance! 💪`;
    }
    
    // Default response
    return `That's a great question! I can help you with:\n\n• Workout tips and programming\n• Nutrition and meal planning\n• Exercise form and technique\n• Recovery and rest days\n• Motivation and progress tracking\n• Supplements\n• General fitness advice\n\nWhat would you like to know more about?`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    // Add user message
    const userMessage: Message = {
      role: 'user',
      content: input,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // Simulate typing delay
    setTimeout(() => {
      const response = generateResponse(input);
      const assistantMessage: Message = {
        role: 'assistant',
        content: response,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, assistantMessage]);
      setIsTyping(false);
    }, 800);
  };

  return (
    <>
      {/* Floating Chat Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className={`fixed bottom-6 right-6 z-[9999] w-14 h-14 rounded-full shadow-2xl flex items-center justify-center transition-all hover:scale-110 active:scale-95 bg-gradient-to-br ${theme.buttonGradient}`}
          style={{
            animation: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
          }}
        >
          <MessageCircle className={`w-6 h-6 text-${theme.textPrimary}`} />
        </button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 z-[9999] w-[calc(100vw-3rem)] sm:w-96 h-[600px] max-h-[80vh] rounded-2xl shadow-2xl overflow-hidden flex flex-col"
          style={{
            background: 'linear-gradient(to bottom, rgba(0, 0, 0, 0.95), rgba(0, 0, 0, 0.98))',
            border: '1px solid rgba(255, 255, 255, 0.1)',
          }}
        >
          {/* Header */}
          <div className={`p-4 bg-gradient-to-r ${theme.buttonGradient} flex items-center justify-between`}>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                <Bot className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-white">AI Fitness Coach</h3>
                <p className="text-white/80 text-xs">Always here to help!</p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-2 hover:bg-white/20 rounded-lg transition-colors"
            >
              <X className="w-5 h-5 text-white" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`flex gap-3 ${message.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  message.role === 'user' 
                    ? `bg-gradient-to-br ${theme.buttonGradient}` 
                    : 'bg-purple-500/20'
                }`}>
                  {message.role === 'user' ? (
                    <UserIcon className="w-4 h-4 text-white" />
                  ) : (
                    <Bot className="w-4 h-4 text-purple-300" />
                  )}
                </div>
                <div
                  className={`max-w-[75%] rounded-2xl p-3 ${
                    message.role === 'user'
                      ? `bg-gradient-to-br ${theme.buttonGradient} text-white`
                      : 'bg-white/10 text-white border border-white/10'
                  }`}
                >
                  <p className="text-sm whitespace-pre-line">{message.content}</p>
                  <span className="text-xs opacity-60 mt-1 block">
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center">
                  <Bot className="w-4 h-4 text-purple-300" />
                </div>
                <div className="bg-white/10 rounded-2xl p-3 border border-white/10">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 rounded-full bg-purple-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                    <div className="w-2 h-2 rounded-full bg-purple-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                    <div className="w-2 h-2 rounded-full bg-purple-400 animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <form onSubmit={handleSubmit} className="p-4 border-t border-white/10">
            <div className="flex gap-2">
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask me anything about fitness..."
                className="flex-1 px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder:text-white/40 focus:outline-none focus:ring-2 focus:ring-purple-500 text-sm"
              />
              <button
                type="submit"
                disabled={!input.trim() || isTyping}
                className={`p-3 rounded-xl bg-gradient-to-br ${theme.buttonGradient} text-white transition-all hover:scale-105 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100`}
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </form>
        </div>
      )}

      <style>
        {`
          @keyframes pulse {
            0%, 100% {
              opacity: 1;
            }
            50% {
              opacity: .8;
            }
          }
        `}
      </style>
    </>
  );
}
