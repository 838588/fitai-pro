import { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Progress } from './ui/progress';
import { Apple, Plus, Trash2, Search, Utensils } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { projectId } from '../utils/supabase/info';
import { toast } from 'sonner@2.0.3';

interface FoodEntry {
  id: string;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  meal: string;
  date: string;
}

interface DailyGoals {
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
}

interface NutritionLoggerProps {
  accessToken: string;
  dailyCalories: number;
}

const MEAL_TYPES = ['Breakfast', 'Lunch', 'Dinner', 'Snacks'];

export function NutritionLogger({ accessToken, dailyCalories }: NutritionLoggerProps) {
  const [entries, setEntries] = useState<FoodEntry[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [loading, setLoading] = useState(true);

  const [formData, setFormData] = useState({
    name: '',
    calories: '',
    protein: '',
    carbs: '',
    fats: '',
    meal: 'Breakfast',
  });

  const [dailyGoals] = useState<DailyGoals>({
    calories: dailyCalories,
    protein: Math.round(dailyCalories * 0.3 / 4), // 30% of calories from protein
    carbs: Math.round(dailyCalories * 0.4 / 4), // 40% from carbs
    fats: Math.round(dailyCalories * 0.3 / 9), // 30% from fats
  });

  useEffect(() => {
    loadEntries();
  }, []);

  const loadEntries = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-eb0ee345/nutrition-log`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${accessToken}`
          }
        }
      );

      const data = await response.json();
      if (response.ok && data.entries) {
        setEntries(data.entries);
      }
    } catch (err) {
      console.error('Error loading nutrition entries:', err);
    } finally {
      setLoading(false);
    }
  };

  const saveEntry = async () => {
    if (!formData.name || !formData.calories) {
      toast.error('Food name and calories are required');
      return;
    }

    const newEntry: FoodEntry = {
      id: Date.now().toString(),
      name: formData.name,
      calories: parseFloat(formData.calories),
      protein: parseFloat(formData.protein) || 0,
      carbs: parseFloat(formData.carbs) || 0,
      fats: parseFloat(formData.fats) || 0,
      meal: formData.meal,
      date: selectedDate,
    };

    try {
      const updatedEntries = [...entries, newEntry];

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-eb0ee345/nutrition-log`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`
          },
          body: JSON.stringify({ entries: updatedEntries })
        }
      );

      if (response.ok) {
        setEntries(updatedEntries);
        setShowForm(false);
        setFormData({
          name: '',
          calories: '',
          protein: '',
          carbs: '',
          fats: '',
          meal: 'Breakfast',
        });
        toast.success('Food logged successfully!');
      }
    } catch (err) {
      console.error('Error saving entry:', err);
      toast.error('Failed to save entry');
    }
  };

  const deleteEntry = async (id: string) => {
    const updatedEntries = entries.filter(e => e.id !== id);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-eb0ee345/nutrition-log`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`
          },
          body: JSON.stringify({ entries: updatedEntries })
        }
      );

      if (response.ok) {
        setEntries(updatedEntries);
        toast.success('Entry deleted');
      }
    } catch (err) {
      console.error('Error deleting entry:', err);
      toast.error('Failed to delete entry');
    }
  };

  const getTodayEntries = () => {
    return entries.filter(e => e.date === selectedDate);
  };

  const getTodayTotals = () => {
    const todayEntries = getTodayEntries();
    return {
      calories: todayEntries.reduce((sum, e) => sum + e.calories, 0),
      protein: todayEntries.reduce((sum, e) => sum + e.protein, 0),
      carbs: todayEntries.reduce((sum, e) => sum + e.carbs, 0),
      fats: todayEntries.reduce((sum, e) => sum + e.fats, 0),
    };
  };

  const getEntriesByMeal = () => {
    const todayEntries = getTodayEntries();
    const byMeal: { [key: string]: FoodEntry[] } = {};
    
    MEAL_TYPES.forEach(meal => {
      byMeal[meal] = todayEntries.filter(e => e.meal === meal);
    });

    return byMeal;
  };

  const totals = getTodayTotals();
  const entriesByMeal = getEntriesByMeal();

  const macroData = [
    { name: 'Protein', current: totals.protein, goal: dailyGoals.protein },
    { name: 'Carbs', current: totals.carbs, goal: dailyGoals.carbs },
    { name: 'Fats', current: totals.fats, goal: dailyGoals.fats },
  ];

  if (loading) {
    return (
      <Card className="p-6 bg-white/5 border-white/10">
        <p className="text-white/60 text-center">Loading nutrition log...</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-white mb-2 flex items-center gap-2">
            <Apple className="w-6 h-6 text-green-400" />
            Nutrition Logger
          </h2>
          <p className="text-white/60">Track your daily food intake</p>
        </div>
        <div className="flex gap-3">
          <Input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="bg-white/10 border-white/20 text-white w-auto"
          />
          <Button
            onClick={() => setShowForm(!showForm)}
            className="bg-gradient-to-r from-green-500 to-emerald-500"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Food
          </Button>
        </div>
      </div>

      {/* Daily Summary */}
      <Card className="p-6 bg-white/5 border-white/10">
        <h3 className="text-white mb-4">Daily Summary</h3>
        
        {/* Calories */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-white/80">Calories</span>
            <span className="text-white">
              {Math.round(totals.calories)} / {dailyGoals.calories}
            </span>
          </div>
          <Progress 
            value={(totals.calories / dailyGoals.calories) * 100} 
            className="h-3"
          />
          <div className="flex justify-between mt-1">
            <span className="text-white/60 text-sm">
              {dailyGoals.calories - Math.round(totals.calories)} remaining
            </span>
            <span className="text-white/60 text-sm">
              {Math.round((totals.calories / dailyGoals.calories) * 100)}%
            </span>
          </div>
        </div>

        {/* Macros */}
        <div className="grid grid-cols-3 gap-4">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-white/80 text-sm">Protein</span>
              <span className="text-white text-sm">{Math.round(totals.protein)}g</span>
            </div>
            <Progress 
              value={(totals.protein / dailyGoals.protein) * 100} 
              className="h-2"
            />
            <span className="text-white/60 text-xs">{dailyGoals.protein}g goal</span>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-white/80 text-sm">Carbs</span>
              <span className="text-white text-sm">{Math.round(totals.carbs)}g</span>
            </div>
            <Progress 
              value={(totals.carbs / dailyGoals.carbs) * 100} 
              className="h-2"
            />
            <span className="text-white/60 text-xs">{dailyGoals.carbs}g goal</span>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-white/80 text-sm">Fats</span>
              <span className="text-white text-sm">{Math.round(totals.fats)}g</span>
            </div>
            <Progress 
              value={(totals.fats / dailyGoals.fats) * 100} 
              className="h-2"
            />
            <span className="text-white/60 text-xs">{dailyGoals.fats}g goal</span>
          </div>
        </div>
      </Card>

      {/* Macro Chart */}
      {getTodayEntries().length > 0 && (
        <Card className="p-6 bg-white/5 border-white/10">
          <h3 className="text-white mb-4">Macro Breakdown</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={macroData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff20" />
              <XAxis dataKey="name" stroke="#ffffff60" />
              <YAxis stroke="#ffffff60" />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(0, 0, 0, 0.8)',
                  border: '1px solid rgba(255, 255, 255, 0.1)',
                  borderRadius: '8px',
                }}
              />
              <Legend />
              <Bar dataKey="current" fill="#10b981" name="Current (g)" />
              <Bar dataKey="goal" fill="#6366f1" name="Goal (g)" />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      )}

      {/* Add Food Form */}
      {showForm && (
        <Card className="p-6 bg-white/5 border-white/10">
          <h3 className="text-white mb-4">Log Food</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <Label className="text-white/80">Food Name *</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-white/10 border-white/20 text-white"
                placeholder="e.g., Grilled Chicken Breast"
              />
            </div>

            <div>
              <Label className="text-white/80">Meal *</Label>
              <select
                value={formData.meal}
                onChange={(e) => setFormData({ ...formData, meal: e.target.value })}
                className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
              >
                {MEAL_TYPES.map(meal => (
                  <option key={meal} value={meal}>{meal}</option>
                ))}
              </select>
            </div>

            <div>
              <Label className="text-white/80">Calories *</Label>
              <Input
                type="number"
                value={formData.calories}
                onChange={(e) => setFormData({ ...formData, calories: e.target.value })}
                className="bg-white/10 border-white/20 text-white"
                placeholder="250"
              />
            </div>

            <div>
              <Label className="text-white/80">Protein (g)</Label>
              <Input
                type="number"
                value={formData.protein}
                onChange={(e) => setFormData({ ...formData, protein: e.target.value })}
                className="bg-white/10 border-white/20 text-white"
                placeholder="30"
              />
            </div>

            <div>
              <Label className="text-white/80">Carbs (g)</Label>
              <Input
                type="number"
                value={formData.carbs}
                onChange={(e) => setFormData({ ...formData, carbs: e.target.value })}
                className="bg-white/10 border-white/20 text-white"
                placeholder="10"
              />
            </div>

            <div>
              <Label className="text-white/80">Fats (g)</Label>
              <Input
                type="number"
                value={formData.fats}
                onChange={(e) => setFormData({ ...formData, fats: e.target.value })}
                className="bg-white/10 border-white/20 text-white"
                placeholder="5"
              />
            </div>
          </div>

          <div className="flex gap-3 mt-6">
            <Button onClick={saveEntry} className="bg-gradient-to-r from-green-500 to-emerald-500">
              Save Entry
            </Button>
            <Button onClick={() => setShowForm(false)} className="bg-white/10">
              Cancel
            </Button>
          </div>
        </Card>
      )}

      {/* Meals by Type */}
      {getTodayEntries().length > 0 && (
        <div className="space-y-4">
          {MEAL_TYPES.map(mealType => {
            const mealEntries = entriesByMeal[mealType];
            if (mealEntries.length === 0) return null;

            const mealTotals = {
              calories: mealEntries.reduce((sum, e) => sum + e.calories, 0),
              protein: mealEntries.reduce((sum, e) => sum + e.protein, 0),
              carbs: mealEntries.reduce((sum, e) => sum + e.carbs, 0),
              fats: mealEntries.reduce((sum, e) => sum + e.fats, 0),
            };

            return (
              <Card key={mealType} className="p-6 bg-white/5 border-white/10">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <Utensils className="w-5 h-5 text-purple-400" />
                    <h3 className="text-white">{mealType}</h3>
                  </div>
                  <div className="text-white/60 text-sm">
                    {Math.round(mealTotals.calories)} cal
                  </div>
                </div>

                <div className="space-y-3">
                  {mealEntries.map(entry => (
                    <div
                      key={entry.id}
                      className="flex items-start justify-between p-4 bg-white/5 rounded-lg"
                    >
                      <div className="flex-1">
                        <p className="text-white">{entry.name}</p>
                        <div className="flex gap-4 mt-1 text-sm text-white/60">
                          <span>{entry.calories} cal</span>
                          {entry.protein > 0 && <span>P: {entry.protein}g</span>}
                          {entry.carbs > 0 && <span>C: {entry.carbs}g</span>}
                          {entry.fats > 0 && <span>F: {entry.fats}g</span>}
                        </div>
                      </div>
                      <Button
                        onClick={() => deleteEntry(entry.id)}
                        className="bg-red-500/20 hover:bg-red-500/30 text-red-300"
                        size="sm"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {getTodayEntries().length === 0 && !showForm && (
        <Card className="p-12 bg-white/5 border-white/10 text-center">
          <Apple className="w-12 h-12 text-white/40 mx-auto mb-4" />
          <p className="text-white/60 mb-4">No food logged for {new Date(selectedDate).toLocaleDateString()}</p>
          <p className="text-white/40 text-sm">Start tracking your nutrition to reach your goals!</p>
        </Card>
      )}
    </div>
  );
}
