import { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Moon, Plus, Trash2, TrendingUp, Calendar } from 'lucide-react';
import { projectId } from '../utils/supabase/info';
import { toast } from 'sonner@2.0.3';

interface SleepEntry {
  id: string;
  date: string;
  hours: number;
  quality: 'poor' | 'fair' | 'good' | 'excellent';
  notes?: string;
}

interface SleepTrackerProps {
  accessToken: string;
}

const SLEEP_GOAL = 8; // hours

export function SleepTracker({ accessToken }: SleepTrackerProps) {
  const [entries, setEntries] = useState<SleepEntry[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);

  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    hours: '',
    quality: 'good' as const,
    notes: '',
  });

  useEffect(() => {
    loadEntries();
  }, []);

  const loadEntries = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-eb0ee345/sleep-tracker`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${accessToken}`
          }
        }
      );

      const data = await response.json();
      if (response.ok && data.entries) {
        setEntries(data.entries);
      }
    } catch (err) {
      console.error('Error loading sleep entries:', err);
    } finally {
      setLoading(false);
    }
  };

  const saveEntry = async () => {
    if (!formData.hours) {
      toast.error('Sleep duration is required');
      return;
    }

    const newEntry: SleepEntry = {
      id: Date.now().toString(),
      date: formData.date,
      hours: parseFloat(formData.hours),
      quality: formData.quality,
      notes: formData.notes,
    };

    try {
      const updatedEntries = [...entries, newEntry].sort((a, b) =>
        new Date(a.date).getTime() - new Date(b.date).getTime()
      );

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-eb0ee345/sleep-tracker`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`
          },
          body: JSON.stringify({ entries: updatedEntries })
        }
      );

      if (response.ok) {
        setEntries(updatedEntries);
        setShowForm(false);
        setFormData({
          date: new Date().toISOString().split('T')[0],
          hours: '',
          quality: 'good',
          notes: '',
        });
        toast.success('Sleep logged successfully!');
      }
    } catch (err) {
      console.error('Error saving entry:', err);
      toast.error('Failed to save entry');
    }
  };

  const deleteEntry = async (id: string) => {
    const updatedEntries = entries.filter(e => e.id !== id);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-eb0ee345/sleep-tracker`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`
          },
          body: JSON.stringify({ entries: updatedEntries })
        }
      );

      if (response.ok) {
        setEntries(updatedEntries);
        toast.success('Entry deleted');
      }
    } catch (err) {
      console.error('Error deleting entry:', err);
      toast.error('Failed to delete entry');
    }
  };

  const getAverageHours = () => {
    if (entries.length === 0) return 0;
    const total = entries.reduce((sum, e) => sum + e.hours, 0);
    return (total / entries.length).toFixed(1);
  };

  const getWeeklyAverage = () => {
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    
    const weekEntries = entries.filter(e => new Date(e.date) >= weekAgo);
    if (weekEntries.length === 0) return 0;
    
    const total = weekEntries.reduce((sum, e) => sum + e.hours, 0);
    return (total / weekEntries.length).toFixed(1);
  };

  const getQualityScore = () => {
    if (entries.length === 0) return 0;
    
    const qualityScores = { poor: 1, fair: 2, good: 3, excellent: 4 };
    const total = entries.reduce((sum, e) => sum + qualityScores[e.quality], 0);
    return ((total / entries.length / 4) * 100).toFixed(0);
  };

  const getQualityColor = (quality: string) => {
    const colors = {
      poor: 'text-red-400',
      fair: 'text-yellow-400',
      good: 'text-green-400',
      excellent: 'text-purple-400',
    };
    return colors[quality as keyof typeof colors];
  };

  const getQualityBadgeColor = (quality: string) => {
    const colors = {
      poor: 'bg-red-500/20 text-red-300 border-red-500/30',
      fair: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
      good: 'bg-green-500/20 text-green-300 border-green-500/30',
      excellent: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
    };
    return colors[quality as keyof typeof colors];
  };

  if (loading) {
    return (
      <Card className="p-6 bg-white/5 border-white/10">
        <p className="text-white/60 text-center">Loading sleep tracker...</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-white mb-2 flex items-center gap-2">
            <Moon className="w-6 h-6 text-indigo-400" />
            Sleep Tracker
          </h2>
          <p className="text-white/60">Monitor your sleep quality and duration</p>
        </div>
        <Button
          onClick={() => setShowForm(!showForm)}
          className="bg-gradient-to-r from-indigo-500 to-purple-500"
        >
          <Plus className="w-4 h-4 mr-2" />
          Log Sleep
        </Button>
      </div>

      {/* Stats Overview */}
      {entries.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-6 bg-white/5 border-white/10">
            <div className="flex items-center gap-3 mb-2">
              <Moon className="w-5 h-5 text-indigo-400" />
              <span className="text-white/60">Last Night</span>
            </div>
            <p className="text-white text-2xl">
              {entries[entries.length - 1]?.hours.toFixed(1)} hrs
            </p>
          </Card>

          <Card className="p-6 bg-white/5 border-white/10">
            <div className="flex items-center gap-3 mb-2">
              <TrendingUp className="w-5 h-5 text-green-400" />
              <span className="text-white/60">Weekly Avg</span>
            </div>
            <p className="text-white text-2xl">{getWeeklyAverage()} hrs</p>
          </Card>

          <Card className="p-6 bg-white/5 border-white/10">
            <div className="flex items-center gap-3 mb-2">
              <Calendar className="w-5 h-5 text-blue-400" />
              <span className="text-white/60">Overall Avg</span>
            </div>
            <p className="text-white text-2xl">{getAverageHours()} hrs</p>
          </Card>

          <Card className="p-6 bg-white/5 border-white/10">
            <div className="flex items-center gap-3 mb-2">
              <div className="text-xl">⭐</div>
              <span className="text-white/60">Quality Score</span>
            </div>
            <p className="text-white text-2xl">{getQualityScore()}%</p>
          </Card>
        </div>
      )}

      {/* Add Sleep Form */}
      {showForm && (
        <Card className="p-6 bg-white/5 border-white/10">
          <h3 className="text-white mb-4">Log Sleep</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="text-white/80">Date *</Label>
              <Input
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="bg-white/10 border-white/20 text-white"
              />
            </div>

            <div>
              <Label className="text-white/80">Hours of Sleep *</Label>
              <Input
                type="number"
                step="0.5"
                value={formData.hours}
                onChange={(e) => setFormData({ ...formData, hours: e.target.value })}
                className="bg-white/10 border-white/20 text-white"
                placeholder="8.0"
              />
            </div>

            <div>
              <Label className="text-white/80">Sleep Quality *</Label>
              <select
                value={formData.quality}
                onChange={(e) => setFormData({ ...formData, quality: e.target.value as any })}
                className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white"
              >
                <option value="poor">Poor</option>
                <option value="fair">Fair</option>
                <option value="good">Good</option>
                <option value="excellent">Excellent</option>
              </select>
            </div>

            <div>
              <Label className="text-white/80">Notes</Label>
              <Input
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="bg-white/10 border-white/20 text-white"
                placeholder="Optional notes"
              />
            </div>
          </div>

          <div className="flex gap-3 mt-6">
            <Button onClick={saveEntry} className="bg-gradient-to-r from-indigo-500 to-purple-500">
              Save Entry
            </Button>
            <Button onClick={() => setShowForm(false)} className="bg-white/10">
              Cancel
            </Button>
          </div>
        </Card>
      )}

      {/* Sleep Chart */}
      {entries.length > 0 && (
        <Card className="p-6 bg-white/5 border-white/10">
          <h3 className="text-white mb-4">Sleep Duration Trend</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={entries.slice(-14)}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff20" />
              <XAxis 
                dataKey="date" 
                stroke="#ffffff60"
                tick={{ fill: '#ffffff60' }}
                tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
              />
              <YAxis 
                stroke="#ffffff60"
                tick={{ fill: '#ffffff60' }}
                domain={[0, 12]}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(0, 0, 0, 0.8)',
                  border: '1px solid rgba(255, 255, 255, 0.1)',
                  borderRadius: '8px',
                  color: '#fff'
                }}
              />
              <Legend wrapperStyle={{ color: '#fff' }} />
              <Line 
                type="monotone" 
                dataKey="hours" 
                stroke="#818cf8" 
                strokeWidth={2}
                dot={{ fill: '#818cf8', r: 4 }}
                name="Sleep (hours)"
              />
              <Line
                type="monotone"
                y={SLEEP_GOAL}
                stroke="#10b981"
                strokeDasharray="5 5"
                name="Goal"
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      )}

      {/* Sleep History */}
      {entries.length > 0 && (
        <Card className="p-6 bg-white/5 border-white/10">
          <h3 className="text-white mb-4">Sleep History</h3>
          <div className="space-y-3">
            {entries.slice().reverse().slice(0, 10).map((entry) => (
              <div
                key={entry.id}
                className="flex items-center justify-between p-4 bg-white/5 rounded-lg"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <p className="text-white">{new Date(entry.date).toLocaleDateString()}</p>
                    <span className={`px-2 py-1 rounded text-xs ${getQualityBadgeColor(entry.quality)}`}>
                      {entry.quality}
                    </span>
                  </div>
                  <div className="flex items-center gap-4 text-sm">
                    <span className={`${entry.hours >= SLEEP_GOAL ? 'text-green-400' : 'text-orange-400'}`}>
                      {entry.hours} hours
                    </span>
                    {entry.notes && (
                      <span className="text-white/60 italic">{entry.notes}</span>
                    )}
                  </div>
                </div>
                <Button
                  onClick={() => deleteEntry(entry.id)}
                  className="bg-red-500/20 hover:bg-red-500/30 text-red-300"
                  size="sm"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        </Card>
      )}

      {entries.length === 0 && !showForm && (
        <Card className="p-12 bg-white/5 border-white/10 text-center">
          <Moon className="w-12 h-12 text-white/40 mx-auto mb-4" />
          <p className="text-white/60 mb-4">No sleep data yet</p>
          <p className="text-white/40 text-sm">Start tracking your sleep to optimize recovery and performance</p>
        </Card>
      )}

      {/* Sleep Tips */}
      <Card className="p-6 bg-gradient-to-r from-indigo-500/10 to-purple-500/10 border-indigo-500/30">
        <h3 className="text-white mb-3">😴 Better Sleep Tips</h3>
        <ul className="space-y-2 text-white/80 text-sm">
          <li>• Aim for 7-9 hours of sleep per night</li>
          <li>• Maintain a consistent sleep schedule</li>
          <li>• Avoid screens 1 hour before bed</li>
          <li>• Keep your bedroom cool and dark</li>
          <li>• Avoid caffeine 6 hours before bedtime</li>
        </ul>
      </Card>
    </div>
  );
}
