import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Plus, Trash2, Save, GripVertical } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface Exercise {
  id: string;
  name: string;
  sets: number;
  reps: string;
  rest: number;
  notes?: string;
}

interface CustomWorkout {
  id: string;
  name: string;
  focus: string;
  exercises: Exercise[];
}

export function CustomWorkoutBuilder() {
  const [workouts, setWorkouts] = useState<CustomWorkout[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [currentWorkout, setCurrentWorkout] = useState<CustomWorkout>({
    id: '',
    name: '',
    focus: '',
    exercises: [],
  });
  const [exerciseForm, setExerciseForm] = useState({
    name: '',
    sets: '3',
    reps: '10',
    rest: '60',
    notes: '',
  });

  const addExercise = () => {
    if (!exerciseForm.name) {
      toast.error('Exercise name is required');
      return;
    }

    const newExercise: Exercise = {
      id: Date.now().toString(),
      name: exerciseForm.name,
      sets: parseInt(exerciseForm.sets),
      reps: exerciseForm.reps,
      rest: parseInt(exerciseForm.rest),
      notes: exerciseForm.notes,
    };

    setCurrentWorkout({
      ...currentWorkout,
      exercises: [...currentWorkout.exercises, newExercise],
    });

    setExerciseForm({
      name: '',
      sets: '3',
      reps: '10',
      rest: '60',
      notes: '',
    });

    toast.success('Exercise added!');
  };

  const removeExercise = (id: string) => {
    setCurrentWorkout({
      ...currentWorkout,
      exercises: currentWorkout.exercises.filter(e => e.id !== id),
    });
  };

  const saveWorkout = () => {
    if (!currentWorkout.name || currentWorkout.exercises.length === 0) {
      toast.error('Workout name and at least one exercise are required');
      return;
    }

    const workout = {
      ...currentWorkout,
      id: currentWorkout.id || Date.now().toString(),
    };

    if (currentWorkout.id) {
      setWorkouts(workouts.map(w => w.id === workout.id ? workout : w));
      toast.success('Workout updated!');
    } else {
      setWorkouts([...workouts, workout]);
      toast.success('Workout saved!');
    }

    setCurrentWorkout({ id: '', name: '', focus: '', exercises: [] });
    setShowForm(false);
  };

  const editWorkout = (workout: CustomWorkout) => {
    setCurrentWorkout(workout);
    setShowForm(true);
  };

  const deleteWorkout = (id: string) => {
    setWorkouts(workouts.filter(w => w.id !== id));
    toast.success('Workout deleted');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-white mb-2">Custom Workout Builder</h2>
          <p className="text-white/60">Create your own personalized workouts</p>
        </div>
        <Button
          onClick={() => {
            setCurrentWorkout({ id: '', name: '', focus: '', exercises: [] });
            setShowForm(!showForm);
          }}
          className="bg-gradient-to-r from-purple-500 to-pink-500"
        >
          <Plus className="w-4 h-4 mr-2" />
          {showForm ? 'Cancel' : 'New Workout'}
        </Button>
      </div>

      {/* Workout Builder Form */}
      {showForm && (
        <div className="space-y-4">
          <Card className="p-6 bg-white/5 border-white/10">
            <h3 className="text-white mb-4">Workout Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="text-white/80">Workout Name *</Label>
                <Input
                  value={currentWorkout.name}
                  onChange={(e) => setCurrentWorkout({ ...currentWorkout, name: e.target.value })}
                  className="bg-white/10 border-white/20 text-white"
                  placeholder="e.g., Upper Body Power"
                />
              </div>
              <div>
                <Label className="text-white/80">Focus Area</Label>
                <Input
                  value={currentWorkout.focus}
                  onChange={(e) => setCurrentWorkout({ ...currentWorkout, focus: e.target.value })}
                  className="bg-white/10 border-white/20 text-white"
                  placeholder="e.g., Chest & Triceps"
                />
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-white/5 border-white/10">
            <h3 className="text-white mb-4">Add Exercises</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-4">
              <div className="lg:col-span-2">
                <Label className="text-white/80">Exercise Name *</Label>
                <Input
                  value={exerciseForm.name}
                  onChange={(e) => setExerciseForm({ ...exerciseForm, name: e.target.value })}
                  className="bg-white/10 border-white/20 text-white"
                  placeholder="e.g., Bench Press"
                />
              </div>
              <div>
                <Label className="text-white/80">Sets</Label>
                <Input
                  type="number"
                  value={exerciseForm.sets}
                  onChange={(e) => setExerciseForm({ ...exerciseForm, sets: e.target.value })}
                  className="bg-white/10 border-white/20 text-white"
                />
              </div>
              <div>
                <Label className="text-white/80">Reps</Label>
                <Input
                  value={exerciseForm.reps}
                  onChange={(e) => setExerciseForm({ ...exerciseForm, reps: e.target.value })}
                  className="bg-white/10 border-white/20 text-white"
                  placeholder="8-10"
                />
              </div>
              <div>
                <Label className="text-white/80">Rest (sec)</Label>
                <Input
                  type="number"
                  value={exerciseForm.rest}
                  onChange={(e) => setExerciseForm({ ...exerciseForm, rest: e.target.value })}
                  className="bg-white/10 border-white/20 text-white"
                />
              </div>
            </div>

            <div className="mb-4">
              <Label className="text-white/80">Notes (Optional)</Label>
              <Input
                value={exerciseForm.notes}
                onChange={(e) => setExerciseForm({ ...exerciseForm, notes: e.target.value })}
                className="bg-white/10 border-white/20 text-white"
                placeholder="Any special instructions..."
              />
            </div>

            <Button onClick={addExercise} className="bg-purple-500 w-full md:w-auto">
              <Plus className="w-4 h-4 mr-2" />
              Add Exercise
            </Button>
          </Card>

          {/* Exercise List */}
          {currentWorkout.exercises.length > 0 && (
            <Card className="p-6 bg-white/5 border-white/10">
              <h3 className="text-white mb-4">Exercises ({currentWorkout.exercises.length})</h3>
              <div className="space-y-3">
                {currentWorkout.exercises.map((exercise, index) => (
                  <div
                    key={exercise.id}
                    className="flex items-center gap-4 p-4 bg-white/5 rounded-lg"
                  >
                    <GripVertical className="w-5 h-5 text-white/40" />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-white">{index + 1}. {exercise.name}</span>
                      </div>
                      <div className="flex gap-4 text-sm text-white/60">
                        <span>{exercise.sets} sets</span>
                        <span>{exercise.reps} reps</span>
                        <span>{exercise.rest}s rest</span>
                      </div>
                      {exercise.notes && (
                        <p className="text-white/60 text-sm mt-1 italic">{exercise.notes}</p>
                      )}
                    </div>
                    <Button
                      onClick={() => removeExercise(exercise.id)}
                      className="bg-red-500/20 hover:bg-red-500/30 text-red-300"
                      size="sm"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>

              <Button onClick={saveWorkout} className="bg-gradient-to-r from-green-500 to-emerald-500 w-full mt-4">
                <Save className="w-4 h-4 mr-2" />
                Save Workout
              </Button>
            </Card>
          )}
        </div>
      )}

      {/* Saved Workouts */}
      {workouts.length > 0 && !showForm && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {workouts.map(workout => (
            <Card key={workout.id} className="p-6 bg-white/5 border-white/10">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-white mb-1">{workout.name}</h3>
                  {workout.focus && (
                    <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30">
                      {workout.focus}
                    </Badge>
                  )}
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={() => editWorkout(workout)}
                    className="bg-blue-500/20 hover:bg-blue-500/30 text-blue-300"
                    size="sm"
                  >
                    Edit
                  </Button>
                  <Button
                    onClick={() => deleteWorkout(workout.id)}
                    className="bg-red-500/20 hover:bg-red-500/30 text-red-300"
                    size="sm"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                {workout.exercises.map((exercise, index) => (
                  <div key={exercise.id} className="text-sm text-white/80">
                    {index + 1}. {exercise.name} - {exercise.sets}x{exercise.reps}
                  </div>
                ))}
              </div>

              <div className="mt-4 pt-4 border-t border-white/10 text-white/60 text-sm">
                {workout.exercises.length} exercises
              </div>
            </Card>
          ))}
        </div>
      )}

      {workouts.length === 0 && !showForm && (
        <Card className="p-12 bg-white/5 border-white/10 text-center">
          <Plus className="w-12 h-12 text-white/40 mx-auto mb-4" />
          <p className="text-white/60 mb-4">No custom workouts yet</p>
          <p className="text-white/40 text-sm">Create your first custom workout to get started!</p>
        </Card>
      )}
    </div>
  );
}
