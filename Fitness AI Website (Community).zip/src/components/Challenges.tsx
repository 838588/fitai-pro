import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Target, Trophy, Calendar, Zap } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface Challenge {
  id: string;
  title: string;
  description: string;
  duration: number;
  goal: number;
  current: number;
  type: string;
  reward: string;
  active: boolean;
}

const availableChallenges: Challenge[] = [
  {
    id: '1',
    title: '30-Day Workout Challenge',
    description: 'Complete 30 workouts in 30 days',
    duration: 30,
    goal: 30,
    current: 0,
    type: 'Consistency',
    reward: '🏆 Consistency Master Badge',
    active: false,
  },
  {
    id: '2',
    title: 'Water Warrior',
    description: 'Hit your water goal for 14 consecutive days',
    duration: 14,
    goal: 14,
    current: 0,
    type: 'Wellness',
    reward: '💧 Hydration Hero Badge',
    active: false,
  },
  {
    id: '3',
    title: 'PR Crusher',
    description: 'Set 10 new personal records this month',
    duration: 30,
    goal: 10,
    current: 0,
    type: 'Strength',
    reward: '💪 Strength Champion Badge',
    active: false,
  },
  {
    id: '4',
    title: 'Early Bird Special',
    description: 'Complete 7 morning workouts before 7 AM',
    duration: 30,
    goal: 7,
    current: 0,
    type: 'Special',
    reward: '🌅 Early Riser Badge',
    active: false,
  },
  {
    id: '5',
    title: 'Meal Prep Master',
    description: 'Log all meals for 21 consecutive days',
    duration: 21,
    goal: 21,
    current: 0,
    type: 'Nutrition',
    reward: '🍎 Nutrition Pro Badge',
    active: false,
  },
  {
    id: '6',
    title: 'Sleep Champion',
    description: 'Get 8+ hours of sleep for 14 nights',
    duration: 14,
    goal: 14,
    current: 0,
    type: 'Recovery',
    reward: '😴 Sleep Master Badge',
    active: false,
  },
];

export function Challenges() {
  const [challenges, setChallenges] = useState(availableChallenges);

  const startChallenge = (id: string) => {
    setChallenges(challenges.map(c => 
      c.id === id ? { ...c, active: true } : c
    ));
    toast.success('Challenge started! Good luck! 🎯');
  };

  const quitChallenge = (id: string) => {
    setChallenges(challenges.map(c => 
      c.id === id ? { ...c, active: false, current: 0 } : c
    ));
    toast.info('Challenge quit');
  };

  const activeChallenges = challenges.filter(c => c.active);
  const availableForStart = challenges.filter(c => !c.active);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-white mb-2 flex items-center gap-2">
          <Target className="w-6 h-6 text-purple-400" />
          Fitness Challenges
        </h2>
        <p className="text-white/60">Join challenges to stay motivated</p>
      </div>

      {/* Active Challenges */}
      {activeChallenges.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-white">Active Challenges ({activeChallenges.length})</h3>
          {activeChallenges.map(challenge => {
            const percentage = (challenge.current / challenge.goal) * 100;
            const daysLeft = challenge.duration - Math.floor(challenge.duration * (challenge.current / challenge.goal));

            return (
              <Card key={challenge.id} className="p-6 bg-gradient-to-br from-purple-500/20 to-pink-500/20 border-purple-500/30">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-white mb-2">{challenge.title}</h3>
                    <p className="text-white/60 text-sm mb-2">{challenge.description}</p>
                    <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30">
                      {challenge.type}
                    </Badge>
                  </div>
                  <Button
                    onClick={() => quitChallenge(challenge.id)}
                    className="bg-red-500/20 hover:bg-red-500/30 text-red-300"
                    size="sm"
                  >
                    Quit
                  </Button>
                </div>

                <div className="mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-white text-sm">Progress</span>
                    <span className="text-white text-sm">{challenge.current} / {challenge.goal}</span>
                  </div>
                  <Progress value={percentage} className="h-3" />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-white/60 text-sm">
                    <Calendar className="w-4 h-4" />
                    <span>~{daysLeft} days left</span>
                  </div>
                  <div className="text-white/60 text-sm">
                    {challenge.reward}
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Available Challenges */}
      {availableForStart.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-white">Available Challenges</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {availableForStart.map(challenge => (
              <Card key={challenge.id} className="p-6 bg-white/5 border-white/10">
                <div className="mb-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Target className="w-5 h-5 text-purple-400" />
                    <h3 className="text-white">{challenge.title}</h3>
                  </div>
                  <p className="text-white/60 text-sm mb-3">{challenge.description}</p>
                  <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30">
                    {challenge.type}
                  </Badge>
                </div>

                <div className="space-y-2 mb-4 text-sm text-white/80">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-blue-400" />
                    <span>{challenge.duration} days</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-yellow-400" />
                    <span>Goal: {challenge.goal}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Trophy className="w-4 h-4 text-yellow-400" />
                    <span>{challenge.reward}</span>
                  </div>
                </div>

                <Button
                  onClick={() => startChallenge(challenge.id)}
                  className="bg-gradient-to-r from-purple-500 to-pink-500 w-full"
                >
                  Start Challenge
                </Button>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Tips */}
      <Card className="p-6 bg-gradient-to-r from-purple-500/10 to-pink-500/10 border-purple-500/30">
        <h3 className="text-white mb-3">💡 Challenge Tips</h3>
        <ul className="space-y-2 text-white/80 text-sm">
          <li>• Start with one challenge at a time</li>
          <li>• Track your progress daily</li>
          <li>• Share your achievements with friends</li>
          <li>• Don't give up if you miss a day - just keep going!</li>
          <li>• Completing challenges unlocks exclusive badges</li>
        </ul>
      </Card>
    </div>
  );
}
