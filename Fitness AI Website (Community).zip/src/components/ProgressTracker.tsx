import { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { TrendingUp, Calendar, Flame, Award, Dumbbell, Target } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { projectId } from '../utils/supabase/info';

interface ProgressTrackerProps {
  accessToken: string;
}

interface WorkoutLog {
  date: string;
  workoutDay: string;
  exercisesCompleted: number;
  totalExercises: number;
  duration: number;
}

interface ProgressData {
  weeklyWorkouts: { day: string; workouts: number }[];
  monthlyProgress: { week: string; completion: number }[];
  totalWorkouts: number;
  currentStreak: number;
  longestStreak: number;
  totalMinutes: number;
  recentLogs: WorkoutLog[];
}

export function ProgressTracker({ accessToken }: ProgressTrackerProps) {
  const { theme } = useTheme();
  const [progressData, setProgressData] = useState<ProgressData | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadProgressData();
  }, []);

  const loadProgressData = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-eb0ee345/progress`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${accessToken}`
          }
        }
      );

      const data = await response.json();

      if (response.ok && data.progress) {
        setProgressData(data.progress);
      } else {
        // Initialize with empty data
        setProgressData({
          weeklyWorkouts: generateEmptyWeekData(),
          monthlyProgress: generateEmptyMonthData(),
          totalWorkouts: 0,
          currentStreak: 0,
          longestStreak: 0,
          totalMinutes: 0,
          recentLogs: []
        });
      }
    } catch (err) {
      console.log(`Error loading progress data: ${err}`);
      setProgressData({
        weeklyWorkouts: generateEmptyWeekData(),
        monthlyProgress: generateEmptyMonthData(),
        totalWorkouts: 0,
        currentStreak: 0,
        longestStreak: 0,
        totalMinutes: 0,
        recentLogs: []
      });
    } finally {
      setIsLoading(false);
    }
  };

  const generateEmptyWeekData = () => {
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    return days.map(day => ({ day, workouts: 0 }));
  };

  const generateEmptyMonthData = () => {
    return [
      { week: 'Week 1', completion: 0 },
      { week: 'Week 2', completion: 0 },
      { week: 'Week 3', completion: 0 },
      { week: 'Week 4', completion: 0 }
    ];
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className={`text-${theme.textSecondary}`}>Loading progress data...</div>
      </div>
    );
  }

  if (!progressData) {
    return null;
  }

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours > 0) {
      return `${hours}h ${mins}m`;
    }
    return `${mins}m`;
  };

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-6 bg-white/5 border-white/10 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className={`text-${theme.textSecondary} text-sm mb-1`}>Total Workouts</p>
              <p className="text-white text-3xl">{progressData.totalWorkouts}</p>
            </div>
            <div className={`p-3 bg-${theme.primary}/20 rounded-lg`}>
              <Dumbbell className={`w-6 h-6 text-${theme.accent}`} />
            </div>
          </div>
        </Card>

        <Card className="p-6 bg-white/5 border-white/10 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className={`text-${theme.textSecondary} text-sm mb-1`}>Current Streak</p>
              <p className="text-white text-3xl">{progressData.currentStreak}</p>
              <p className="text-orange-400 text-xs mt-1">days in a row 🔥</p>
            </div>
            <div className="p-3 bg-orange-500/20 rounded-lg">
              <Flame className="w-6 h-6 text-orange-400" />
            </div>
          </div>
        </Card>

        <Card className="p-6 bg-white/5 border-white/10 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className={`text-${theme.textSecondary} text-sm mb-1`}>Longest Streak</p>
              <p className="text-white text-3xl">{progressData.longestStreak}</p>
              <p className="text-yellow-400 text-xs mt-1">personal best 🏆</p>
            </div>
            <div className="p-3 bg-yellow-500/20 rounded-lg">
              <Award className="w-6 h-6 text-yellow-400" />
            </div>
          </div>
        </Card>

        <Card className="p-6 bg-white/5 border-white/10 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className={`text-${theme.textSecondary} text-sm mb-1`}>Total Time</p>
              <p className="text-white text-3xl">{formatDuration(progressData.totalMinutes)}</p>
              <p className="text-blue-400 text-xs mt-1">of training</p>
            </div>
            <div className="p-3 bg-blue-500/20 rounded-lg">
              <Target className="w-6 h-6 text-blue-400" />
            </div>
          </div>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Activity */}
        <Card className="p-6 bg-white/5 border-white/10 backdrop-blur-sm">
          <div className="mb-4">
            <h3 className="text-white mb-1">This Week's Activity</h3>
            <p className={`text-${theme.textSecondary} text-sm`}>
              Workouts completed each day
            </p>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={progressData.weeklyWorkouts}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis 
                dataKey="day" 
                stroke="rgba(255,255,255,0.5)"
                style={{ fontSize: '12px' }}
              />
              <YAxis 
                stroke="rgba(255,255,255,0.5)"
                style={{ fontSize: '12px' }}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'rgba(0,0,0,0.9)', 
                  border: '1px solid rgba(255,255,255,0.2)',
                  borderRadius: '8px',
                  color: '#fff'
                }}
              />
              <Bar dataKey="workouts" fill="#a855f7" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* Monthly Progress */}
        <Card className="p-6 bg-white/5 border-white/10 backdrop-blur-sm">
          <div className="mb-4">
            <h3 className="text-white mb-1">Monthly Completion Rate</h3>
            <p className={`text-${theme.textSecondary} text-sm`}>
              Average workout completion by week
            </p>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={progressData.monthlyProgress}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis 
                dataKey="week" 
                stroke="rgba(255,255,255,0.5)"
                style={{ fontSize: '12px' }}
              />
              <YAxis 
                stroke="rgba(255,255,255,0.5)"
                style={{ fontSize: '12px' }}
                domain={[0, 100]}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'rgba(0,0,0,0.9)', 
                  border: '1px solid rgba(255,255,255,0.2)',
                  borderRadius: '8px',
                  color: '#fff'
                }}
                formatter={(value: number) => `${value}%`}
              />
              <Line 
                type="monotone" 
                dataKey="completion" 
                stroke="#10b981" 
                strokeWidth={3}
                dot={{ fill: '#10b981', r: 5 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Recent Workouts */}
      <Card className="p-6 bg-white/5 border-white/10 backdrop-blur-sm">
        <div className="mb-4">
          <h3 className="text-white mb-1">Recent Workouts</h3>
          <p className={`text-${theme.textSecondary} text-sm`}>
            Your latest training sessions
          </p>
        </div>

        {progressData.recentLogs.length === 0 ? (
          <div className="text-center py-8">
            <Calendar className={`w-12 h-12 text-${theme.textSecondary} mx-auto mb-3 opacity-50`} />
            <p className={`text-${theme.textSecondary}`}>No workouts logged yet</p>
            <p className={`text-${theme.textSecondary} text-sm mt-1`}>
              Complete a workout to start tracking your progress!
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {progressData.recentLogs.map((log, index) => (
              <div
                key={index}
                className="p-4 bg-white/5 rounded-lg border border-white/10 flex items-center justify-between"
              >
                <div className="flex items-center gap-4">
                  <div className={`p-2 bg-${theme.primary}/20 rounded-lg`}>
                    <Dumbbell className={`w-5 h-5 text-${theme.accent}`} />
                  </div>
                  <div>
                    <p className="text-white">{log.workoutDay}</p>
                    <p className={`text-${theme.textSecondary} text-sm`}>
                      {new Date(log.date).toLocaleDateString('en-US', { 
                        weekday: 'short', 
                        month: 'short', 
                        day: 'numeric' 
                      })}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <Badge className="bg-green-500/20 text-green-300">
                      {log.exercisesCompleted}/{log.totalExercises} exercises
                    </Badge>
                    <p className={`text-${theme.textSecondary} text-xs mt-1`}>
                      {formatDuration(log.duration)}
                    </p>
                  </div>
                  {log.exercisesCompleted === log.totalExercises && (
                    <div className="text-2xl">✅</div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Motivational Message */}
      {progressData.currentStreak > 0 && (
        <Card className="p-6 bg-gradient-to-r from-orange-500/10 to-yellow-500/10 border-orange-500/30">
          <div className="flex items-center gap-3">
            <Flame className="w-8 h-8 text-orange-400" />
            <div>
              <p className="text-white">
                🔥 You're on fire! Keep up the {progressData.currentStreak}-day streak!
              </p>
              <p className="text-orange-200 text-sm mt-1">
                Just {progressData.longestStreak > progressData.currentStreak 
                  ? `${progressData.longestStreak - progressData.currentStreak} more days to beat your record!`
                  : "You're at your personal best! Keep going!"}
              </p>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
