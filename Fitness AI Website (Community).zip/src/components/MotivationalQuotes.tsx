import { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Quote, RefreshCw, Heart } from 'lucide-react';

const quotes = [
  { text: "The only bad workout is the one that didn't happen.", author: "Unknown" },
  { text: "Strength does not come from physical capacity. It comes from an indomitable will.", author: "Mahatma Gandhi" },
  { text: "The pain you feel today will be the strength you feel tomorrow.", author: "Unknown" },
  { text: "Your body can stand almost anything. It's your mind you have to convince.", author: "Unknown" },
  { text: "The only way to define your limits is by going beyond them.", author: "Unknown" },
  { text: "Sweat is fat crying.", author: "Unknown" },
  { text: "Success is the sum of small efforts repeated day in and day out.", author: "Robert Collier" },
  { text: "Don't wish for it. Work for it.", author: "Unknown" },
  { text: "The difference between try and triumph is a little umph.", author: "Unknown" },
  { text: "Exercise is king. Nutrition is queen. Put them together and you've got a kingdom.", author: "Jack LaLanne" },
  { text: "Take care of your body. It's the only place you have to live.", author: "Jim Rohn" },
  { text: "A one hour workout is 4% of your day. No excuses.", author: "Unknown" },
  { text: "The hardest lift of all is lifting your butt off the couch.", author: "Unknown" },
  { text: "Fitness is not about being better than someone else. It's about being better than you used to be.", author: "Unknown" },
  { text: "Strive for progress, not perfection.", author: "Unknown" },
  { text: "You don't have to be extreme, just consistent.", author: "Unknown" },
  { text: "The only impossible journey is the one you never begin.", author: "Tony Robbins" },
  { text: "Your health is an investment, not an expense.", author: "Unknown" },
  { text: "Discipline is choosing between what you want now and what you want most.", author: "Unknown" },
  { text: "The body achieves what the mind believes.", author: "Unknown" },
];

export function MotivationalQuotes() {
  const [currentQuote, setCurrentQuote] = useState(quotes[0]);
  const [favorites, setFavorites] = useState<typeof quotes>([]);

  useEffect(() => {
    // Get a random quote on mount
    const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
    setCurrentQuote(randomQuote);
  }, []);

  const getNewQuote = () => {
    let newQuote;
    do {
      newQuote = quotes[Math.floor(Math.random() * quotes.length)];
    } while (newQuote.text === currentQuote.text && quotes.length > 1);
    setCurrentQuote(newQuote);
  };

  const toggleFavorite = () => {
    const isFavorite = favorites.some(q => q.text === currentQuote.text);
    if (isFavorite) {
      setFavorites(favorites.filter(q => q.text !== currentQuote.text));
    } else {
      setFavorites([...favorites, currentQuote]);
    }
  };

  const isFavorite = favorites.some(q => q.text === currentQuote.text);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-white mb-2 flex items-center gap-2">
          <Quote className="w-6 h-6 text-purple-400" />
          Daily Motivation
        </h2>
        <p className="text-white/60">Get inspired to reach your fitness goals</p>
      </div>

      {/* Quote of the Day */}
      <Card className="p-8 bg-gradient-to-br from-purple-500/20 to-pink-500/20 border-purple-500/30 text-center">
        <Quote className="w-12 h-12 text-purple-400 mx-auto mb-6" />
        <blockquote className="text-white text-xl md:text-2xl mb-4 leading-relaxed">
          "{currentQuote.text}"
        </blockquote>
        <p className="text-purple-300">— {currentQuote.author}</p>
        
        <div className="flex items-center justify-center gap-4 mt-6">
          <Button
            onClick={getNewQuote}
            className="bg-purple-500 hover:bg-purple-600"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            New Quote
          </Button>
          <Button
            onClick={toggleFavorite}
            className={isFavorite ? 'bg-red-500 hover:bg-red-600' : 'bg-white/10 hover:bg-white/20'}
          >
            <Heart className={`w-4 h-4 mr-2 ${isFavorite ? 'fill-current' : ''}`} />
            {isFavorite ? 'Saved' : 'Save'}
          </Button>
        </div>
      </Card>

      {/* Favorite Quotes */}
      {favorites.length > 0 && (
        <Card className="p-6 bg-white/5 border-white/10">
          <h3 className="text-white mb-4">Your Favorite Quotes ({favorites.length})</h3>
          <div className="space-y-4">
            {favorites.map((quote, index) => (
              <div key={index} className="p-4 bg-white/5 rounded-lg">
                <p className="text-white mb-2 italic">"{quote.text}"</p>
                <p className="text-white/60 text-sm">— {quote.author}</p>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Quote Categories */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-6 bg-gradient-to-br from-blue-500/10 to-cyan-500/10 border-blue-500/30">
          <div className="text-3xl mb-3">💪</div>
          <h3 className="text-white mb-2">Strength</h3>
          <p className="text-white/60 text-sm">Find your inner power</p>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-green-500/10 to-emerald-500/10 border-green-500/30">
          <div className="text-3xl mb-3">🎯</div>
          <h3 className="text-white mb-2">Discipline</h3>
          <p className="text-white/60 text-sm">Build lasting habits</p>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-orange-500/10 to-red-500/10 border-orange-500/30">
          <div className="text-3xl mb-3">🔥</div>
          <h3 className="text-white mb-2">Perseverance</h3>
          <p className="text-white/60 text-sm">Never give up</p>
        </Card>
      </div>
    </div>
  );
}
