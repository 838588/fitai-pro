import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select } from './ui/select';
import { Checkbox } from './ui/checkbox';
import { UserData } from '../App';
import { User, Activity, Target, Heart, Dumbbell, Zap, Utensils, Ruler, Weight } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

interface UserDataFormProps {
  onSubmit: (data: UserData) => void;
}

export function UserDataForm({ onSubmit }: UserDataFormProps) {
  const { theme } = useTheme();
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    gender: '',
    height: '',
    weight: '',
    goal: '',
    activityLevel: '',
    experience: '',
  });

  const [medicalConditions, setMedicalConditions] = useState<string[]>([]);
  const [dietaryRestrictions, setDietaryRestrictions] = useState<string[]>([]);
  const [showOtherMedical, setShowOtherMedical] = useState(false);
  const [otherMedicalText, setOtherMedicalText] = useState('');
  const [showOtherDietary, setShowOtherDietary] = useState(false);
  const [otherDietaryText, setOtherDietaryText] = useState('');
  const [heightUnit, setHeightUnit] = useState<'cm' | 'ft'>('cm');
  const [heightFeet, setHeightFeet] = useState('');
  const [heightInches, setHeightInches] = useState('');

  const availableMedicalConditions = [
    'Diabetes',
    'Hypertension (High Blood Pressure)',
    'Heart Disease',
    'Asthma',
    'Arthritis',
    'Thyroid Issues',
    'Back Pain',
    'Knee Problems',
    'PCOS',
    'High Cholesterol',
  ];

  const availableDietaryRestrictions = [
    'Vegetarian',
    'Vegan',
    'Gluten-Free',
    'Lactose Intolerant',
    'Nut Allergies',
    'Low Sodium',
    'Halal',
    'Kosher',
  ];

  const toggleMedicalCondition = (condition: string) => {
    setMedicalConditions(prev =>
      prev.includes(condition)
        ? prev.filter(c => c !== condition)
        : [...prev, condition]
    );
  };

  const toggleDietaryRestriction = (restriction: string) => {
    setDietaryRestrictions(prev =>
      prev.includes(restriction)
        ? prev.filter(r => r !== restriction)
        : [...prev, restriction]
    );
  };

  // Height conversion functions
  const cmToFeetInches = (cm: number) => {
    const totalInches = cm / 2.54;
    const feet = Math.floor(totalInches / 12);
    const inches = Math.round(totalInches % 12);
    return { feet, inches };
  };

  const feetInchesToCm = (feet: number, inches: number) => {
    const totalInches = feet * 12 + inches;
    return Math.round(totalInches * 2.54);
  };

  const handleHeightUnitChange = (newUnit: 'cm' | 'ft') => {
    if (newUnit === heightUnit) return;

    if (newUnit === 'ft' && formData.height) {
      // Converting from cm to feet/inches
      const cm = parseInt(formData.height);
      const { feet, inches } = cmToFeetInches(cm);
      setHeightFeet(feet.toString());
      setHeightInches(inches.toString());
    } else if (newUnit === 'cm' && heightFeet) {
      // Converting from feet/inches to cm
      const feet = parseInt(heightFeet) || 0;
      const inches = parseInt(heightInches) || 0;
      const cm = feetInchesToCm(feet, inches);
      setFormData({ ...formData, height: cm.toString() });
    }

    setHeightUnit(newUnit);
  };

  const handleHeightCmChange = (value: string) => {
    setFormData({ ...formData, height: value });
  };

  const handleHeightFeetChange = (value: string) => {
    setHeightFeet(value);
    const feet = parseInt(value) || 0;
    const inches = parseInt(heightInches) || 0;
    const cm = feetInchesToCm(feet, inches);
    setFormData({ ...formData, height: cm.toString() });
  };

  const handleHeightInchesChange = (value: string) => {
    setHeightInches(value);
    const feet = parseInt(heightFeet) || 0;
    const inches = parseInt(value) || 0;
    const cm = feetInchesToCm(feet, inches);
    setFormData({ ...formData, height: cm.toString() });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      name: formData.name,
      age: parseInt(formData.age),
      gender: formData.gender,
      height: parseInt(formData.height),
      weight: parseInt(formData.weight),
      goal: formData.goal,
      activityLevel: formData.activityLevel,
      experience: formData.experience,
      medicalConditions,
      dietaryRestrictions,
      otherMedicalConditions: otherMedicalText,
      otherDietaryRestrictions: otherDietaryText,
    });
  };

  const isFormValid = () => {
    return (
      formData.name &&
      formData.age &&
      formData.gender &&
      formData.height &&
      formData.weight &&
      formData.goal &&
      formData.activityLevel &&
      formData.experience
    );
  };

  return (
    <div className="max-w-3xl mx-auto">
      <Card className="p-8 bg-white/5 border-white/10 backdrop-blur-sm">
        <div className="mb-8 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full mb-4">
            <User className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-white mb-2">Let's Get Started</h2>
          <p className={`text-${theme.textSecondary}`}>Tell us about yourself to get your personalized fitness plan</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Personal Information */}
          <div className="space-y-4">
            <div className={`flex items-center gap-2 text-${theme.textSecondary} mb-4`}>
              <User className="w-5 h-5" />
              <span>Personal Information</span>
            </div>

            <div>
              <Label htmlFor="name" className="text-white">Name</Label>
              <Input
                id="name"
                type="text"
                placeholder="Enter your name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-white/10 border-white/20 text-white placeholder:text-white/40"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="age" className="text-white">Age</Label>
                <Input
                  id="age"
                  type="number"
                  placeholder="25"
                  value={formData.age}
                  onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/40"
                />
              </div>

              <div>
                <Label htmlFor="gender" className="text-white">Gender</Label>
                <select
                  id="gender"
                  value={formData.gender}
                  onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
                  className={`flex h-10 w-full rounded-md border border-white/20 bg-white/10 px-3 py-2 text-white placeholder:text-white/40 focus:outline-none focus:ring-2 focus:ring-${theme.accent} focus:ring-offset-2 focus:ring-offset-slate-900`}
                >
                  <option value="" className="bg-slate-800">Select gender</option>
                  <option value="male" className="bg-slate-800">Male</option>
                  <option value="female" className="bg-slate-800">Female</option>
                  <option value="other" className="bg-slate-800">Other</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Ruler className={`w-4 h-4 text-${theme.textSecondary}`} />
                    <Label htmlFor="height" className="text-white">Height</Label>
                  </div>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => handleHeightUnitChange('cm')}
                      className={`px-3 py-1 rounded text-xs transition-all ${
                        heightUnit === 'cm'
                          ? 'text-white border-2'
                          : 'bg-white/5 text-white/60 border border-white/20 hover:bg-white/10'
                      }`}
                      style={heightUnit === 'cm' ? {
                        background: `linear-gradient(to right, var(--tw-gradient-stops))`,
                        borderColor: 'rgba(255, 255, 255, 0.5)'
                      } : {}}
                    >
                      cm
                    </button>
                    <button
                      type="button"
                      onClick={() => handleHeightUnitChange('ft')}
                      className={`px-3 py-1 rounded text-xs transition-all ${
                        heightUnit === 'ft'
                          ? 'text-white border-2'
                          : 'bg-white/5 text-white/60 border border-white/20 hover:bg-white/10'
                      }`}
                      style={heightUnit === 'ft' ? {
                        background: `linear-gradient(to right, var(--tw-gradient-stops))`,
                        borderColor: 'rgba(255, 255, 255, 0.5)'
                      } : {}}
                    >
                      ft
                    </button>
                  </div>
                </div>
                <div className="space-y-2">
                  {heightUnit === 'cm' ? (
                    <Input
                      id="height"
                      type="number"
                      placeholder="170"
                      value={formData.height}
                      onChange={(e) => handleHeightCmChange(e.target.value)}
                      className="bg-white/10 border-white/20 text-white placeholder:text-white/40"
                    />
                  ) : (
                    <div className="flex gap-2">
                      <div className="flex-1">
                        <Input
                          type="number"
                          placeholder="5"
                          value={heightFeet}
                          onChange={(e) => handleHeightFeetChange(e.target.value)}
                          className="bg-white/10 border-white/20 text-white placeholder:text-white/40"
                        />
                        <span className="text-white/60 text-xs mt-1 block text-center">feet</span>
                      </div>
                      <div className="flex-1">
                        <Input
                          type="number"
                          placeholder="7"
                          value={heightInches}
                          onChange={(e) => handleHeightInchesChange(e.target.value)}
                          className="bg-white/10 border-white/20 text-white placeholder:text-white/40"
                        />
                        <span className="text-white/60 text-xs mt-1 block text-center">inches</span>
                      </div>
                    </div>
                  )}
                  {formData.height && parseInt(formData.height) > 0 && (
                    <div className="flex items-center gap-2 px-2 py-1 bg-white/5 rounded border border-white/10">
                      <span className="text-white/40 text-xs">≈</span>
                      <p className={`text-${theme.textSecondary} text-xs`}>
                        {heightUnit === 'cm' 
                          ? `${cmToFeetInches(parseInt(formData.height)).feet}' ${cmToFeetInches(parseInt(formData.height)).inches}"`
                          : `${formData.height} cm`
                        }
                      </p>
                    </div>
                  )}
                </div>
              </div>

              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Weight className={`w-4 h-4 text-${theme.textSecondary}`} />
                  <Label htmlFor="weight" className="text-white">Weight (kg)</Label>
                </div>
                <Input
                  id="weight"
                  type="number"
                  placeholder="70"
                  value={formData.weight}
                  onChange={(e) => setFormData({ ...formData, weight: e.target.value })}
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/40"
                />
              </div>
            </div>
          </div>

          {/* Fitness Goals */}
          <div className="space-y-4">
            <div className={`flex items-center gap-2 text-${theme.textSecondary} mb-4`}>
              <Target className="w-5 h-5" />
              <span>Fitness Goals</span>
            </div>

            <div>
              <Label htmlFor="goal" className="text-white">Primary Goal</Label>
              <select
                id="goal"
                value={formData.goal}
                onChange={(e) => setFormData({ ...formData, goal: e.target.value })}
                className="flex h-10 w-full rounded-md border border-white/20 bg-white/10 px-3 py-2 text-white placeholder:text-white/40 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 focus:ring-offset-slate-900"
              >
                <option value="" className="bg-slate-800">Select your goal</option>
                <option value="weight-loss" className="bg-slate-800">Weight Loss</option>
                <option value="muscle-gain" className="bg-slate-800">Muscle Gain</option>
                <option value="maintenance" className="bg-slate-800">Maintenance</option>
                <option value="endurance" className="bg-slate-800">Improve Endurance</option>
              </select>
            </div>

            <div>
              <Label htmlFor="activityLevel" className="text-white">Activity Level</Label>
              <select
                id="activityLevel"
                value={formData.activityLevel}
                onChange={(e) => setFormData({ ...formData, activityLevel: e.target.value })}
                className="flex h-10 w-full rounded-md border border-white/20 bg-white/10 px-3 py-2 text-white placeholder:text-white/40 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 focus:ring-offset-slate-900"
              >
                <option value="" className="bg-slate-800">Select activity level</option>
                <option value="sedentary" className="bg-slate-800">Sedentary (little to no exercise)</option>
                <option value="light" className="bg-slate-800">Light (1-3 days/week)</option>
                <option value="moderate" className="bg-slate-800">Moderate (3-5 days/week)</option>
                <option value="active" className="bg-slate-800">Active (6-7 days/week)</option>
                <option value="very-active" className="bg-slate-800">Very Active (2x per day)</option>
              </select>
            </div>

            <div>
              <Label className="text-white mb-4">Current Fitness Level</Label>
              <div className="grid grid-cols-3 gap-4">
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, experience: 'beginner' })}
                  className={`p-6 rounded-lg border-2 transition-all ${
                    formData.experience === 'beginner'
                      ? `border-${theme.primary} bg-${theme.primary}/20`
                      : 'border-white/20 bg-white/5 hover:bg-white/10'
                  }`}
                >
                  <div className="flex flex-col items-center gap-3">
                    <Heart className="w-10 h-10 text-white" />
                    <span className="text-white">Beginner</span>
                  </div>
                </button>
                
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, experience: 'intermediate' })}
                  className={`p-6 rounded-lg border-2 transition-all ${
                    formData.experience === 'intermediate'
                      ? `border-${theme.primary} bg-${theme.primary}/20`
                      : 'border-white/20 bg-white/5 hover:bg-white/10'
                  }`}
                >
                  <div className="flex flex-col items-center gap-3">
                    <Dumbbell className="w-10 h-10 text-white" />
                    <span className="text-white">Intermediate</span>
                  </div>
                </button>
                
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, experience: 'advanced' })}
                  className={`p-6 rounded-lg border-2 transition-all ${
                    formData.experience === 'advanced'
                      ? `border-${theme.primary} bg-${theme.primary}/20`
                      : 'border-white/20 bg-white/5 hover:bg-white/10'
                  }`}
                >
                  <div className="flex flex-col items-center gap-3">
                    <Zap className="w-10 h-10 text-white" />
                    <span className="text-white">Advanced</span>
                  </div>
                </button>
              </div>
            </div>
          </div>

          {/* Health & Dietary Information */}
          <div className="space-y-4">
            <div className={`flex items-center gap-2 text-${theme.textSecondary} mb-4`}>
              <Heart className="w-5 h-5" />
              <span>Health & Dietary Information</span>
            </div>

            <div>
              <Label className="text-white mb-3">Medical Conditions (Optional)</Label>
              <p className={`text-${theme.textSecondary} text-sm mb-3`}>
                Select any conditions that may affect your workout plan
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {availableMedicalConditions.map((condition) => (
                  <div
                    key={condition}
                    className="flex items-center space-x-2 p-3 bg-white/5 rounded-lg border border-white/10 hover:bg-white/10 transition-colors cursor-pointer"
                    onClick={() => toggleMedicalCondition(condition)}
                  >
                    <Checkbox
                      id={condition}
                      checked={medicalConditions.includes(condition)}
                      onCheckedChange={() => toggleMedicalCondition(condition)}
                      className="border-white/30"
                    />
                    <label
                      htmlFor={condition}
                      className="text-white text-sm cursor-pointer flex-1"
                    >
                      {condition}
                    </label>
                  </div>
                ))}
                {showOtherMedical && (
                  <div className="flex items-center space-x-2 p-3 bg-white/5 rounded-lg border border-white/10 hover:bg-white/10 transition-colors cursor-pointer">
                    <Checkbox
                      id="otherMedical"
                      checked={!!otherMedicalText}
                      onCheckedChange={() => setShowOtherMedical(!showOtherMedical)}
                      className="border-white/30"
                    />
                    <label
                      htmlFor="otherMedical"
                      className="text-white text-sm cursor-pointer flex-1"
                    >
                      Other
                    </label>
                    <Input
                      id="otherMedicalText"
                      type="text"
                      placeholder="Enter other medical condition"
                      value={otherMedicalText}
                      onChange={(e) => setOtherMedicalText(e.target.value)}
                      className="bg-white/10 border-white/20 text-white placeholder:text-white/40"
                    />
                  </div>
                )}
                {!showOtherMedical && (
                  <div
                    className="flex items-center space-x-2 p-3 bg-white/5 rounded-lg border border-white/10 hover:bg-white/10 transition-colors cursor-pointer"
                    onClick={() => setShowOtherMedical(true)}
                  >
                    <Checkbox
                      id="otherMedical"
                      checked={!!otherMedicalText}
                      onCheckedChange={() => setShowOtherMedical(!showOtherMedical)}
                      className="border-white/30"
                    />
                    <label
                      htmlFor="otherMedical"
                      className="text-white text-sm cursor-pointer flex-1"
                    >
                      Other
                    </label>
                  </div>
                )}
              </div>
            </div>

            <div>
              <Label className="text-white mb-3">Dietary Restrictions (Optional)</Label>
              <p className={`text-${theme.textSecondary} text-sm mb-3`}>
                Select any dietary preferences or restrictions
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {availableDietaryRestrictions.map((restriction) => (
                  <div
                    key={restriction}
                    className="flex items-center space-x-2 p-3 bg-white/5 rounded-lg border border-white/10 hover:bg-white/10 transition-colors cursor-pointer"
                    onClick={() => toggleDietaryRestriction(restriction)}
                  >
                    <Checkbox
                      id={restriction}
                      checked={dietaryRestrictions.includes(restriction)}
                      onCheckedChange={() => toggleDietaryRestriction(restriction)}
                      className="border-white/30"
                    />
                    <label
                      htmlFor={restriction}
                      className="text-white text-sm cursor-pointer flex-1"
                    >
                      {restriction}
                    </label>
                  </div>
                ))}
                {showOtherDietary && (
                  <div className="flex items-center space-x-2 p-3 bg-white/5 rounded-lg border border-white/10 hover:bg-white/10 transition-colors cursor-pointer">
                    <Checkbox
                      id="otherDietary"
                      checked={!!otherDietaryText}
                      onCheckedChange={() => setShowOtherDietary(!showOtherDietary)}
                      className="border-white/30"
                    />
                    <label
                      htmlFor="otherDietary"
                      className="text-white text-sm cursor-pointer flex-1"
                    >
                      Other
                    </label>
                    <Input
                      id="otherDietaryText"
                      type="text"
                      placeholder="Enter other dietary restriction"
                      value={otherDietaryText}
                      onChange={(e) => setOtherDietaryText(e.target.value)}
                      className="bg-white/10 border-white/20 text-white placeholder:text-white/40"
                    />
                  </div>
                )}
                {!showOtherDietary && (
                  <div
                    className="flex items-center space-x-2 p-3 bg-white/5 rounded-lg border border-white/10 hover:bg-white/10 transition-colors cursor-pointer"
                    onClick={() => setShowOtherDietary(true)}
                  >
                    <Checkbox
                      id="otherDietary"
                      checked={!!otherDietaryText}
                      onCheckedChange={() => setShowOtherDietary(!showOtherDietary)}
                      className="border-white/30"
                    />
                    <label
                      htmlFor="otherDietary"
                      className="text-white text-sm cursor-pointer flex-1"
                    >
                      Other
                    </label>
                  </div>
                )}
              </div>
            </div>
          </div>

          <Button
            type="submit"
            disabled={!isFormValid()}
            className={`w-full bg-gradient-to-r ${theme.buttonGradient} hover:${theme.buttonHover} text-white disabled:opacity-50 disabled:cursor-not-allowed`}
          >
            Generate My Plan
          </Button>
        </form>
      </Card>
    </div>
  );
}