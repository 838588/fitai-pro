import { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Calendar, TrendingDown, TrendingUp, Plus, Trash2 } from 'lucide-react';
import { projectId } from '../utils/supabase/info';
import { toast } from 'sonner@2.0.3';

interface Measurement {
  id: string;
  date: string;
  weight: number;
  bodyFat?: number;
  chest?: number;
  waist?: number;
  hips?: number;
  arms?: number;
  thighs?: number;
}

interface BodyMeasurementsProps {
  accessToken: string;
}

export function BodyMeasurements({ accessToken }: BodyMeasurementsProps) {
  const [measurements, setMeasurements] = useState<Measurement[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);
  
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    weight: '',
    bodyFat: '',
    chest: '',
    waist: '',
    hips: '',
    arms: '',
    thighs: '',
  });

  useEffect(() => {
    loadMeasurements();
  }, []);

  const loadMeasurements = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-eb0ee345/body-measurements`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${accessToken}`
          }
        }
      );

      const data = await response.json();
      if (response.ok && data.measurements) {
        setMeasurements(data.measurements);
      }
    } catch (err) {
      console.error('Error loading measurements:', err);
    } finally {
      setLoading(false);
    }
  };

  const saveMeasurement = async () => {
    if (!formData.weight) {
      toast.error('Weight is required');
      return;
    }

    const newMeasurement: Measurement = {
      id: Date.now().toString(),
      date: formData.date,
      weight: parseFloat(formData.weight),
      bodyFat: formData.bodyFat ? parseFloat(formData.bodyFat) : undefined,
      chest: formData.chest ? parseFloat(formData.chest) : undefined,
      waist: formData.waist ? parseFloat(formData.waist) : undefined,
      hips: formData.hips ? parseFloat(formData.hips) : undefined,
      arms: formData.arms ? parseFloat(formData.arms) : undefined,
      thighs: formData.thighs ? parseFloat(formData.thighs) : undefined,
    };

    try {
      const updatedMeasurements = [...measurements, newMeasurement].sort((a, b) => 
        new Date(a.date).getTime() - new Date(b.date).getTime()
      );

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-eb0ee345/body-measurements`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`
          },
          body: JSON.stringify({ measurements: updatedMeasurements })
        }
      );

      if (response.ok) {
        setMeasurements(updatedMeasurements);
        setShowForm(false);
        setFormData({
          date: new Date().toISOString().split('T')[0],
          weight: '',
          bodyFat: '',
          chest: '',
          waist: '',
          hips: '',
          arms: '',
          thighs: '',
        });
        toast.success('Measurement saved successfully!');
      }
    } catch (err) {
      console.error('Error saving measurement:', err);
      toast.error('Failed to save measurement');
    }
  };

  const deleteMeasurement = async (id: string) => {
    const updatedMeasurements = measurements.filter(m => m.id !== id);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-eb0ee345/body-measurements`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`
          },
          body: JSON.stringify({ measurements: updatedMeasurements })
        }
      );

      if (response.ok) {
        setMeasurements(updatedMeasurements);
        toast.success('Measurement deleted');
      }
    } catch (err) {
      console.error('Error deleting measurement:', err);
      toast.error('Failed to delete measurement');
    }
  };

  const calculateChange = (metric: keyof Measurement) => {
    if (measurements.length < 2) return null;
    
    const validMeasurements = measurements.filter(m => m[metric] !== undefined);
    if (validMeasurements.length < 2) return null;

    const first = validMeasurements[0][metric] as number;
    const last = validMeasurements[validMeasurements.length - 1][metric] as number;
    const change = last - first;
    const percentage = ((change / first) * 100).toFixed(1);

    return { change: change.toFixed(1), percentage };
  };

  const weightChange = calculateChange('weight');

  if (loading) {
    return (
      <Card className="p-6 bg-white/5 border-white/10">
        <p className="text-white/60 text-center">Loading measurements...</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-white mb-2">Body Measurements</h2>
          <p className="text-white/60">Track your physical progress over time</p>
        </div>
        <Button
          onClick={() => setShowForm(!showForm)}
          className="bg-gradient-to-r from-purple-500 to-pink-500"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Measurement
        </Button>
      </div>

      {/* Add Measurement Form */}
      {showForm && (
        <Card className="p-6 bg-white/5 border-white/10">
          <h3 className="text-white mb-4">New Measurement</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="text-white/80">Date *</Label>
              <Input
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="bg-white/10 border-white/20 text-white"
              />
            </div>
            <div>
              <Label className="text-white/80">Weight (kg) *</Label>
              <Input
                type="number"
                step="0.1"
                value={formData.weight}
                onChange={(e) => setFormData({ ...formData, weight: e.target.value })}
                className="bg-white/10 border-white/20 text-white"
                placeholder="70.5"
              />
            </div>
            <div>
              <Label className="text-white/80">Body Fat %</Label>
              <Input
                type="number"
                step="0.1"
                value={formData.bodyFat}
                onChange={(e) => setFormData({ ...formData, bodyFat: e.target.value })}
                className="bg-white/10 border-white/20 text-white"
                placeholder="15.0"
              />
            </div>
            <div>
              <Label className="text-white/80">Chest (cm)</Label>
              <Input
                type="number"
                step="0.1"
                value={formData.chest}
                onChange={(e) => setFormData({ ...formData, chest: e.target.value })}
                className="bg-white/10 border-white/20 text-white"
                placeholder="95.0"
              />
            </div>
            <div>
              <Label className="text-white/80">Waist (cm)</Label>
              <Input
                type="number"
                step="0.1"
                value={formData.waist}
                onChange={(e) => setFormData({ ...formData, waist: e.target.value })}
                className="bg-white/10 border-white/20 text-white"
                placeholder="80.0"
              />
            </div>
            <div>
              <Label className="text-white/80">Hips (cm)</Label>
              <Input
                type="number"
                step="0.1"
                value={formData.hips}
                onChange={(e) => setFormData({ ...formData, hips: e.target.value })}
                className="bg-white/10 border-white/20 text-white"
                placeholder="95.0"
              />
            </div>
            <div>
              <Label className="text-white/80">Arms (cm)</Label>
              <Input
                type="number"
                step="0.1"
                value={formData.arms}
                onChange={(e) => setFormData({ ...formData, arms: e.target.value })}
                className="bg-white/10 border-white/20 text-white"
                placeholder="35.0"
              />
            </div>
            <div>
              <Label className="text-white/80">Thighs (cm)</Label>
              <Input
                type="number"
                step="0.1"
                value={formData.thighs}
                onChange={(e) => setFormData({ ...formData, thighs: e.target.value })}
                className="bg-white/10 border-white/20 text-white"
                placeholder="55.0"
              />
            </div>
          </div>
          <div className="flex gap-3 mt-6">
            <Button onClick={saveMeasurement} className="bg-gradient-to-r from-purple-500 to-pink-500">
              Save Measurement
            </Button>
            <Button onClick={() => setShowForm(false)} className="bg-white/10">
              Cancel
            </Button>
          </div>
        </Card>
      )}

      {/* Stats Cards */}
      {measurements.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="p-6 bg-white/5 border-white/10">
            <div className="flex items-center justify-between mb-2">
              <span className="text-white/60">Current Weight</span>
              <Calendar className="w-4 h-4 text-purple-400" />
            </div>
            <p className="text-white text-2xl">{measurements[measurements.length - 1].weight} kg</p>
            {weightChange && (
              <div className={`flex items-center gap-2 mt-2 ${parseFloat(weightChange.change) > 0 ? 'text-red-400' : 'text-green-400'}`}>
                {parseFloat(weightChange.change) > 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                <span>{weightChange.change} kg ({weightChange.percentage}%)</span>
              </div>
            )}
          </Card>

          {measurements[measurements.length - 1].bodyFat && (
            <Card className="p-6 bg-white/5 border-white/10">
              <div className="flex items-center justify-between mb-2">
                <span className="text-white/60">Body Fat %</span>
                <Calendar className="w-4 h-4 text-pink-400" />
              </div>
              <p className="text-white text-2xl">{measurements[measurements.length - 1].bodyFat}%</p>
            </Card>
          )}

          {measurements[measurements.length - 1].waist && (
            <Card className="p-6 bg-white/5 border-white/10">
              <div className="flex items-center justify-between mb-2">
                <span className="text-white/60">Waist</span>
                <Calendar className="w-4 h-4 text-blue-400" />
              </div>
              <p className="text-white text-2xl">{measurements[measurements.length - 1].waist} cm</p>
            </Card>
          )}
        </div>
      )}

      {/* Weight Chart */}
      {measurements.length > 0 && (
        <Card className="p-6 bg-white/5 border-white/10">
          <h3 className="text-white mb-4">Weight Progress</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={measurements}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff20" />
              <XAxis 
                dataKey="date" 
                stroke="#ffffff60"
                tick={{ fill: '#ffffff60' }}
              />
              <YAxis 
                stroke="#ffffff60"
                tick={{ fill: '#ffffff60' }}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'rgba(0, 0, 0, 0.8)', 
                  border: '1px solid rgba(255, 255, 255, 0.1)',
                  borderRadius: '8px',
                  color: '#fff'
                }}
              />
              <Legend wrapperStyle={{ color: '#fff' }} />
              <Line 
                type="monotone" 
                dataKey="weight" 
                stroke="#a855f7" 
                strokeWidth={2}
                dot={{ fill: '#a855f7', r: 4 }}
                name="Weight (kg)"
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      )}

      {/* Measurement History */}
      {measurements.length > 0 && (
        <Card className="p-6 bg-white/5 border-white/10">
          <h3 className="text-white mb-4">Measurement History</h3>
          <div className="space-y-3">
            {measurements.slice().reverse().map((measurement) => (
              <div
                key={measurement.id}
                className="flex items-center justify-between p-4 bg-white/5 rounded-lg"
              >
                <div className="flex-1">
                  <p className="text-white">{new Date(measurement.date).toLocaleDateString()}</p>
                  <div className="flex flex-wrap gap-4 mt-2 text-sm text-white/60">
                    <span>Weight: {measurement.weight} kg</span>
                    {measurement.bodyFat && <span>Body Fat: {measurement.bodyFat}%</span>}
                    {measurement.chest && <span>Chest: {measurement.chest} cm</span>}
                    {measurement.waist && <span>Waist: {measurement.waist} cm</span>}
                    {measurement.hips && <span>Hips: {measurement.hips} cm</span>}
                    {measurement.arms && <span>Arms: {measurement.arms} cm</span>}
                    {measurement.thighs && <span>Thighs: {measurement.thighs} cm</span>}
                  </div>
                </div>
                <Button
                  onClick={() => deleteMeasurement(measurement.id)}
                  className="bg-red-500/20 hover:bg-red-500/30 text-red-300"
                  size="sm"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        </Card>
      )}

      {measurements.length === 0 && !showForm && (
        <Card className="p-12 bg-white/5 border-white/10 text-center">
          <Calendar className="w-12 h-12 text-white/40 mx-auto mb-4" />
          <p className="text-white/60 mb-4">No measurements yet</p>
          <p className="text-white/40 text-sm">Start tracking your body measurements to see progress over time</p>
        </Card>
      )}
    </div>
  );
}
