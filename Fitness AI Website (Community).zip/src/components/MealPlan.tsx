import { UserData } from '../App';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Utensils, Flame, Beef, Wheat, Droplet } from 'lucide-react';

interface MealPlanProps {
  userData: UserData;
  tdee: number;
}

interface Meal {
  name: string;
  time: string;
  foods: string[];
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
}

export function MealPlan({ userData, tdee }: MealPlanProps) {
  const calculateMacros = () => {
    let targetCalories = tdee;
    
    // Adjust based on goal
    if (userData.goal === 'weight-loss') {
      targetCalories = tdee - 500;
    } else if (userData.goal === 'muscle-gain') {
      targetCalories = tdee + 300;
    }

    // Macro split (simplified)
    const proteinCalories = targetCalories * 0.30;
    const carbsCalories = targetCalories * 0.40;
    const fatsCalories = targetCalories * 0.30;

    return {
      calories: targetCalories,
      protein: Math.round(proteinCalories / 4), // 4 cal per gram
      carbs: Math.round(carbsCalories / 4),
      fats: Math.round(fatsCalories / 9), // 9 cal per gram
    };
  };

  const macros = calculateMacros();

  const generateMealPlan = (): Meal[] => {
    const caloriesPerMeal = Math.round(macros.calories / 5); // 5 meals
    const proteinPerMeal = Math.round(macros.protein / 5);
    const carbsPerMeal = Math.round(macros.carbs / 5);
    const fatsPerMeal = Math.round(macros.fats / 5);

    if (userData.goal === 'muscle-gain') {
      return [
        {
          name: 'Breakfast',
          time: '7:00 AM',
          foods: [
            '4 whole eggs scrambled',
            '2 slices whole wheat toast',
            '1 medium banana',
            '1 tbsp peanut butter',
          ],
          calories: caloriesPerMeal,
          protein: proteinPerMeal,
          carbs: carbsPerMeal,
          fats: fatsPerMeal,
        },
        {
          name: 'Mid-Morning Snack',
          time: '10:00 AM',
          foods: [
            'Greek yogurt (200g)',
            '1/4 cup granola',
            '1/2 cup mixed berries',
            '1 scoop whey protein',
          ],
          calories: caloriesPerMeal,
          protein: proteinPerMeal,
          carbs: carbsPerMeal,
          fats: fatsPerMeal,
        },
        {
          name: 'Lunch',
          time: '1:00 PM',
          foods: [
            'Grilled chicken breast (200g)',
            'Brown rice (1 cup cooked)',
            'Mixed vegetables (broccoli, carrots)',
            'Olive oil (1 tbsp)',
          ],
          calories: caloriesPerMeal,
          protein: proteinPerMeal,
          carbs: carbsPerMeal,
          fats: fatsPerMeal,
        },
        {
          name: 'Pre-Workout Snack',
          time: '4:00 PM',
          foods: [
            'Rice cakes (2)',
            'Almond butter (2 tbsp)',
            '1 medium apple',
            'Handful of almonds',
          ],
          calories: caloriesPerMeal,
          protein: proteinPerMeal,
          carbs: carbsPerMeal,
          fats: fatsPerMeal,
        },
        {
          name: 'Dinner',
          time: '7:00 PM',
          foods: [
            'Salmon fillet (200g)',
            'Sweet potato (medium)',
            'Asparagus (1 cup)',
            'Avocado (1/2)',
          ],
          calories: caloriesPerMeal,
          protein: proteinPerMeal,
          carbs: carbsPerMeal,
          fats: fatsPerMeal,
        },
      ];
    } else if (userData.goal === 'weight-loss') {
      return [
        {
          name: 'Breakfast',
          time: '7:00 AM',
          foods: [
            'Egg white omelet (4 whites)',
            'Spinach and mushrooms',
            '1 slice whole wheat toast',
            'Black coffee or tea',
          ],
          calories: caloriesPerMeal,
          protein: proteinPerMeal,
          carbs: carbsPerMeal,
          fats: fatsPerMeal,
        },
        {
          name: 'Mid-Morning Snack',
          time: '10:00 AM',
          foods: [
            'Greek yogurt (150g, low-fat)',
            '1/2 cup berries',
            '10 almonds',
          ],
          calories: caloriesPerMeal,
          protein: proteinPerMeal,
          carbs: carbsPerMeal,
          fats: fatsPerMeal,
        },
        {
          name: 'Lunch',
          time: '1:00 PM',
          foods: [
            'Grilled chicken salad',
            'Mixed greens, tomatoes, cucumber',
            'Balsamic vinaigrette (light)',
            'Quinoa (1/2 cup)',
          ],
          calories: caloriesPerMeal,
          protein: proteinPerMeal,
          carbs: carbsPerMeal,
          fats: fatsPerMeal,
        },
        {
          name: 'Afternoon Snack',
          time: '4:00 PM',
          foods: [
            'Protein shake',
            'Celery sticks',
            '1 tbsp hummus',
          ],
          calories: caloriesPerMeal,
          protein: proteinPerMeal,
          carbs: carbsPerMeal,
          fats: fatsPerMeal,
        },
        {
          name: 'Dinner',
          time: '7:00 PM',
          foods: [
            'Grilled white fish (180g)',
            'Steamed broccoli (2 cups)',
            'Cauliflower rice (1 cup)',
            'Lemon and herbs',
          ],
          calories: caloriesPerMeal,
          protein: proteinPerMeal,
          carbs: carbsPerMeal,
          fats: fatsPerMeal,
        },
      ];
    } else {
      // Maintenance or endurance
      return [
        {
          name: 'Breakfast',
          time: '7:00 AM',
          foods: [
            'Oatmeal (1 cup cooked)',
            '2 whole eggs',
            '1 banana',
            'Honey (1 tsp)',
          ],
          calories: caloriesPerMeal,
          protein: proteinPerMeal,
          carbs: carbsPerMeal,
          fats: fatsPerMeal,
        },
        {
          name: 'Mid-Morning Snack',
          time: '10:00 AM',
          foods: [
            'Greek yogurt (170g)',
            'Granola (1/4 cup)',
            'Mixed nuts (small handful)',
          ],
          calories: caloriesPerMeal,
          protein: proteinPerMeal,
          carbs: carbsPerMeal,
          fats: fatsPerMeal,
        },
        {
          name: 'Lunch',
          time: '1:00 PM',
          foods: [
            'Turkey breast sandwich',
            'Whole grain bread (2 slices)',
            'Lettuce, tomato, avocado',
            'Side salad',
          ],
          calories: caloriesPerMeal,
          protein: proteinPerMeal,
          carbs: carbsPerMeal,
          fats: fatsPerMeal,
        },
        {
          name: 'Afternoon Snack',
          time: '4:00 PM',
          foods: [
            'Protein bar',
            'Apple',
            'String cheese',
          ],
          calories: caloriesPerMeal,
          protein: proteinPerMeal,
          carbs: carbsPerMeal,
          fats: fatsPerMeal,
        },
        {
          name: 'Dinner',
          time: '7:00 PM',
          foods: [
            'Lean beef stir-fry (150g)',
            'Mixed vegetables',
            'Jasmine rice (3/4 cup)',
            'Soy sauce (low sodium)',
          ],
          calories: caloriesPerMeal,
          protein: proteinPerMeal,
          carbs: carbsPerMeal,
          fats: fatsPerMeal,
        },
      ];
    }
  };

  const mealPlan = generateMealPlan();

  const getDietaryModifications = () => {
    const modifications: string[] = [];
    
    // Get all dietary restrictions including custom ones
    const allRestrictions = [...userData.dietaryRestrictions];
    if (userData.otherDietaryRestrictions) {
      allRestrictions.push(userData.otherDietaryRestrictions);
    }
    
    if (allRestrictions.some(r => r.toLowerCase().includes('vegetarian') && !r.toLowerCase().includes('vegan'))) {
      modifications.push('Replace all meat and fish with plant-based proteins like tofu, tempeh, legumes, and seitan.');
    }
    if (allRestrictions.some(r => r.toLowerCase().includes('vegan'))) {
      modifications.push('Replace all animal products including eggs, dairy, and honey with plant-based alternatives.');
    }
    if (allRestrictions.some(r => r.toLowerCase().includes('gluten'))) {
      modifications.push('Substitute wheat bread, pasta, and grains with gluten-free alternatives like rice, quinoa, and gluten-free oats.');
    }
    if (allRestrictions.some(r => r.toLowerCase().includes('lactose'))) {
      modifications.push('Replace dairy products with lactose-free or plant-based alternatives like almond milk, oat milk, or lactose-free yogurt.');
    }
    if (allRestrictions.some(r => r.toLowerCase().includes('nut'))) {
      modifications.push('Avoid all nuts and nut butters. Use seed butters (sunflower, pumpkin) as alternatives.');
    }
    if (allRestrictions.some(r => r.toLowerCase().includes('sodium'))) {
      modifications.push('Use herbs and spices for flavor instead of salt. Choose fresh foods over processed ones.');
    }
    
    // Add general note for custom restrictions
    if (userData.otherDietaryRestrictions) {
      modifications.push(`Custom dietary restriction noted: ${userData.otherDietaryRestrictions}. Please adjust meals accordingly.`);
    }
    
    return modifications;
  };

  const getHealthDietModifications = () => {
    const modifications: string[] = [];
    
    if (userData.medicalConditions.includes('Diabetes')) {
      modifications.push('Monitor carbohydrate intake and choose low-glycemic index foods. Include fiber-rich foods.');
    }
    if (userData.medicalConditions.includes('Hypertension (High Blood Pressure)')) {
      modifications.push('Follow a low-sodium diet. Increase potassium-rich foods like bananas and leafy greens.');
    }
    if (userData.medicalConditions.includes('High Cholesterol')) {
      modifications.push('Limit saturated fats. Include more omega-3 fatty acids from fish or plant sources.');
    }
    if (userData.medicalConditions.includes('Heart Disease')) {
      modifications.push('Focus on heart-healthy foods: lean proteins, whole grains, fruits, vegetables, and healthy fats.');
    }
    if (userData.medicalConditions.includes('PCOS')) {
      modifications.push('Focus on whole foods, high fiber, and balanced meals to help manage insulin levels.');
    }
    if (userData.medicalConditions.includes('Thyroid Issues')) {
      modifications.push('Ensure adequate iodine and selenium intake. Consider timing of meals with medication.');
    }
    
    return modifications;
  };

  const dietaryModifications = getDietaryModifications();
  const healthDietModifications = getHealthDietModifications();

  return (
    <div className="space-y-6">
      {(userData.dietaryRestrictions.length > 0 || userData.medicalConditions.length > 0) && (
        <Card className="p-6 bg-blue-500/10 border-blue-500/30 backdrop-blur-sm">
          <h4 className="text-blue-300 mb-3 flex items-center gap-2">
            <Utensils className="w-5 h-5" />
            Dietary Adjustments
          </h4>
          
          {userData.dietaryRestrictions.length > 0 && (
            <div className="mb-4">
              <p className="text-blue-200 text-sm mb-2">
                Your dietary preferences: {userData.dietaryRestrictions.join(', ')}
              </p>
              {dietaryModifications.length > 0 && (
                <ul className="space-y-1 text-blue-100 text-sm">
                  {dietaryModifications.map((mod, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <span className="text-blue-400">•</span>
                      <span>{mod}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}

          {userData.medicalConditions.length > 0 && healthDietModifications.length > 0 && (
            <div>
              <p className="text-blue-200 text-sm mb-2">
                Health-based dietary recommendations:
              </p>
              <ul className="space-y-1 text-blue-100 text-sm">
                {healthDietModifications.map((mod, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <span className="text-blue-400">•</span>
                    <span>{mod}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
          
          <p className="text-blue-300 text-sm mt-3 italic">
            The meal plan below is a general template. Please adjust according to your restrictions.
          </p>
        </Card>
      )}

      {/* Macro Summary */}
      <Card className="p-6 bg-white/5 border-white/10 backdrop-blur-sm">
        <h3 className="text-white mb-4">Daily Nutrition Targets</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 bg-white/5 rounded-lg border border-white/10">
            <div className="flex items-center gap-2 mb-2">
              <Flame className="w-5 h-5 text-orange-400" />
              <span className="text-purple-200 text-sm">Calories</span>
            </div>
            <p className="text-white text-2xl">{macros.calories}</p>
          </div>
          <div className="p-4 bg-white/5 rounded-lg border border-white/10">
            <div className="flex items-center gap-2 mb-2">
              <Beef className="w-5 h-5 text-red-400" />
              <span className="text-purple-200 text-sm">Protein</span>
            </div>
            <p className="text-white text-2xl">{macros.protein}g</p>
          </div>
          <div className="p-4 bg-white/5 rounded-lg border border-white/10">
            <div className="flex items-center gap-2 mb-2">
              <Wheat className="w-5 h-5 text-yellow-400" />
              <span className="text-purple-200 text-sm">Carbs</span>
            </div>
            <p className="text-white text-2xl">{macros.carbs}g</p>
          </div>
          <div className="p-4 bg-white/5 rounded-lg border border-white/10">
            <div className="flex items-center gap-2 mb-2">
              <Droplet className="w-5 h-5 text-blue-400" />
              <span className="text-purple-200 text-sm">Fats</span>
            </div>
            <p className="text-white text-2xl">{macros.fats}g</p>
          </div>
        </div>
      </Card>

      {/* Meal Plan */}
      <Card className="p-6 bg-white/5 border-white/10 backdrop-blur-sm">
        <h3 className="text-white mb-4">Daily Meal Plan</h3>
        <div className="space-y-4">
          {mealPlan.map((meal, index) => (
            <div
              key={index}
              className="p-4 bg-white/5 rounded-lg border border-white/10"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <Utensils className="w-5 h-5 text-purple-400" />
                  <div>
                    <h4 className="text-white">{meal.name}</h4>
                    <p className="text-purple-300 text-sm">{meal.time}</p>
                  </div>
                </div>
                <Badge className="bg-purple-500">{meal.calories} cal</Badge>
              </div>
              
              <ul className="space-y-1 mb-3 ml-8">
                {meal.foods.map((food, foodIndex) => (
                  <li key={foodIndex} className="text-purple-200 text-sm">
                    • {food}
                  </li>
                ))}
              </ul>

              <div className="flex items-center gap-4 text-sm text-purple-300 ml-8 pt-2 border-t border-white/10">
                <span>P: {meal.protein}g</span>
                <span>C: {meal.carbs}g</span>
                <span>F: {meal.fats}g</span>
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card className="p-6 bg-white/5 border-white/10 backdrop-blur-sm">
        <h4 className="text-white mb-2">Hydration Reminder</h4>
        <p className="text-purple-200">
          Drink at least {Math.round(userData.weight * 0.033)} liters of water per day 
          (based on your body weight). Stay hydrated throughout the day!
        </p>
      </Card>
    </div>
  );
}