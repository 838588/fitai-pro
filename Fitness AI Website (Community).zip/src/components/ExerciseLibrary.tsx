import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Search, BookOpen, Filter, Target, Info } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

interface Exercise {
  name: string;
  category: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  equipment: string[];
  primaryMuscles: string[];
  secondaryMuscles: string[];
  instructions: string[];
  tips: string[];
}

const exercises: Exercise[] = [
  {
    name: 'Barbell Bench Press',
    category: 'Chest',
    difficulty: 'intermediate',
    equipment: ['Barbell', 'Bench'],
    primaryMuscles: ['Pectoralis Major'],
    secondaryMuscles: ['Anterior Deltoids', 'Triceps'],
    instructions: [
      'Lie flat on a bench with your feet planted on the ground',
      'Grip the barbell slightly wider than shoulder-width',
      'Unrack the bar and lower it slowly to your chest',
      'Press the bar back up explosively',
      'Lock out your elbows at the top',
    ],
    tips: [
      'Keep your shoulder blades retracted',
      'Maintain a slight arch in your lower back',
      'Touch the bar to your chest, don\'t bounce it',
      'Breathe in on the way down, out on the way up',
    ],
  },
  {
    name: 'Barbell Squats',
    category: 'Legs',
    difficulty: 'intermediate',
    equipment: ['Barbell', 'Squat Rack'],
    primaryMuscles: ['Quadriceps', 'Glutes'],
    secondaryMuscles: ['Hamstrings', 'Core', 'Calves'],
    instructions: [
      'Position the bar high on your traps',
      'Stand with feet shoulder-width apart',
      'Descend by bending knees and hips simultaneously',
      'Go down until thighs are parallel to ground',
      'Drive through heels to return to starting position',
    ],
    tips: [
      'Keep your chest up throughout the movement',
      'Don\'t let your knees cave inward',
      'Keep your core braced',
      'Look straight ahead or slightly up',
    ],
  },
  {
    name: 'Deadlifts',
    category: 'Back',
    difficulty: 'advanced',
    equipment: ['Barbell'],
    primaryMuscles: ['Erector Spinae', 'Glutes', 'Hamstrings'],
    secondaryMuscles: ['Lats', 'Traps', 'Forearms'],
    instructions: [
      'Stand with feet hip-width apart, bar over mid-foot',
      'Bend down and grip the bar just outside your legs',
      'Keep your back straight, chest up',
      'Drive through heels to lift the bar',
      'Stand up fully, pulling shoulders back',
      'Lower the bar by hinging at hips',
    ],
    tips: [
      'Never round your back',
      'Keep the bar close to your body',
      'Use mixed grip or straps for heavy weight',
      'Brace your core throughout',
    ],
  },
  {
    name: 'Pull-ups',
    category: 'Back',
    difficulty: 'intermediate',
    equipment: ['Pull-up Bar'],
    primaryMuscles: ['Latissimus Dorsi'],
    secondaryMuscles: ['Biceps', 'Rear Deltoids', 'Traps'],
    instructions: [
      'Hang from bar with overhand grip, hands shoulder-width apart',
      'Pull yourself up until chin is above bar',
      'Lower yourself down with control',
      'Repeat for desired reps',
    ],
    tips: [
      'Don\'t swing or use momentum',
      'Pull with your back, not just arms',
      'Full range of motion - dead hang to chin over bar',
      'If too hard, use resistance bands',
    ],
  },
  {
    name: 'Push-ups',
    category: 'Chest',
    difficulty: 'beginner',
    equipment: ['None'],
    primaryMuscles: ['Pectoralis Major'],
    secondaryMuscles: ['Anterior Deltoids', 'Triceps', 'Core'],
    instructions: [
      'Start in plank position, hands slightly wider than shoulders',
      'Lower your body until chest nearly touches ground',
      'Keep elbows at 45-degree angle',
      'Push back up to starting position',
    ],
    tips: [
      'Keep your body in straight line',
      'Don\'t let hips sag',
      'Full range of motion',
      'Modify on knees if needed',
    ],
  },
  {
    name: 'Shoulder Press',
    category: 'Shoulders',
    difficulty: 'beginner',
    equipment: ['Dumbbells', 'Barbell'],
    primaryMuscles: ['Deltoids'],
    secondaryMuscles: ['Triceps', 'Upper Chest', 'Core'],
    instructions: [
      'Stand with weights at shoulder height',
      'Press weights overhead until arms are extended',
      'Lower back to shoulder height with control',
      'Repeat for desired reps',
    ],
    tips: [
      'Don\'t arch your back excessively',
      'Keep core engaged',
      'Press slightly forward at top',
      'Use full range of motion',
    ],
  },
  {
    name: 'Bicep Curls',
    category: 'Arms',
    difficulty: 'beginner',
    equipment: ['Dumbbells', 'Barbell', 'Cable'],
    primaryMuscles: ['Biceps Brachii'],
    secondaryMuscles: ['Brachialis', 'Forearms'],
    instructions: [
      'Stand with weights in hands, arms fully extended',
      'Keep elbows close to torso',
      'Curl weights up to shoulder level',
      'Squeeze biceps at top',
      'Lower weights with control',
    ],
    tips: [
      'Don\'t swing or use momentum',
      'Keep elbows stationary',
      'Full range of motion',
      'Control the negative',
    ],
  },
  {
    name: 'Plank',
    category: 'Core',
    difficulty: 'beginner',
    equipment: ['None'],
    primaryMuscles: ['Rectus Abdominis', 'Transverse Abdominis'],
    secondaryMuscles: ['Obliques', 'Lower Back', 'Shoulders'],
    instructions: [
      'Start in push-up position',
      'Lower onto forearms',
      'Keep body in straight line from head to heels',
      'Hold position for desired time',
    ],
    tips: [
      'Don\'t let hips sag or pike up',
      'Engage your core',
      'Breathe normally',
      'Start with shorter holds',
    ],
  },
  {
    name: 'Lunges',
    category: 'Legs',
    difficulty: 'beginner',
    equipment: ['None', 'Dumbbells'],
    primaryMuscles: ['Quadriceps', 'Glutes'],
    secondaryMuscles: ['Hamstrings', 'Calves', 'Core'],
    instructions: [
      'Stand with feet hip-width apart',
      'Step forward with one leg',
      'Lower hips until both knees are at 90 degrees',
      'Push back to starting position',
      'Alternate legs',
    ],
    tips: [
      'Keep front knee over ankle',
      'Don\'t let front knee go past toes',
      'Keep torso upright',
      'Step far enough forward',
    ],
  },
  {
    name: 'Tricep Dips',
    category: 'Arms',
    difficulty: 'intermediate',
    equipment: ['Dip Bar', 'Bench'],
    primaryMuscles: ['Triceps'],
    secondaryMuscles: ['Chest', 'Anterior Deltoids'],
    instructions: [
      'Grip parallel bars, arms extended',
      'Lower body by bending elbows',
      'Go down until upper arms are parallel to ground',
      'Push back up to starting position',
    ],
    tips: [
      'Keep elbows close to body',
      'Lean slightly forward for more chest activation',
      'Don\'t go too deep to protect shoulders',
      'Use assistance if needed',
    ],
  },
  {
    name: 'Lat Pulldowns',
    category: 'Back',
    difficulty: 'beginner',
    equipment: ['Cable Machine'],
    primaryMuscles: ['Latissimus Dorsi'],
    secondaryMuscles: ['Biceps', 'Rear Deltoids', 'Rhomboids'],
    instructions: [
      'Sit at lat pulldown machine',
      'Grip bar slightly wider than shoulder-width',
      'Pull bar down to upper chest',
      'Squeeze shoulder blades together',
      'Return to starting position with control',
    ],
    tips: [
      'Don\'t lean back too much',
      'Pull with your back, not arms',
      'Keep chest up',
      'Full range of motion',
    ],
  },
  {
    name: 'Romanian Deadlifts',
    category: 'Legs',
    difficulty: 'intermediate',
    equipment: ['Barbell', 'Dumbbells'],
    primaryMuscles: ['Hamstrings', 'Glutes'],
    secondaryMuscles: ['Lower Back', 'Traps'],
    instructions: [
      'Stand holding barbell at hip level',
      'Keep knees slightly bent',
      'Hinge at hips, lowering bar down legs',
      'Feel stretch in hamstrings',
      'Return to standing position',
    ],
    tips: [
      'Keep back straight',
      'Bar should stay close to legs',
      'Don\'t round lower back',
      'Focus on hip hinge, not squat',
    ],
  },
];

export function ExerciseLibrary() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedDifficulty, setSelectedDifficulty] = useState('All');
  const [selectedExercise, setSelectedExercise] = useState<Exercise | null>(null);

  const categories = ['All', 'Chest', 'Back', 'Legs', 'Shoulders', 'Arms', 'Core'];
  const difficulties = ['All', 'beginner', 'intermediate', 'advanced'];

  const filteredExercises = exercises.filter(exercise => {
    const matchesSearch = exercise.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         exercise.primaryMuscles.some(m => m.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = selectedCategory === 'All' || exercise.category === selectedCategory;
    const matchesDifficulty = selectedDifficulty === 'All' || exercise.difficulty === selectedDifficulty;
    
    return matchesSearch && matchesCategory && matchesDifficulty;
  });

  const getDifficultyColor = (difficulty: string) => {
    const colors = {
      beginner: 'bg-green-500/20 text-green-300 border-green-500/30',
      intermediate: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
      advanced: 'bg-red-500/20 text-red-300 border-red-500/30',
    };
    return colors[difficulty as keyof typeof colors];
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-white mb-2 flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-purple-400" />
            Exercise Library
          </h2>
          <p className="text-white/60">Learn proper form and technique</p>
        </div>
      </div>

      {/* Search and Filters */}
      <Card className="p-6 bg-white/5 border-white/10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40" />
              <Input
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-white/10 border-white/20 text-white"
                placeholder="Search exercises or muscles..."
              />
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2 mb-2">
              <Filter className="w-4 h-4 text-white/60" />
              <span className="text-white/60 text-sm">Category</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {categories.map(cat => (
                <Button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={selectedCategory === cat ? 'bg-purple-500' : 'bg-white/10'}
                  size="sm"
                >
                  {cat}
                </Button>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2 mb-2">
              <Target className="w-4 h-4 text-white/60" />
              <span className="text-white/60 text-sm">Difficulty</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {difficulties.map(diff => (
                <Button
                  key={diff}
                  onClick={() => setSelectedDifficulty(diff)}
                  className={selectedDifficulty === diff ? 'bg-purple-500' : 'bg-white/10'}
                  size="sm"
                >
                  {diff === 'All' ? 'All' : diff.charAt(0).toUpperCase() + diff.slice(1)}
                </Button>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-4 text-white/60 text-sm">
          Showing {filteredExercises.length} of {exercises.length} exercises
        </div>
      </Card>

      {/* Exercise Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredExercises.map((exercise) => (
          <Card
            key={exercise.name}
            className="p-6 bg-white/5 border-white/10 hover:bg-white/10 cursor-pointer transition-all"
            onClick={() => setSelectedExercise(exercise)}
          >
            <div className="flex items-start justify-between mb-3">
              <h3 className="text-white">{exercise.name}</h3>
              <Info className="w-4 h-4 text-purple-400" />
            </div>

            <div className="flex flex-wrap gap-2 mb-3">
              <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30">
                {exercise.category}
              </Badge>
              <Badge className={getDifficultyColor(exercise.difficulty)}>
                {exercise.difficulty}
              </Badge>
            </div>

            <div className="space-y-2 text-sm">
              <div>
                <span className="text-white/60">Primary: </span>
                <span className="text-white">{exercise.primaryMuscles.join(', ')}</span>
              </div>
              <div>
                <span className="text-white/60">Equipment: </span>
                <span className="text-white">{exercise.equipment.join(', ')}</span>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {filteredExercises.length === 0 && (
        <Card className="p-12 bg-white/5 border-white/10 text-center">
          <BookOpen className="w-12 h-12 text-white/40 mx-auto mb-4" />
          <p className="text-white/60">No exercises found matching your criteria</p>
        </Card>
      )}

      {/* Exercise Detail Modal */}
      {selectedExercise && (
        <div 
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedExercise(null)}
        >
          <Card 
            className="bg-gradient-to-br from-gray-900 to-black border-white/20 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h2 className="text-white mb-2">{selectedExercise.name}</h2>
                  <div className="flex gap-2">
                    <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30">
                      {selectedExercise.category}
                    </Badge>
                    <Badge className={getDifficultyColor(selectedExercise.difficulty)}>
                      {selectedExercise.difficulty}
                    </Badge>
                  </div>
                </div>
                <Button
                  onClick={() => setSelectedExercise(null)}
                  className="bg-white/10"
                  size="sm"
                >
                  ✕
                </Button>
              </div>

              <Tabs defaultValue="instructions" className="w-full">
                <TabsList className="grid w-full grid-cols-3 bg-white/5">
                  <TabsTrigger value="instructions">Instructions</TabsTrigger>
                  <TabsTrigger value="muscles">Muscles</TabsTrigger>
                  <TabsTrigger value="tips">Tips</TabsTrigger>
                </TabsList>

                <TabsContent value="instructions" className="mt-4">
                  <div className="space-y-3">
                    {selectedExercise.instructions.map((instruction, index) => (
                      <div key={index} className="flex gap-3">
                        <div className="flex-shrink-0 w-6 h-6 rounded-full bg-purple-500/20 text-purple-300 flex items-center justify-center text-sm">
                          {index + 1}
                        </div>
                        <p className="text-white/80">{instruction}</p>
                      </div>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="muscles" className="mt-4">
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-white mb-2">Primary Muscles</h3>
                      <div className="flex flex-wrap gap-2">
                        {selectedExercise.primaryMuscles.map(muscle => (
                          <Badge key={muscle} className="bg-green-500/20 text-green-300 border-green-500/30">
                            {muscle}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div>
                      <h3 className="text-white mb-2">Secondary Muscles</h3>
                      <div className="flex flex-wrap gap-2">
                        {selectedExercise.secondaryMuscles.map(muscle => (
                          <Badge key={muscle} className="bg-blue-500/20 text-blue-300 border-blue-500/30">
                            {muscle}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div>
                      <h3 className="text-white mb-2">Equipment Needed</h3>
                      <div className="flex flex-wrap gap-2">
                        {selectedExercise.equipment.map(eq => (
                          <Badge key={eq} className="bg-orange-500/20 text-orange-300 border-orange-500/30">
                            {eq}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="tips" className="mt-4">
                  <div className="space-y-3">
                    {selectedExercise.tips.map((tip, index) => (
                      <div key={index} className="flex gap-3 p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                        <span className="text-yellow-400">💡</span>
                        <p className="text-white/80">{tip}</p>
                      </div>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
