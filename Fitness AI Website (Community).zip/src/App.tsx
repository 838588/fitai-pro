import { useState, useEffect } from 'react';
import { UserDataForm } from './components/UserDataForm';
import { Dashboard } from './components/Dashboard';
import { AuthPage } from './components/AuthPage';
import { ThemeSelector } from './components/ThemeSelector';
import { ChatBot } from './components/ChatBot';
import { Dumbbell, LogOut } from 'lucide-react';
import { createClient } from './utils/supabase/client';
import { ThemeProvider, useTheme } from './contexts/ThemeContext';
import { projectId } from './utils/supabase/info';
import { toast } from 'sonner@2.0.3';
import { Toaster } from './components/ui/sonner';

export interface UserData {
  name: string;
  age: number;
  gender: string;
  height: number;
  weight: number;
  goal: string;
  activityLevel: string;
  experience: string;
  medicalConditions: string[];
  dietaryRestrictions: string[];
  otherMedicalConditions?: string;
  otherDietaryRestrictions?: string;
}

function AppContent() {
  const { theme } = useTheme();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [userName, setUserName] = useState('');
  const [userData, setUserData] = useState<UserData | null>(null);
  const [showForm, setShowForm] = useState(true);
  const [isCheckingSession, setIsCheckingSession] = useState(true);

  useEffect(() => {
    // Check for existing session on mount
    const checkSession = async () => {
      try {
        const supabase = createClient();
        const { data, error } = await supabase.auth.getSession();

        if (error) {
          console.log(`Session check error: ${error.message}`);
          setIsCheckingSession(false);
          return;
        }

        if (data.session) {
          console.log('Existing session found');
          const token = data.session.access_token;
          setAccessToken(token);
          setUserName(data.session.user.user_metadata?.name || data.session.user.email || 'User');
          setIsAuthenticated(true);
          
          // Load saved user data
          await loadUserData(token);
        }
      } catch (err) {
        console.log(`Error checking session: ${err}`);
      } finally {
        setIsCheckingSession(false);
      }
    };

    checkSession();
  }, []);

  const loadUserData = async (token: string) => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-eb0ee345/user-data`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      );

      const data = await response.json();

      if (response.ok && data.userData) {
        console.log('User data loaded successfully');
        setUserData(data.userData);
        setShowForm(false);
        toast.success('Welcome back! Your fitness plan has been loaded.');
      } else {
        console.log('No saved user data found');
      }
    } catch (err) {
      console.log(`Error loading user data: ${err}`);
    }
  };

  const saveUserData = async (data: UserData) => {
    if (!accessToken) {
      console.log('Cannot save user data: No access token');
      return;
    }

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-eb0ee345/user-data`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`
          },
          body: JSON.stringify({ userData: data })
        }
      );

      if (response.ok) {
        console.log('User data saved successfully');
        toast.success('Your fitness plan has been saved!');
      } else {
        const errorData = await response.json();
        console.log(`Error saving user data: ${errorData.error}`);
        toast.error('Failed to save your fitness plan');
      }
    } catch (err) {
      console.log(`Error saving user data: ${err}`);
    }
  };

  const handleAuthSuccess = async (token: string, name: string) => {
    setAccessToken(token);
    setUserName(name);
    setIsAuthenticated(true);
    
    // Load user data after authentication
    await loadUserData(token);
  };

  const handleSignOut = async () => {
    try {
      const supabase = createClient();
      const { error } = await supabase.auth.signOut();

      if (error) {
        console.log(`Sign out error: ${error.message}`);
        return;
      }

      console.log('Sign out successful');
      setIsAuthenticated(false);
      setAccessToken(null);
      setUserName('');
      setUserData(null);
      setShowForm(true);
    } catch (err) {
      console.log(`Unexpected error during sign out: ${err}`);
    }
  };

  const handleSubmit = async (data: UserData) => {
    setUserData(data);
    setShowForm(false);
    
    // Save user data to backend
    await saveUserData(data);
  };

  const handleReset = () => {
    setUserData(null);
    setShowForm(true);
  };

  // Show loading state while checking session
  if (isCheckingSession) {
    return (
      <div className={`min-h-screen bg-gradient-to-br ${theme.gradient} flex items-center justify-center`}>
        <div className={`text-${theme.textPrimary} text-center`}>
          <Dumbbell className="w-12 h-12 mx-auto mb-4 animate-pulse" />
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  // Show auth page if not authenticated
  if (!isAuthenticated) {
    return <AuthPage onAuthSuccess={handleAuthSuccess} />;
  }

  return (
    <div className={`min-h-screen bg-gradient-to-br ${theme.gradient}`}>
      <Toaster />
      {/* Header */}
      <header className="border-b border-white/10 bg-black/20 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`bg-gradient-to-br ${theme.buttonGradient} p-2 rounded-lg`}>
                <Dumbbell className={`w-6 h-6 text-${theme.textPrimary}`} />
              </div>
              <div>
                <h1 className={`text-${theme.textPrimary}`}>FitAI Pro</h1>
                <p className={`text-${theme.textSecondary} text-sm`}>AI-Powered Fitness & Nutrition</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <span className={`text-${theme.textSecondary} text-sm hidden md:block`}>
                Welcome, {userName}
              </span>
              <ThemeSelector />
              {userData && (
                <button
                  onClick={handleReset}
                  className={`px-4 py-2 bg-${theme.cardBg} hover:bg-white/20 text-${theme.textPrimary} rounded-lg transition-colors`}
                  style={{ backgroundColor: 'rgba(255, 255, 255, 0.1)' }}
                >
                  New Assessment
                </button>
              )}
              <button
                onClick={handleSignOut}
                className="flex items-center gap-2 px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-200 rounded-lg transition-colors border border-red-500/30"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">Sign Out</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {showForm ? (
          <UserDataForm onSubmit={handleSubmit} />
        ) : (
          userData && accessToken && <Dashboard userData={userData} accessToken={accessToken} />
        )}
      </main>

      {/* ChatBot - Only show when user has completed the form */}
      {!showForm && userData && <ChatBot userData={userData} />}
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}