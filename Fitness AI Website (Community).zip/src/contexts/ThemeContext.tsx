import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Theme, themes, getTheme } from '../utils/themes';

interface ThemeContextType {
  theme: Theme;
  setTheme: (themeId: string) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<Theme>(() => {
    // Load theme from localStorage or default to first theme
    const savedThemeId = localStorage.getItem('fitai-theme');
    return savedThemeId ? getTheme(savedThemeId) : themes[0];
  });

  const setTheme = (themeId: string) => {
    const newTheme = getTheme(themeId);
    setThemeState(newTheme);
    localStorage.setItem('fitai-theme', themeId);
  };

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within ThemeProvider');
  }
  return context;
}
