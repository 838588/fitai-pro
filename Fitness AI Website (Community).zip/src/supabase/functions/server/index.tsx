import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "jsr:@supabase/supabase-js@2";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-eb0ee345/health", (c) => {
  return c.json({ status: "ok" });
});

// Sign up endpoint
app.post("/make-server-eb0ee345/signup", async (c) => {
  try {
    const body = await c.req.json();
    const { email, password, name } = body;

    if (!email || !password) {
      console.log("Sign up error: Missing email or password");
      return c.json({ error: "Email and password are required" }, 400);
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name: name || '' },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });

    if (error) {
      console.log(`Authorization error while creating user during sign up: ${error.message}`);
      return c.json({ error: error.message }, 400);
    }

    console.log(`User created successfully: ${email}`);
    return c.json({ user: data.user });
  } catch (error) {
    console.log(`Unexpected error during sign up: ${error}`);
    return c.json({ error: "An unexpected error occurred during sign up" }, 500);
  }
});

// Save user fitness data endpoint
app.post("/make-server-eb0ee345/user-data", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      console.log("Save user data error: No authorization token provided");
      return c.json({ error: "Unauthorized" }, 401);
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (authError || !user?.id) {
      console.log(`Save user data authorization error: ${authError?.message || 'No user ID'}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    const body = await c.req.json();
    const { userData } = body;

    if (!userData) {
      console.log("Save user data error: No userData provided");
      return c.json({ error: "User data is required" }, 400);
    }

    // Save user data to KV store
    const key = `user_data_${user.id}`;
    await kv.set(key, userData);

    console.log(`User data saved successfully for user: ${user.id}`);
    return c.json({ success: true });
  } catch (error) {
    console.log(`Unexpected error saving user data: ${error}`);
    return c.json({ error: "An unexpected error occurred while saving user data" }, 500);
  }
});

// Get user fitness data endpoint
app.get("/make-server-eb0ee345/user-data", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      console.log("Get user data error: No authorization token provided");
      return c.json({ error: "Unauthorized" }, 401);
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (authError || !user?.id) {
      console.log(`Get user data authorization error: ${authError?.message || 'No user ID'}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    // Get user data from KV store
    const key = `user_data_${user.id}`;
    const userData = await kv.get(key);

    console.log(`User data retrieved for user: ${user.id}`);
    return c.json({ userData: userData || null });
  } catch (error) {
    console.log(`Unexpected error retrieving user data: ${error}`);
    return c.json({ error: "An unexpected error occurred while retrieving user data" }, 500);
  }
});

// Get progress data endpoint
app.get("/make-server-eb0ee345/progress", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      console.log("Get progress error: No authorization token provided");
      return c.json({ error: "Unauthorized" }, 401);
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (authError || !user?.id) {
      console.log(`Get progress authorization error: ${authError?.message || 'No user ID'}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    // Get progress data from KV store
    const key = `progress_${user.id}`;
    const progress = await kv.get(key);

    console.log(`Progress data retrieved for user: ${user.id}`);
    return c.json({ progress: progress || null });
  } catch (error) {
    console.log(`Unexpected error retrieving progress data: ${error}`);
    return c.json({ error: "An unexpected error occurred while retrieving progress data" }, 500);
  }
});

// Save workout completion endpoint
app.post("/make-server-eb0ee345/log-workout", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      console.log("Log workout error: No authorization token provided");
      return c.json({ error: "Unauthorized" }, 401);
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (authError || !user?.id) {
      console.log(`Log workout authorization error: ${authError?.message || 'No user ID'}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    const body = await c.req.json();
    const { workoutLog } = body;

    if (!workoutLog) {
      console.log("Log workout error: No workoutLog provided");
      return c.json({ error: "Workout log is required" }, 400);
    }

    // Get existing progress data
    const progressKey = `progress_${user.id}`;
    let progress = await kv.get(progressKey) || {
      weeklyWorkouts: generateEmptyWeekData(),
      monthlyProgress: generateEmptyMonthData(),
      totalWorkouts: 0,
      currentStreak: 0,
      longestStreak: 0,
      totalMinutes: 0,
      recentLogs: [],
      lastWorkoutDate: null
    };

    // Update progress
    progress.totalWorkouts += 1;
    progress.totalMinutes += workoutLog.duration;
    
    // Add to recent logs (keep last 10)
    progress.recentLogs.unshift(workoutLog);
    if (progress.recentLogs.length > 10) {
      progress.recentLogs = progress.recentLogs.slice(0, 10);
    }

    // Update weekly data
    const dayIndex = new Date(workoutLog.date).getDay();
    const adjustedIndex = dayIndex === 0 ? 6 : dayIndex - 1; // Convert Sunday=0 to Sunday=6
    progress.weeklyWorkouts[adjustedIndex].workouts += 1;

    // Calculate streaks
    const today = new Date().toDateString();
    const workoutDate = new Date(workoutLog.date).toDateString();
    
    if (workoutDate === today || workoutDate === progress.lastWorkoutDate) {
      // Same day or consecutive day
      if (progress.lastWorkoutDate) {
        const lastDate = new Date(progress.lastWorkoutDate);
        const currentDate = new Date(workoutDate);
        const diffDays = Math.floor((currentDate.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));
        
        if (diffDays <= 1) {
          progress.currentStreak = diffDays === 1 ? progress.currentStreak + 1 : progress.currentStreak;
        } else {
          progress.currentStreak = 1;
        }
      } else {
        progress.currentStreak = 1;
      }
      
      progress.longestStreak = Math.max(progress.longestStreak, progress.currentStreak);
      progress.lastWorkoutDate = workoutDate;
    }

    // Save updated progress
    await kv.set(progressKey, progress);

    console.log(`Workout logged successfully for user: ${user.id}`);
    return c.json({ success: true, progress });
  } catch (error) {
    console.log(`Unexpected error logging workout: ${error}`);
    return c.json({ error: "An unexpected error occurred while logging workout" }, 500);
  }
});

// Generic data endpoints for all features
const endpoints = [
  'body-measurements',
  'personal-records',
  'workout-calendar',
  'nutrition-log',
  'water-tracker',
  'sleep-tracker',
  'achievements'
];

endpoints.forEach(endpoint => {
  // GET endpoint
  app.get(`/make-server-eb0ee345/${endpoint}`, async (c) => {
    try {
      const accessToken = c.req.header('Authorization')?.split(' ')[1];
      if (!accessToken) {
        return c.json({ error: "Unauthorized" }, 401);
      }

      const supabase = createClient(
        Deno.env.get('SUPABASE_URL') ?? '',
        Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      );

      const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
      
      if (authError || !user?.id) {
        return c.json({ error: "Unauthorized" }, 401);
      }

      const key = `${endpoint}_${user.id}`;
      const data = await kv.get(key);
      
      const responseKey = endpoint.replace(/-/g, '_');
      return c.json({ [responseKey === 'nutrition_log' ? 'entries' : responseKey === 'workout_calendar' ? 'workoutDays' : responseKey.replace(/_/g, '') || 'data']: data || (endpoint === 'body-measurements' ? [] : endpoint === 'personal-records' ? [] : endpoint === 'workout-calendar' ? [] : endpoint === 'nutrition-log' ? [] : endpoint === 'water-tracker' ? [] : endpoint === 'sleep-tracker' ? [] : []) });
    } catch (error) {
      console.log(`Error retrieving ${endpoint}: ${error}`);
      return c.json({ error: "An unexpected error occurred" }, 500);
    }
  });

  // POST endpoint
  app.post(`/make-server-eb0ee345/${endpoint}`, async (c) => {
    try {
      const accessToken = c.req.header('Authorization')?.split(' ')[1];
      if (!accessToken) {
        return c.json({ error: "Unauthorized" }, 401);
      }

      const supabase = createClient(
        Deno.env.get('SUPABASE_URL') ?? '',
        Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      );

      const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
      
      if (authError || !user?.id) {
        return c.json({ error: "Unauthorized" }, 401);
      }

      const body = await c.req.json();
      const key = `${endpoint}_${user.id}`;
      
      // Extract data from body - handle different field names
      const data = body.measurements || body.records || body.workoutDays || body.entries || body.achievements || null;
      
      if (data !== null) {
        await kv.set(key, data);
      }

      return c.json({ success: true });
    } catch (error) {
      console.log(`Error saving ${endpoint}: ${error}`);
      return c.json({ error: "An unexpected error occurred" }, 500);
    }
  });
});

// Helper functions for server
function generateEmptyWeekData() {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  return days.map(day => ({ day, workouts: 0 }));
}

function generateEmptyMonthData() {
  return [
    { week: 'Week 1', completion: 0 },
    { week: 'Week 2', completion: 0 },
    { week: 'Week 3', completion: 0 },
    { week: 'Week 4', completion: 0 }
  ];
}

Deno.serve(app.fetch);