export interface Theme {
  id: string;
  name: string;
  gradient: string;
  primary: string;
  secondary: string;
  accent: string;
  textPrimary: string;
  textSecondary: string;
  cardBg: string;
  cardBorder: string;
  buttonGradient: string;
  buttonHover: string;
}

export const themes: Theme[] = [
  {
    id: 'purple-dream',
    name: 'Purple Dream',
    gradient: 'from-slate-900 via-purple-900 to-slate-900',
    primary: 'purple-500',
    secondary: 'pink-500',
    accent: 'purple-400',
    textPrimary: 'white',
    textSecondary: 'purple-300',
    cardBg: 'white/10',
    cardBorder: 'white/20',
    buttonGradient: 'from-purple-500 to-pink-500',
    buttonHover: 'from-purple-600 to-pink-600',
  },
  {
    id: 'ocean-blue',
    name: 'Ocean Blue',
    gradient: 'from-slate-900 via-blue-900 to-cyan-900',
    primary: 'blue-500',
    secondary: 'cyan-500',
    accent: 'cyan-400',
    textPrimary: 'white',
    textSecondary: 'cyan-300',
    cardBg: 'white/10',
    cardBorder: 'white/20',
    buttonGradient: 'from-blue-500 to-cyan-500',
    buttonHover: 'from-blue-600 to-cyan-600',
  },
  {
    id: 'sunset-orange',
    name: 'Sunset Fire',
    gradient: 'from-slate-900 via-orange-900 to-red-900',
    primary: 'orange-500',
    secondary: 'red-500',
    accent: 'orange-400',
    textPrimary: 'white',
    textSecondary: 'orange-300',
    cardBg: 'white/10',
    cardBorder: 'white/20',
    buttonGradient: 'from-orange-500 to-red-500',
    buttonHover: 'from-orange-600 to-red-600',
  },
  {
    id: 'forest-green',
    name: 'Forest Green',
    gradient: 'from-slate-900 via-green-900 to-emerald-900',
    primary: 'green-500',
    secondary: 'emerald-500',
    accent: 'emerald-400',
    textPrimary: 'white',
    textSecondary: 'emerald-300',
    cardBg: 'white/10',
    cardBorder: 'white/20',
    buttonGradient: 'from-green-500 to-emerald-500',
    buttonHover: 'from-green-600 to-emerald-600',
  },
  {
    id: 'pink-power',
    name: 'Pink Power',
    gradient: 'from-slate-900 via-pink-900 to-rose-900',
    primary: 'pink-500',
    secondary: 'rose-500',
    accent: 'pink-400',
    textPrimary: 'white',
    textSecondary: 'pink-300',
    cardBg: 'white/10',
    cardBorder: 'white/20',
    buttonGradient: 'from-pink-500 to-rose-500',
    buttonHover: 'from-pink-600 to-rose-600',
  },
  {
    id: 'midnight-blue',
    name: 'Midnight Blue',
    gradient: 'from-slate-950 via-indigo-950 to-blue-950',
    primary: 'indigo-500',
    secondary: 'blue-600',
    accent: 'indigo-400',
    textPrimary: 'white',
    textSecondary: 'indigo-300',
    cardBg: 'white/10',
    cardBorder: 'white/20',
    buttonGradient: 'from-indigo-500 to-blue-600',
    buttonHover: 'from-indigo-600 to-blue-700',
  },
];

export function getTheme(themeId: string): Theme {
  return themes.find(t => t.id === themeId) || themes[0];
}
