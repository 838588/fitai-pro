
  # Fitness AI Website (Community)

  This is a code bundle for Fitness AI Website (Community). The original project is available at https://www.figma.com/design/U9wyReR2yKCyy3cQXHwC2m/Fitness-AI-Website--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  